<<>>plugins/kotlin/idea/src/org/jetbrains/kotlin/idea/refactoring/changeSignature/KotlinChangeSignatureUsageProcessor.java<<>>
<<>> 20 Jan 2021 <<>>



import com.intellij.refactoring.changeSignature.*
import com.intellij.refactoring.rename.ResolveSnapshotProvider
import com.intellij.refactoring.rename.UnresolvableCollisionUsageInfo
import com.intellij.refactoring.util.*
import com.intellij.usageView.UsageInfo
import com.intellij.util.containers.MultiMap
import org.jetbrains.kotlin.asJava.elements.KtLightMethod
	@@ -589,10 +586,8 @@ class KotlinChangeSignatureUsageProcessor : ChangeSignatureUsageProcessor {
        }

        val parametersToRemove = ktChangeInfo.parametersToRemove
        if (ktChangeInfo.checkUsedParameters && function is KtCallableDeclaration) {
            checkParametersToDelete(function, parametersToRemove, result)
        }

        for (parameter in ktChangeInfo.getNonReceiverParameters()) {
	@@ -640,19 +635,45 @@ class KotlinChangeSignatureUsageProcessor : ChangeSignatureUsageProcessor {
                    val declaration = usageInfo.declaration as? KtCallableDeclaration ?: continue
                    if (ktChangeInfo.checkUsedParameters) {
                        checkParametersToDelete(declaration, parametersToRemove, result)
                    }
                }

                is KotlinCallerUsage -> {
                    val callerDescriptor = usageInfo.element?.resolveToDescriptorIfAny() ?: continue
                    findParameterDuplicationInCaller(result, ktChangeInfo, usageInfo.element!!, callerDescriptor)
                }

                is KotlinWrapperForJavaUsageInfos -> {
                    findConflictsInJavaUsages(ktChangeInfo, usageInfo, result)
                }
            }
        }

        return result
    }

    private fun findConflictsInJavaUsages(
        changeInfo: KotlinChangeInfo,
        wrapper: KotlinWrapperForJavaUsageInfos,
        result: MultiMap<PsiElement, String>,
    ) {
        if (!changeInfo.checkUsedParameters) return

        val javaChangeInfo = wrapper.javaChangeInfo
        val javaUsageInfos = wrapper.javaUsageInfos
        val parametersToRemove = javaChangeInfo.toRemoveParm()

        for (javaUsage in javaUsageInfos) {
            if (javaUsage !is OverriderUsageInfo) continue

            val javaMethod = javaUsage.overridingMethod
            val baseMethod = javaUsage.baseMethod
            if (baseMethod != javaChangeInfo.method) continue

            JavaChangeSignatureUsageProcessor.ConflictSearcher.checkParametersToDelete(javaMethod, parametersToRemove, result)
        }
    }

    private fun findReceiverUsages(
        callableDeclaration: KtCallableDeclaration,
        result: MultiMap<PsiElement, String>,
	@@ -691,8 +712,15 @@ class KotlinChangeSignatureUsageProcessor : ChangeSignatureUsageProcessor {
        result: MultiMap<PsiElement, String>,
    ) {
        val scope = LocalSearchScope(callableDeclaration)
        val valueParameters = callableDeclaration.valueParameters
        val hasReceiver = valueParameters.size != toRemove.size
        if (hasReceiver && toRemove[0]) {
            findReceiverUsages(callableDeclaration, result)
        }

        for ((i, parameter) in valueParameters.withIndex()) {
            val index = (if (hasReceiver) 1 else 0) + i
            if (toRemove[index]) {
                registerConflictIfUsed(parameter, scope, result)
            }
        }