
<<>>plugins/kotlin/idea/src/org/jetbrains/kotlin/idea/refactoring/changeSignature/KotlinChangeSignature.java<<>>
<<>> 24 Feb 2021 <<>>



import org.jetbrains.kotlin.idea.refactoring.changeSignature.ui.KotlinChangePropertySignatureDialog
import org.jetbrains.kotlin.idea.refactoring.changeSignature.ui.KotlinChangeSignatureDialog
import org.jetbrains.kotlin.idea.refactoring.createJavaMethod
import org.jetbrains.kotlin.psi.KtClass
import org.jetbrains.kotlin.psi.KtFile
import org.jetbrains.kotlin.psi.KtFunction
import org.jetbrains.kotlin.psi.KtPsiFactory
import org.jetbrains.kotlin.utils.KotlinExceptionWithAttachments

interface KotlinChangeSignatureConfiguration {
	@@ -81,37 +84,35 @@ class KotlinChangeSignature(
    override fun forcePerformForSelectedFunctionOnly() = configuration.forcePerformForSelectedFunctionOnly()

    private fun runSilentRefactoring(descriptor: KotlinMethodDescriptor) {
        val processor = if (descriptor.baseDescriptor is PropertyDescriptor)
            KotlinChangePropertySignatureDialog.createProcessorForSilentRefactoring(project, commandName, descriptor)
        else
            when (val baseDeclaration = descriptor.baseDeclaration) {
                is KtFunction, is KtClass -> KotlinChangeSignatureDialog.createRefactoringProcessorForSilentChangeSignature(
                    project,
                    commandName,
                    descriptor,
                    defaultValueContext
                )

                is PsiMethod -> {
                    if (baseDeclaration.language != JavaLanguage.INSTANCE) {
                        Messages.showErrorDialog(
                            KotlinBundle.message(
                                "error.text.can.t.change.signature.of.method",
                                baseDeclaration.language.displayName
                            ),
                            commandName
                        )
                        return
                    }

                    ChangeSignatureProcessor(project, getPreviewInfoForJavaMethod(descriptor).second)
                }

                else -> throwUnexpectedDeclarationException(baseDeclaration)
            }


        processor.run()
    }


<<>> 24 Feb 2021 <<>>

import com.intellij.util.VisibilityUtil
import org.jetbrains.annotations.TestOnly
import org.jetbrains.kotlin.asJava.getRepresentativeLightMethod
import org.jetbrains.kotlin.descriptors.*
import org.jetbrains.kotlin.idea.KotlinBundle
import org.jetbrains.kotlin.idea.codeInsight.DescriptorToSourceUtilsIde
import org.jetbrains.kotlin.idea.core.getDeepestSuperDeclarations
    @@ -59,7 +56,7 @@ fun runChangeSignature(
    callableDescriptor: CallableDescriptor,
    configuration: KotlinChangeSignatureConfiguration,
    defaultValueContext: PsiElement,
    @NlsContexts.Command commandName: String? = null
): Boolean {
    val result = KotlinChangeSignature(project, editor, callableDescriptor, configuration, defaultValueContext, commandName).run()
    if (!result) {
    @@ -120,57 +117,59 @@ class KotlinChangeSignature(
    }

    private fun runInteractiveRefactoring(descriptor: KotlinMethodDescriptor) {
        val dialog = if (descriptor.baseDescriptor is PropertyDescriptor)
            KotlinChangePropertySignatureDialog(project, descriptor, commandName)
        else
            when (val baseDeclaration = descriptor.baseDeclaration) {
                is KtFunction, is KtClass -> KotlinChangeSignatureDialog(project, editor, descriptor, defaultValueContext, commandName)
                is PsiMethod -> {
                    // No changes are made from Kotlin side: just run foreign refactoring
                    if (descriptor is KotlinChangeSignatureData) {
                        ChangeSignatureUtil.invokeChangeSignatureOn(baseDeclaration, project)
                        return
                    }

                    if (baseDeclaration.language != JavaLanguage.INSTANCE) {
                        Messages.showErrorDialog(
                            KotlinBundle.message(
                                "error.text.can.t.change.signature.of.method",
                                baseDeclaration.language.displayName
                            ), commandName
                        )
                        return
                    }

                    val (preview, javaChangeInfo) = getPreviewInfoForJavaMethod(descriptor)
                    val javaDescriptor = object : JavaMethodDescriptor(preview) {
                        @Suppress("UNCHECKED_CAST")
                        override fun getParameters() = javaChangeInfo.newParameters.toMutableList() as MutableList<ParameterInfoImpl>
                    }

                    object : JavaChangeSignatureDialog(project, javaDescriptor, false, null) {
                        override fun createRefactoringProcessor(): BaseRefactoringProcessor {
                            val parameters = parameters
                            LOG.assertTrue(myMethod.method.isValid)
                            val newJavaChangeInfo = JavaChangeInfoImpl(
                                visibility ?: VisibilityUtil.getVisibilityModifier(myMethod.method.modifierList),
                                javaChangeInfo.method,
                                methodName,
                                returnType ?: CanonicalTypes.createTypeWrapper(PsiType.VOID),
                                parameters.toTypedArray(),
                                exceptions,
                                isGenerateDelegate,
                                myMethodsToPropagateParameters ?: HashSet(),
                                myMethodsToPropagateExceptions ?: HashSet()
                            ).also {
                                it.setCheckUnusedParameter()
                            }

                            return ChangeSignatureProcessor(myProject, newJavaChangeInfo)
                        }
                    }
                }

                else -> throwUnexpectedDeclarationException(baseDeclaration)
            }

        if (ApplicationManager.getApplication().isUnitTestMode) {
            try {

