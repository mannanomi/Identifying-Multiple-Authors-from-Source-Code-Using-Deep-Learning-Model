<<>>plugins/kotlin/idea/tests/test/org/jetbrains/kotlin/idea/refactoring/changeSignature/KotlinChangeSignatureTest.java<<>>
<<>> 15 March 2021 <<>>

 private fun KotlinMutableMethodDescriptor.addNewIntParameterWithValue(asParameter: Boolean, index: Int? = null) {
        val newIntParameter = createNewIntParameter(defaultValueForCall = kotlinDefaultIntValue, withDefaultValue = asParameter)
        if (index != null) {
            addParameter(index, newIntParameter)
        } else {
            addParameter(newIntParameter)
        }
    }

    private fun doTestWithDescriptorModification(modificator: KotlinMutableMethodDescriptor.() -> Unit) {
        configureFiles()

	@@ -463,12 +472,60 @@ class KotlinChangeSignatureTest : KotlinLightCodeInsightFixtureTestCase() {
    """.trimIndent()
    )

    fun testAddNewParameterWithDefaultValueToFunctionWithEmptyArguments() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true)
    }

    fun testAddNewLastParameterWithDefaultValue() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true)
    }

    fun testAddNewLastParameterWithDefaultValue2() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true)
    }

    fun testAddNewLastParameterWithDefaultValue3() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true)
    }

    fun testAddNewFirstParameterWithDefaultValue() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true, 0)
    }

    fun testAddNewMiddleParameterWithDefaultValue() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(true, 2)
    }

    fun testAddNewParameterToFunctionWithEmptyArguments() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testAddNewLastParameter() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testAddNewLastParameter2() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testAddNewLastParameter3() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testAddNewFirstParameter() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false, 0)
    }

    fun testAddNewMiddleParameter() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false, 2)
    }

    fun testAddParameterToInvokeFunction() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testAddParameterToInvokeFunctionFromObject() = doTestWithDescriptorModification {
        addNewIntParameterWithValue(false)
    }

    fun testCaretAtReferenceAsValueParameter() = doTestConflict()


    <<>> 20 Jan 2021 <<>>

     fun testInvokeOperatorInClass() {
        doTest {
            val defaultValueForCall = KtPsiFactory(project).createExpression("42")
            addParameter(KotlinParameterInfo(
                originalBaseFunctionDescriptor,
                -1,
                "i",
                KotlinTypeInfo(false, BUILT_INS.intType),
                null,
                defaultValueForCall
            ))
        }
    }

    fun testInvokeOperatorInObject() {
        doTest {
            val defaultValueForCall = KtPsiFactory(project).createExpression("42")
            addParameter(KotlinParameterInfo(
                originalBaseFunctionDescriptor,
                -1,
                "i",
                KotlinTypeInfo(false, BUILT_INS.intType),
                null,
                defaultValueForCall
            ))
        }
    }