<<>>plugins/kotlin/idea/src/org/jetbrains/kotlin/idea/refactoring/changeSignature/KotlinChangeSignatureProcessor.java <<>>
<<>> 12 March 2021 <<>>


private fun findConstructorPropertyUsages(
        primaryConstructor: KtPrimaryConstructor,
        allUsages: ArrayList<UsageInfo>
    ) {
        for ((index, parameter) in primaryConstructor.valueParameters.withIndex()) {
            if (!parameter.isOverridable) continue

            val parameterInfo = ktChangeInfo.newParameters.find { it.originalIndex == index } ?: continue
            val descriptor = parameter.resolveToDescriptorIfAny() as? PropertyDescriptor ?: continue
            val methodDescriptor = KotlinChangeSignatureData(
                descriptor,
                parameter,
                listOf(descriptor),
            )

            val propertyChangeInfo = KotlinChangeInfo(
                methodDescriptor,
                name = parameterInfo.name,
                newReturnTypeInfo = parameterInfo.currentTypeInfo,
                context = parameter,
            )

            ktChangeInfo.registerInnerChangeInfo(propertyChangeInfo)
            KotlinChangeSignatureProcessor(myProject, propertyChangeInfo, commandName).findUsages().mapNotNullTo(allUsages) {
                if (it is KotlinWrapperForJavaUsageInfos) return@mapNotNullTo it

                val element = it.element
                if (element != null && !(it is KotlinCallableDefinitionUsage<*> && element == parameter))
                    KotlinWrapperForPropertyInheritorsUsage(propertyChangeInfo, it, element)
                else
                    null
            }
        }
    }