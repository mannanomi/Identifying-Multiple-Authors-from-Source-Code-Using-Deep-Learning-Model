<<>>plugins/kotlin/idea/tests/test/org/jetbrains/kotlin/idea/hierarchy/AbstractHierarchyTest.java <<>>
<<>> 24 Feeb 2021 <<>>

import com.intellij.ide.hierarchy.type.SupertypesHierarchyTreeStructure
import com.intellij.ide.hierarchy.type.TypeHierarchyTreeStructure
import com.intellij.lang.LanguageExtension
import com.intellij.openapi.util.Computable
import com.intellij.openapi.util.io.FileUtil
import com.intellij.psi.PsiClass
	@@ -43,118 +42,70 @@ Test accept more than one file, file extension should be .java or .kt
abstract class AbstractHierarchyTest : KotlinHierarchyViewTestBase() {
    protected var folderName: String? = null

    private fun doHierarchyTest(folderName: String, structure: () -> HierarchyTreeStructure) {
        this.folderName = folderName
        doHierarchyTest(structure, *filesToConfigure)
    }

    protected fun doTypeClassHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        TypeHierarchyTreeStructure(
            project,
            getElementAtCaret(LanguageTypeHierarchy.INSTANCE) as PsiClass,
            HierarchyBrowserBaseEx.SCOPE_PROJECT
        )
    }

    protected fun doSuperClassHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        SupertypesHierarchyTreeStructure(
            project,
            getElementAtCaret(LanguageTypeHierarchy.INSTANCE) as PsiClass
        )
    }

    protected fun doSubClassHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        SubtypesHierarchyTreeStructure(
            project,
            getElementAtCaret(LanguageTypeHierarchy.INSTANCE) as PsiClass,
            HierarchyBrowserBaseEx.SCOPE_PROJECT
        )
    }

    protected fun doCallerHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        KotlinCallerTreeStructure(
            (getElementAtCaret(LanguageCallHierarchy.INSTANCE) as KtElement),
            HierarchyBrowserBaseEx.SCOPE_PROJECT
        )
    }

    protected fun doCallerJavaHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        CallerMethodsTreeStructure(
            project,
            getElementAtCaret(LanguageCallHierarchy.INSTANCE) as PsiMember,
            HierarchyBrowserBaseEx.SCOPE_PROJECT
        )
    }

    protected fun doCalleeHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        KotlinCalleeTreeStructure(
            (getElementAtCaret(LanguageCallHierarchy.INSTANCE) as KtElement),
            HierarchyBrowserBaseEx.SCOPE_PROJECT
        )
    }

    protected fun doOverrideHierarchyTest(folderName: String) = doHierarchyTest(folderName) {
        KotlinOverrideTreeStructure(
            project,
            (getElementAtCaret(LanguageMethodHierarchy.INSTANCE) as KtCallableDeclaration)
        )
    }

    private fun getElementAtCaret(extension: LanguageExtension<HierarchyProvider>): PsiElement {
        val file = PsiDocumentManager.getInstance(project).getPsiFile(editor.document)
        val dataContext = createTextEditorBasedDataContext(project, editor, editor.caretModel.currentCaret)
        return BrowseHierarchyActionBase.findProvider(extension, file, file, dataContext)?.getTarget(dataContext)
            ?: throw RefactoringErrorHintException("Cannot apply action for element at caret")
    }

    protected val filesToConfigure: Array<String>
        get() {
            val folderName = folderName ?: error("folderName should be initialized")
	@@ -194,9 +145,7 @@ abstract class AbstractHierarchyTest : KotlinHierarchyViewTestBase() {
        }
    }

    override fun getProjectDescriptor(): LightProjectDescriptor = KotlinWithJdkAndRuntimeLightProjectDescriptor.INSTANCE

    override val testDataDirectory: File
        get() {