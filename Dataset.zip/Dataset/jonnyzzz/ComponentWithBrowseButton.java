<<>>platform/platform-api/src/com/intellij/openapi/ui/ComponentWithBrowseButton.java<<>>
<<>> 22 March 2021 <<>>

public class ComponentWithBrowseButton<Comp extends JComponent> extends JPanel implements Disposable {
  private final Comp myComponent;
  private final FixedSizeButton myBrowseButton;
  private final ExtendableTextComponent.Extension myInlineButtonExtension;
  private boolean myButtonEnabled = true;

  @ApiStatus.Internal
	@@ -59,14 +60,16 @@ public ComponentWithBrowseButton(@NotNull Comp component, @Nullable ActionListen
    setFocusable(false);
    boolean inlineBrowseButton = myComponent instanceof ExtendableTextComponent && isUseInlineBrowserButton();
    if (inlineBrowseButton) {
      ((ExtendableTextComponent)myComponent).addExtension(myInlineButtonExtension = ExtendableTextComponent.Extension.create(
        getDefaultIcon(), getHoveredIcon(), getIconTooltip(), this::notifyActionListeners));
      new DumbAwareAction() {
        @Override
        public void actionPerformed(@NotNull AnActionEvent e) {
          notifyActionListeners();
        }
      }.registerCustomShortcutSet(new CustomShortcutSet(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, InputEvent.SHIFT_DOWN_MASK)), myComponent);
    } else {
      myInlineButtonExtension = null;
    }
    add(myComponent, BorderLayout.CENTER);

	@@ -149,6 +152,17 @@ public void setButtonEnabled(boolean buttonEnabled) {
    setEnabled(isEnabled());
  }

  public void setButtonVisible(boolean buttonVisible) {
    myBrowseButton.setVisible(buttonVisible);
    if (myInlineButtonExtension != null && myComponent instanceof ExtendableTextComponent) {
      if (buttonVisible) {
        ((ExtendableTextComponent)myComponent).addExtension(myInlineButtonExtension);
      } else {
        ((ExtendableTextComponent)myComponent).removeExtension(myInlineButtonExtension);
      }
    }
  }

  public void setButtonIcon(@NotNull Icon icon) {
    myBrowseButton.setIcon(icon);
    myBrowseButton.setDisabledIcon(IconLoader.getDisabledIcon(icon));
	@@ -209,6 +223,13 @@ public void dispose() {
    }
  }

  /**
   * @deprecated The implementation may attach the button via the
   * {@link ExtendableTextComponent#addExtension(ExtendableTextComponent.Extension)}
   * so that the returned button may not be visible to the users. Instead,
   * please use the class APIs without using the implementation details.
   */
  @Deprecated
  public FixedSizeButton getButton() {
    return myBrowseButton;
  }