<<>>platform/lang-impl/src/com/intellij/openapi/projectRoots/impl/jdkDownloader/RuntimeChooserPresenter.java<<>>
<<>> 12 March 2021 <<>>


     return
    }

    if (value is RuntimeChooserSelectRuntimeItem) {
      append(LangBundle.message("dialog.item.choose.ide.runtime.select.runtime"), SimpleTextAttributes.GRAYED_ATTRIBUTES)
      return
    }

    if (value is RuntimeChooserAddCustomItem) {
      append(LangBundle.message("dialog.item.choose.ide.runtime.add.custom", SimpleTextAttributes.LINK_PLAIN_ATTRIBUTES))
      return
    }

    if (value is RuntimeChooserCustomItem) {
      append(LangBundle.message("dialog.item.choose.ide.runtime.custom", value.version), SimpleTextAttributes.REGULAR_BOLD_ATTRIBUTES,
             true)
      return
    }
  }

  companion object {
    fun SimpleColoredComponent.presetCurrentRuntime(value: RuntimeChooserCurrentItem) {
      value.version?.let {
        append(it, SimpleTextAttributes.REGULAR_BOLD_ATTRIBUTES, true)
        append(" ")
      }

      value.displayName?.let {
        append(it, SimpleTextAttributes.GRAYED_ATTRIBUTES)
        append(" ")
      }

      if (value.version == null && value.displayName == null) {
        append(LangBundle.message("dialog.item.choose.ide.runtime.unknown"))
      }

      if (value.isBundled) {
        append(LangBundle.message("dialog.item.choose.ide.runtime.bundled"), SimpleTextAttributes.GRAY_SMALL_ATTRIBUTES)
      }
    }

    fun SimpleColoredComponent.presentJbrItem(value: RuntimeChooserDownloadableItem) {
      val item = value.item

      append(item.jdkVersion, SimpleTextAttributes.REGULAR_BOLD_ATTRIBUTES, true)
      append(" ")

      item.product.vendor.let {
        append(it, SimpleTextAttributes.GRAYED_ATTRIBUTES)
        append(" ")
      }

      item.product.product?.let {
        append(it, SimpleTextAttributes.GRAYED_ATTRIBUTES)
        append(" ")
      }

      item.product.flavour?.let {
        append(it, SimpleTextAttributes.GRAYED_ATTRIBUTES)
      }
    }
  }
}