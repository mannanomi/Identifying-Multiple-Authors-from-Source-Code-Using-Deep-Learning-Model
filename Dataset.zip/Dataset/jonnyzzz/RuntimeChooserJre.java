<<>>platform/lang-impl/src/com/intellij/openapi/projectRoots/impl/jdkDownloader/RuntimeChooserJre.java<<>>
<<>> 16 Mar 2021 <<>>


import com.intellij.util.io.isFile
import com.intellij.util.lang.JavaVersion
import org.jetbrains.jps.model.java.JdkVersionDetector
import java.nio.file.Files
import java.nio.file.Path
import java.util.*
import kotlin.io.path.div
import kotlin.io.path.isExecutable

private val LOG = logger<RuntimeChooserJreValidator>()

interface RuntimeChooserJreValidatorCallback<R> {
  fun onSdkResolved(displayName: String?, versionString: String, sdkHome: Path): R
  fun onError(@NlsContexts.DialogMessage message: String): R
}

	@@ -64,8 +66,7 @@ object RuntimeChooserJreValidator {
  ): R {
    val homeDir = runCatching { Path.of(computeHomePath()).toAbsolutePath() }.getOrNull()
                  ?: return callback.onError(
                    LangBundle.message("dialog.message.choose.ide.runtime.set.unknown.error", LangBundle.message("dialog.message.choose.ide.runtime.no.file.part")))

    if (SystemInfo.isMac && homeDir.endsWith("Contents/Home")) {
      return testNewJdkUnderProgress(allowRunProcesses, { homeDir.parent?.parent?.toString() }, callback)
	@@ -98,13 +99,14 @@ object RuntimeChooserJreValidator {
      JdkVersionDetector.getInstance().detectJdkVersionInfo(inferredHome)
    }.getOrNull() ?: return callback.onError(LangBundle.message("dialog.message.choose.ide.runtime.set.unknown.error", homeDir))

    if (info.version == null || info.version.feature < minJdkFeatureVersion) {
      LOG.warn("Failed to scan JDK for boot runtime: ${homeDir}. The version $info is less than $minJdkFeatureVersion")
      return callback.onError(LangBundle.message("dialog.message.choose.ide.runtime.set.version.error", homeDir, "11",
                                                 info.version.toString()))
    }

    val jdkVersion = tryComputeAdvancedFullVersion(binJava)
                     ?: info.version?.toString()
                     ?: return callback.onError(LangBundle.message("dialog.message.choose.ide.runtime.set.unknown.error", homeDir))

    if (allowRunProcesses) {
	@@ -123,7 +125,57 @@ object RuntimeChooserJreValidator {
      }
    }

    return callback.onSdkResolved(info.displayName, jdkVersion, homeDir)
  }
}

private class ReleaseProperties(releaseFile: Path) {
  private val p = Properties()

  init {
    runCatching {
      if (Files.isRegularFile(releaseFile)) {
        Files.newInputStream(releaseFile).use { p.load(it) }
      }
    }
  }

  fun getJdkProperty(name: String) = p
    .getProperty(name)
    ?.trim()
    ?.removeSurrounding("\"")
    ?.trim()
}

private fun tryComputeAdvancedFullVersion(binJava: Path): String? = runCatching {
  //we compute the path to handle macOS bundle layout once again here
  val theReleaseFile = binJava.parent?.parent?.resolve("release") ?: return@runCatching null
  val p = ReleaseProperties(theReleaseFile)

  val implementor = p.getJdkProperty("IMPLEMENTOR")
  when {
    implementor.isNullOrBlank() -> null

    implementor.startsWith("JetBrains") -> {
      p.getJdkProperty("IMPLEMENTOR_VERSION")
        ?.removePrefix("JBR-")
        ?.replace("JBRSDK-", "JBRSDK ")
        ?.trim()
    }

    implementor.startsWith("Azul") -> {
      listOfNotNull(
        p.getJdkProperty("JAVA_VERSION"),
        p.getJdkProperty("IMPLEMENTOR_VERSION")
      ).joinToString(" ").takeIf { it.isNotBlank() }
    }

    implementor.startsWith("Amazon.com") -> {
      val implVersion = p.getJdkProperty("IMPLEMENTOR_VERSION")
      if (implVersion != null && implVersion.startsWith("Corretto-")) {
        implVersion.removePrefix("Corretto-")
      } else null
    }
    else -> null
  }
}.getOrNull()