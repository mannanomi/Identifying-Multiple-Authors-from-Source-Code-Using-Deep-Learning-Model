<<>>.platform/lang-impl/src/com/intellij/openapi/projectRoots/impl/jdkDownloader/RuntimeChooserDialog.java <<>>
<<>> 16 March 2021 <<>>

import com.intellij.icons.AllIcons
import com.intellij.lang.LangBundle
import com.intellij.openapi.actionSystem.DataProvider
import com.intellij.openapi.application.ModalityState
import com.intellij.openapi.application.invokeLater
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory
import com.intellij.openapi.ide.CopyPasteManager
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.ComboBox
import com.intellij.openapi.ui.DialogWrapper
import com.intellij.openapi.ui.TextFieldWithBrowseButton
import com.intellij.openapi.util.Disposer
import com.intellij.openapi.util.io.FileUtil
import com.intellij.openapi.util.text.HtmlChunk
import com.intellij.ui.IdeBorderFactory
import com.intellij.ui.JBColor
import com.intellij.ui.SideBorder
import com.intellij.ui.SimpleColoredComponent
import com.intellij.ui.components.JBLabel
import com.intellij.ui.layout.*
import com.intellij.util.castSafelyTo
import com.intellij.util.io.isDirectory
import com.intellij.util.ui.JBUI
import com.intellij.util.ui.components.BorderLayoutPanel
import java.awt.datatransfer.DataFlavor
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import java.nio.file.Path
import java.nio.file.Paths
import javax.swing.Action
	@@ -50,6 +53,36 @@ class RuntimeChooserDialog(
    title = LangBundle.message("dialog.title.choose.ide.runtime")
    setResizable(false)
    init()
    initClipboardListener()
  }

  private fun initClipboardListener() {
    val knownPaths = mutableSetOf<String>()

    val clipboardUpdateAction = {
      val newPath = runCatching {
        CopyPasteManager.getInstance().contents?.getTransferData(DataFlavor.stringFlavor) as? String
      }.getOrNull()

      if (newPath != null && newPath.isNotBlank() && knownPaths.add(newPath)) {
        RuntimeChooserCustom.importDetectedItem(newPath.trim(), model)
      }
    }

    val windowListener = object: WindowAdapter() {
      override fun windowActivated(e: WindowEvent?) {
        invokeLater(ModalityState.any()) {
          clipboardUpdateAction()
        }
      }
    }

    window?.let { window ->
      window.addWindowListener(windowListener)
      Disposer.register(disposable) { window.removeWindowListener(windowListener) }
    }

    clipboardUpdateAction()
  }

  override fun getData(dataId: String): Any? {
      
      
      
      

<<>> 145 March 2021 <<>>






import com.intellij.icons.AllIcons
import com.intellij.lang.LangBundle
import com.intellij.openapi.actionSystem.DataProvider
import com.intellij.openapi.editor.colors.EditorColors
import com.intellij.openapi.editor.colors.EditorColorsManager
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.ComboBox
import com.intellij.openapi.ui.DialogWrapper
import com.intellij.openapi.ui.TextFieldWithBrowseButton
import com.intellij.openapi.util.io.FileUtil
import com.intellij.openapi.util.text.HtmlChunk
import com.intellij.ui.IdeBorderFactory
import com.intellij.ui.JBColor
import com.intellij.ui.SideBorder
import com.intellij.ui.SimpleColoredComponent
import com.intellij.ui.components.JBLabel
import com.intellij.ui.components.JBTextField
import com.intellij.ui.layout.*
import com.intellij.util.castSafelyTo
import com.intellij.util.io.isDirectory
import com.intellij.util.ui.JBUI
import com.intellij.util.ui.components.BorderLayoutPanel
import java.awt.Color
import java.nio.file.Path
import java.nio.file.Paths
import javax.swing.Action
	@@ -79,6 +88,27 @@ class RuntimeChooserDialog(
    return RuntimeChooserDialogResult.Cancel
  }

  override fun createTitlePane(): JComponent {
    return object : BorderLayoutPanel() {
      init {
        border = JBUI.Borders.merge(JBUI.Borders.empty(10), IdeBorderFactory.createBorder(JBColor.border(), SideBorder.BOTTOM), true)

        addToCenter(JBLabel().apply {
          icon = AllIcons.General.Warning
          text = HtmlChunk
            .html()
            .addText(LangBundle.message("dialog.label.choose.ide.runtime.warn"))
            .toString()
        })

        withPreferredWidth(400)
      }

      override fun getBackground(): Color? =
        EditorColorsManager.getInstance().globalScheme.getColor(EditorColors.NOTIFICATION_BACKGROUND) ?: super.getBackground()
    }
  }

  override fun createCenterPanel(): JComponent {
    jdkCombobox = object : ComboBox<RuntimeChooserItem>(model.mainComboBoxModel) {
      init {
	@@ -104,19 +134,6 @@ class RuntimeChooserDialog(
    }

    return panel {
      row(LangBundle.message("dialog.label.choose.ide.runtime.current")) {
        val control = SimpleColoredComponent()
        control().constraints(growX)
	     