<<>>platform/lang-impl/src/com/intellij/codeInsight/hint/ImplementationViewComponent.java<<>>
<<>> 22 Dec 2020 <<>>



import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.NlsActions;
import com.intellij.openapi.util.NlsContexts;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.FileStatusManager;
import com.intellij.openapi.vfs.VirtualFile;
	@@ -40,11 +39,9 @@
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.util.PsiUtilCore;
import com.intellij.ui.*;
import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.list.LeftRightRenderer;
import com.intellij.usages.UsageView;
import com.intellij.util.DocumentUtil;
import com.intellij.util.IconUtil;
	@@ -96,11 +93,11 @@ public boolean hasElementsToShow() {

  private static class FileDescriptor {
    @NotNull public final VirtualFile myFile;
    public final ImplementationViewElement myElement;

    FileDescriptor(@NotNull VirtualFile file, ImplementationViewElement element) {
      myFile = file;
      myElement = element;
    }
  }

	@@ -125,6 +122,7 @@ public ImplementationViewComponent(Collection<ImplementationViewElement> element

    myBinaryPanel = new JPanel(new BorderLayout());
    myViewingPanel.add(myBinaryPanel, BINARY_PAGE_KEY);
    myViewingPanel.setBorder(JBUI.Borders.empty(12, 6));

    add(myViewingPanel, BorderLayout.CENTER);

	@@ -157,13 +155,15 @@ protected DataContext getDataContext() {
    };
    myGearAction.setNoIconsInPopup(true);

    final JPanel header = new JPanel(new BorderLayout());
    header.setBorder(BorderFactory.createCompoundBorder(IdeBorderFactory.createBorder(SideBorder.BOTTOM), JBUI.Borders.empty(3)));
    final JPanel toolbarPanel = new JPanel(new GridBagLayout());
    final GridBagConstraints gc =
      new GridBagConstraints(GridBagConstraints.RELATIVE, 0, 1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                             JBUI.insets(0), 0, 0);
    JComponent component = myToolbar.getComponent();
    component.setBorder(null);
    toolbarPanel.add(component, gc);

    setPreferredSize(JBUI.size(600, 400));

	@@ -179,9 +179,13 @@ protected DataContext getDataContext() {
        myEditor.setHighlighter(highlighter);
      }


      gc.fill = GridBagConstraints.HORIZONTAL;
      gc.weightx = 1;

      mySingleEntryPanel = new JPanel(new BorderLayout());
      toolbarPanel.add(mySingleEntryPanel, gc);

      myFileChooser = new ComboBox<>(fileDescriptors.toArray(new FileDescriptor[0]), 250);
      myFileChooser.addActionListener(e -> {
        int index1 = myFileChooser.getSelectedIndex();
	@@ -194,21 +198,17 @@ protected DataContext getDataContext() {
      toolbarPanel.add(myFileChooser, gc);

      if (myElements.length > 1) {
        mySingleEntryPanel.setVisible(false);
        updateRenderer(project);
      }
      else {
        myFileChooser.setVisible(false);

        if (virtualFile != null) {
          updateSingleEntryLabel(virtualFile);
        }
      }

      header.add(toolbarPanel, BorderLayout.CENTER);
      header.add(myGearAction, BorderLayout.EAST);

	@@ -255,17 +255,42 @@ private void updateRenderer(final Project project) {
    myFileChooser.setRenderer(createRenderer(project));
  }

  private static ListCellRenderer<FileDescriptor> createRenderer(Project project) {
    return new LeftRightRenderer<>() {
      @NotNull
      @Override
      protected ListCellRenderer<FileDescriptor> getMainRenderer() {
        return new ColoredListCellRenderer<>() {
          @Override
          protected void customizeCellRenderer(@NotNull JList<? extends FileDescriptor> list,
                                               FileDescriptor value, int index, boolean selected, boolean hasFocus) {
            if (value != null) {
              ImplementationViewElement element = value.myElement;
              setIcon(getIconForFile(value.myFile, project));
              append(element.getPresentableText());
              String presentation = element.getContainerPresentation();
              if (presentation != null) {
                append("  ");
                append(StringUtil.trimStart(StringUtil.trimEnd(presentation, ")"), "("), SimpleTextAttributes.GRAYED_ATTRIBUTES);
              }
            }
          }
        };
      }

      @NotNull
      @Override
      protected ListCellRenderer<FileDescriptor> getRightRenderer() {
        return new SimpleListCellRenderer<>() {
          @Override
          public void customize(@NotNull JList<? extends FileDescriptor> list,
                                FileDescriptor value, int index, boolean selected, boolean hasFocus) {
            if (value != null) {
              setText(value.myElement.getLocationText());
              setIcon(value.myElement.getLocationIcon());
            }
          }
        };
      }
    };
  }
	@@ -276,7 +301,7 @@ protected void customize(FileDescriptor value) {
    String[] result = new String[model.getSize()];
    for (int i = 0; i < model.getSize(); i++) {
      FileDescriptor o = model.getElementAt(i);
      result[i] = o.myElement.getPresentableText();
    }
    return result;
  }
	@@ -514,7 +539,9 @@ public void update(@NotNull AnActionEvent e) {
    forward.registerCustomShortcutSet(new CustomShortcutSet(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0)), this);
    group.add(forward);

    ActionToolbar toolbar = ActionManager.getInstance().createActionToolbar("ImplementationView", group, true);
    toolbar.setReservePlaceAutoPopupIcon(false);
    return toolbar;
  }

  private void goBack() {
	@@ -542,7 +569,7 @@ public UsageView showInUsageView() {

  private class BackAction extends AnAction implements HintManagerImpl.ActionToIgnore {
    BackAction() {
      super(CodeInsightBundle.messagePointer("quick.definition.back"), AllIcons.Actions.Play_back);
    }

    @Override
	@@ -561,7 +588,7 @@ public void update(@NotNull AnActionEvent e) {

  private class ForwardAction extends AnAction implements HintManagerImpl.ActionToIgnore {
    ForwardAction() {
      super(CodeInsightBundle.messagePointer("quick.definition.forward"), AllIcons.Actions.Play_forward);
    }

    @Override