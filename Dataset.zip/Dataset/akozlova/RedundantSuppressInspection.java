<<>>platform/lang-impl/src/com/intellij/codeInspection/RedundantSuppressInspection.java<<>>
<<>> 22 Jan 2021 <<>>

           @NotNull ProblemDescriptionsProcessor problemDescriptionsProcessor) {
    InspectionSuppressor extension = LanguageInspectionSuppressors.INSTANCE.forLanguage(file.getLanguage());
    if (!(extension instanceof RedundantSuppressionDetector)) return;
    InspectionProfileImpl profile = getProfile(manager, globalContext);
    final CommonProblemDescriptor[] descriptors = checkElement(file, (RedundantSuppressionDetector)extension, manager, profile);
    for (CommonProblemDescriptor descriptor : descriptors) {
      if (descriptor instanceof ProblemDescriptor) {
	@@ -89,6 +81,18 @@ public void checkFile(@NotNull PsiFile file,
    }
  }

  private static InspectionProfileImpl getProfile(InspectionManager manager, GlobalInspectionContext globalContext) {
    if (globalContext instanceof GlobalInspectionContextBase) {
      InspectionProfileImpl profile = ((GlobalInspectionContextBase)globalContext).getCurrentProfile();
      if (profile.getSingleTool() == null) {
        return profile;
      }
    }
    String currentProfileName = ((InspectionManagerBase)manager).getCurrentProfile();
    InspectionProjectProfileManager profileManager = InspectionProjectProfileManager.getInstance(manager.getProject());
    return ObjectUtils.notNull(profileManager.getProfile(currentProfileName, false), profileManager.getCurrentProfile());
  }

  public ProblemDescriptor @NotNull [] checkElement(final @NotNull PsiFile psiElement,
                                                    RedundantSuppressionDetector extension,
                                                    final @NotNull InspectionManager manager,