<<>>>java/java-impl/src/com/intellij/refactoring/move/moveClassesOrPackages/DestinationFolderComboBox.java<<>>

<<>> 2 eb 2021<<>>

import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.ui.ComboBoxWithWidePopup;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Disposer;
import com.intellij.openapi.util.NlsContexts;
import com.intellij.openapi.util.Pass;
import com.intellij.openapi.vfs.VirtualFile;
	@@ -22,6 +23,7 @@
import com.intellij.refactoring.MoveDestination;
import com.intellij.refactoring.PackageWrapper;
import com.intellij.ui.*;
import com.intellij.util.Alarm;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

	@@ -36,9 +38,14 @@

public abstract class DestinationFolderComboBox extends ComboboxWithBrowseButton {
  private static final DirectoryChooser.ItemWrapper NULL_WRAPPER = new DirectoryChooser.ItemWrapper(null, null);

  private PsiDirectory myInitialTargetDirectory;
  private List<VirtualFile> mySourceRoots;
  private Project myProject;
  private boolean myLeaveInTheSameRoot;
  private Pass<String> myUpdateErrorMessage;

  private final Alarm myAlarm = new Alarm(Alarm.ThreadToUse.SWING_THREAD);
  public DestinationFolderComboBox() {
    super(new ComboBoxWithWidePopup());
  }
	@@ -53,6 +60,12 @@ protected boolean reportBaseInSourceSelectionInTest() {
    return false;
  }

  @Override
  public void removeNotify() {
    super.removeNotify();
    Disposer.dispose(myAlarm);
  }

  public void setData(final Project project,
                    final PsiDirectory initialTargetDirectory,
                    final EditorComboBox editorComboBox) {
	@@ -65,9 +78,12 @@ public void pass(String s) {

  public void setData(final Project project,
                      final PsiDirectory initialTargetDirectory,
                      final Pass<@NlsContexts.DialogMessage String> errorMessageUpdater, 
                      final EditorComboBox editorComboBox) {
    myInitialTargetDirectory = initialTargetDirectory;
    mySourceRoots = JavaProjectRootsUtil.getSuitableDestinationSourceRoots(project);
    myProject = project;
    myUpdateErrorMessage = errorMessageUpdater;
    String leaveInSameSourceRoot = JavaBundle.message("leave.in.same.source.root.item");
    new ComboboxSpeedSearch(getComboBox()) {
      @Override
	@@ -98,8 +114,8 @@ protected String getElementText(Object element) {
    final VirtualFile initialSourceRoot =
      initialTargetDirectory != null ? fileIndex.getSourceRootForFile(initialTargetDirectory.getVirtualFile()) : null;
    final VirtualFile[] selection = new VirtualFile[]{initialSourceRoot};
    myLeaveInTheSameRoot = initialTargetDirectory == null || 
                           initialSourceRoot != null && !fileIndex.isInLibrarySource(initialSourceRoot);
    addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
	@@ -115,7 +131,7 @@ public void actionPerformed(ActionEvent e) {
            return;
          }
        }
        setComboboxModel(root, root, true);
      }
    });

	@@ -127,15 +143,15 @@ public void documentChanged(@NotNull DocumentEvent e) {
        VirtualFile initialTargetDirectorySourceRoot = selectedItem != null && selectedItem != NULL_WRAPPER
                                                       ? fileIndex.getSourceRootForFile(selectedItem.getDirectory().getVirtualFile())
                                                       : initialSourceRoot;
        setComboboxModel(initialTargetDirectorySourceRoot, selection[0], false);
      }
    });
    setComboboxModel(initialSourceRoot, selection[0], false);
    getComboBox().addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        Object selectedItem = getComboBox().getSelectedItem();
        updateErrorMessage(fileIndex, selectedItem);
        if (selectedItem instanceof DirectoryChooser.ItemWrapper && selectedItem != NULL_WRAPPER) {
          PsiDirectory directory = ((DirectoryChooser.ItemWrapper)selectedItem).getDirectory();
          if (directory != null) {
	@@ -164,37 +180,40 @@ public MoveDestination selectDirectory(final PackageWrapper targetPackage, final
    return new AutocreatingSingleSourceRootMoveDestination(targetPackage, selectedDestination);
  }

  private void updateErrorMessage(ProjectFileIndex fileIndex, Object selectedItem) {
    myUpdateErrorMessage.pass(null);
    if (myInitialTargetDirectory != null && selectedItem instanceof DirectoryChooser.ItemWrapper && selectedItem != NULL_WRAPPER) {
      final PsiDirectory directory = ((DirectoryChooser.ItemWrapper)selectedItem).getDirectory();
      final boolean isSelectionInTestSourceContent = fileIndex.isInTestSourceContent(directory.getVirtualFile());
      final boolean inTestSourceContent = fileIndex.isInTestSourceContent(myInitialTargetDirectory.getVirtualFile());
      if (isSelectionInTestSourceContent != inTestSourceContent) {
        if (inTestSourceContent && reportBaseInTestSelectionInSource()) {
          myUpdateErrorMessage.pass(JavaBundle.message("destination.combo.source.root.not.expected.conflict"));
        }

        if (isSelectionInTestSourceContent && reportBaseInSourceSelectionInTest()) {
          myUpdateErrorMessage.pass(JavaBundle.message("destination.combo.test.root.not.expected.conflict"));
        }
      }
    }
  }

  private void setComboboxModel(final VirtualFile initialTargetDirectorySourceRoot,
                                final VirtualFile oldSelection,
                                final boolean forceIncludeAll) {
    myAlarm.cancelAllRequests();
    myAlarm.addRequest(() -> setComboboxModelInternal(initialTargetDirectorySourceRoot, oldSelection, forceIncludeAll), 300);
  }

  private void setComboboxModelInternal(final VirtualFile initialTargetDirectorySourceRoot,
                                        final VirtualFile oldSelection,
                                        final boolean forceIncludeAll) {
    ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();
    JComboBox comboBox = getComboBox();
    final LinkedHashSet<PsiDirectory> targetDirectories = new LinkedHashSet<>();
    final HashMap<PsiDirectory, String> pathsToCreate = new HashMap<>();
    MoveClassesOrPackagesUtil
      .buildDirectoryList(new PackageWrapper(PsiManager.getInstance(myProject), getTargetPackage()), mySourceRoots, targetDirectories, pathsToCreate);
    if (!forceIncludeAll && targetDirectories.size() > pathsToCreate.size()) {
      targetDirectories.removeAll(pathsToCreate.keySet());
    }
	@@ -212,7 +231,7 @@ else if (Comparing.equal(sourceRootForFile, oldSelection)) {
        oldOne = itemWrapper;
      }
    }
    if (myLeaveInTheSameRoot) {
      items.add(NULL_WRAPPER);
    }
    final DirectoryChooser.ItemWrapper selection = chooseSelection(initialTargetDirectorySourceRoot, fileIndex, items, initial, oldOne);
	@@ -235,7 +254,7 @@ else if (Comparing.equal(sourceRootForFile, oldSelection)) {
        }
      }
    }
    updateErrorMessage(fileIndex, selection);
    items.sort((o1, o2) -> {
      if (o1 == NULL_WRAPPER) return -1;
      if (o2 == NULL_WRAPPER) return 1;