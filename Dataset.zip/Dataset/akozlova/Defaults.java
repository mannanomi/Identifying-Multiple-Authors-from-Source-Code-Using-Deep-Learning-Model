<<>>java/java-tests/testData/inspection/emptyMethod/superCall/src/Defaults.java<<>>
<<>> 15 Jan 2021 <<>>
Interface1.super.foo();
    Interface2.super.foo();
  }
}

interface Interface4 {
  void foo();
}
interface Interface5 extends Interface1, Interface4 {
  @Override default void foo() { Interface1.super.foo(); }
}

interface Interface6 extends Interface1 {
  void foo();
}
interface Interface7 extends Interface1, Interface6 {
  @Override default void foo() { Interface1.super.foo(); }
}

class Main {
  public static void main(String args[]) {
    new Interface5() { }.foo();
    new Interface7() { }.foo();
  }
}