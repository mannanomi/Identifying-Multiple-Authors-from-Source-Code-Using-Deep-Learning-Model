<<>>java/java-impl/src/com/intellij/codeInsight/daemon/impl/quickfix/CreateClassFromNewFix.java<<>>
<<>> 19 Dec 2020 <<>>

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Segment;
import com.intellij.psi.*;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.ObjectUtils;
	@@ -206,7 +207,7 @@ protected boolean isValidElement(PsiElement element) {
  @Override
  protected boolean isAvailableImpl(int offset) {
    PsiNewExpression expression = getNewExpression();
    if (rejectContainer(expression)) {
      return false;
    }

	@@ -225,8 +226,20 @@ protected boolean isAvailableImpl(int offset) {
    return false;
  }

  protected boolean rejectContainer(PsiNewExpression expression) {
    if (expression.getQualifier() != null) {
      return true;
    }
    PsiJavaCodeReferenceElement classReference = expression.getClassOrAnonymousClassReference();
    if (classReference != null && classReference.isQualified()) {
      PsiJavaCodeReferenceElement containerReference = ObjectUtils.tryCast(classReference.getQualifier(), PsiJavaCodeReferenceElement.class);
      if (containerReference != null) {
        PsiElement targetClass = containerReference.resolve();
        return !(targetClass instanceof PsiClass) || !InheritanceUtil.hasEnclosingInstanceInScope((PsiClass)targetClass, expression, true, true);
      }
      return true;
    }
    return false;
  }

  protected @IntentionName String getText(final String varName) {