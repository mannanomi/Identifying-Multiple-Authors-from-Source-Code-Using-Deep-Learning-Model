<<>>platform/testRunner/src/com/intellij/execution/testframework/export/ExportTestResultsAction.java<<>>

<<>> 5 March 2021 <<>>

import javax.swing.*;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.xml.transform.*;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;
	@@ -114,8 +112,8 @@ public void actionPerformed(@NotNull AnActionEvent e) {
    }

    final File outputFile = getOutputFile(config, project, filename);
    final VirtualFile parent = outputFile.getParentFile().mkdirs() ? LocalFileSystem.getInstance().refreshAndFindFileByIoFile(outputFile.getParentFile()) 
                                                                   : null;
    if (parent == null || !parent.isValid()) {
      showBalloon(project, MessageType.ERROR, ExecutionBundle.message("export.test.results.failed", 
                                                                      Execl);
	@@ -246,36 +244,39 @@ private static void openEditorOrBrowser(final VirtualFile result, final Project
  }

  private boolean writeOutputFile(ExportTestResultsConfiguration config, File outputFile) throws IOException, TransformerException, SAXException {
    switch (config.getExportFormat()) {
      case Xml:
        TransformerHandler handler = ((SAXTransformerFactory)TransformerFactory.newInstance()).newTransformerHandler();
        handler.getTransformer().setOutputProperty(OutputKeys.INDENT, "yes");
        handler.getTransformer().setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");  // NON-NLS
        return transform(outputFile, handler);
      case BundledTemplate:
        try (InputStream bundledXsltUrl = getClass().getResourceAsStream("intellij-export.xsl")) {
          return transformWithXslt(outputFile, new StreamSource(bundledXsltUrl));
        }
      case UserTemplate:
        File xslFile = new File(config.getUserTemplatePath());
        if (!xslFile.isFile()) {
          showBalloon(myRunConfiguration.getProject(), MessageType.ERROR,
                      ExecutionBundle.message("export.test.results.custom.template.not.found", xslFile.getPath()), null);
          return false;
        }
        return transformWithXslt(outputFile, new StreamSource(xslFile));
      default:
        throw new IllegalArgumentException();
    }
  }

  private boolean transformWithXslt(File outputFile, Source xslSource)
    throws TransformerConfigurationException, IOException, SAXException {
    TransformerHandler handler = ((SAXTransformerFactory)TransformerFactory.newInstance()).newTransformerHandler(xslSource);
    handler.getTransformer().setParameter("TITLE", ExecutionBundle.message("export.test.results.filename", myRunConfiguration.getName(),
                                                                           m

    return transform(outputFile, handler);
  }

  private boolean transform(File outputFile, TransformerHandler handler) throws IOException, SAXException {
    try (FileWriter w = new FileWriter(outputFile, StandardCharsets.UTF_8)) {
      handler.setResult(new StreamResult(w));
      TestResultsXmlFormatter.execute(myModel.getRoot(), myRunConfiguration, myModel.getProperties(), handler);
                
        <<>> 5 March 2021 <<>>
            
            import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.ex.ActionUtil;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.WriteAction;
import com.intellij.openapi.diagnostic.Attachment;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileEditorManager;
	@@ -20,13 +21,11 @@
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.NlsContexts;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.ToolWindowManager;
import com.intellij.util.PathUtil;
	@@ -45,9 +44,10 @@
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public final class ExportTestResultsAction extends DumbAwareAction {
  private static final String ID = "ExportTestResults";
	@@ -113,7 +113,14 @@ public void actionPerformed(@NotNull AnActionEvent e) {
      ) != Messages.OK;
    }

    final File outputFile = getOutputFile(config, project, filename);
    outputFile.getParentFile().mkdirs();
    final VirtualFile parent = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(outputFile.getParentFile());
    if (parent == null || !parent.isValid()) {
      showBalloon(project, MessageType.ERROR, ExecutionBundle.message("export.test.results.failed", 
                                                                      ExecutionBundle.message("failed.to.create.output.file", outputFile.getPath())), null);
      return;
    }
    ProgressManager.getInstance().run(
      new Task.Backgroundable(project, ExecutionBundle.message("export.test.results.task.name"), false, new PerformInBackgroundOption() {
        @Override
	@@ -124,70 +131,61 @@ public boolean shouldStartInBackground() {
        @Override
        public void run(@NotNull ProgressIndicator indicator) {
          indicator.setIndeterminate(true);
          try {
            if (!writeOutputFile(config, outputFile)) return;
          }
          catch (IOException | SAXException | TransformerException ex) {
            LOG.warn(ex);
            showBalloon(project, MessageType.ERROR, ExecutionBundle.message("export.test.results.failed", ex.getMessage()), null);
            return;
          }
          catch (RuntimeException ex) {

            File tempFile;
            try {
              tempFile = FileUtil.createTempFile("", "_xml");
            }
            catch (IOException exception) {
              LOG.error("Failed to create temp file", exception);
              LOG.error("Failed to export test results", ex);
              return;
            }

            try {
              ExportTestResultsConfiguration c = new ExportTestResultsConfiguration();
              c.setExportFormat(ExportTestResultsConfiguration.ExportFormat.Xml);
              c.setOpenResults(false);
              writeOutputFile(c, tempFile);
            }
            catch (Throwable ignored) { }

            try {
              String content = FileUtil.loadFile(tempFile);
              LOG.error("Failed to export test results", ex, new Attachment("dump.xml", content));
            }
            catch (IOException exception) {
              LOG.error("Failed to export test results", ex);
            }
            FileUtil.delete(tempFile);
            return;
          }

          final Ref<VirtualFile> result = new Ref<>();
          final Ref<String> error = new Ref<>();
          ApplicationManager.getApplication().invokeAndWait(() -> {
            result.set(WriteAction.compute(() -> {
              try {
                VirtualFile child = parent.findChild(outputFile.getName());
                return child == null ? parent.createChildData(this, outputFile.getName()) : child;
              }
              catch (IOException e) {
                LOG.warn(e);
                error.set(e.getMessage());
                return null;
              }
            }));
          });


          if (!result.isNull()) {
            if (config.isOpenResults()) {
	@@ -247,8 +245,7 @@ private static void openEditorOrBrowser(final VirtualFile result, final Project
    });
  }

  private boolean writeOutputFile(ExportTestResultsConfiguration config, File outputFile) throws IOException, TransformerException, SAXException {
    ExportTestResultsConfiguration.ExportFormat exportFormat = config.getExportFormat();

    SAXTransformerFactory transformerFactory = (SAXTransformerFactory)SAXTransformerFactory.newInstance();
	@@ -270,7 +267,7 @@ private String getOutputText(ExportTestResultsConfiguration config) throws IOExc
        if (!xslFile.isFile()) {
          showBalloon(myRunConfiguration.getProject(), MessageType.ERROR,
                      ExecutionBundle.message("export.test.results.custom.template.not.found", xslFile.getPath()), null);
          return false;
        }
        xslSource = new StreamSource(xslFile);
      }
	@@ -279,15 +276,14 @@ private String getOutputText(ExportTestResultsConfiguration config) throws IOExc
                                                                             myRunConfiguration.getType().getDisplayName()));
    }

    try (FileWriter w = new FileWriter(outputFile, StandardCharsets.UTF_8)) {
      handler.setResult(new StreamResult(w));
      TestResultsXmlFormatter.execute(myModel.getRoot(), myRunConfiguration, myModel.getProperties(), handler);
      return true;
    }
    catch (ProcessCanceledException e) {
      return false;
    }
  }

  private void showBalloon(final Project project,
            
            
            