<<>>java/java-impl/src/com/intellij/refactoring/rename/RenameJavaMemberProcessor.java<<>>
<<>> 21 Nov 2020 <<>>

  protected static void findMemberHidesOuterMemberCollisions(final PsiMember member, final String newName, final List<? super UsageInfo> result) {
    if (member instanceof PsiCompiledElement) return;
    final PsiClass memberClass = member.getContainingClass();
    for (PsiClass aClass = memberClass != null ? memberClass.getContainingClass() : null; aClass != null; aClass = aClass.getContainingClass()) {
      if (member instanceof PsiMethod) {
        for (PsiMethod conflict : aClass.findMethodsByName(newName, true)) {
          findMemberHidesOuterMemberCollisions(member, conflict, memberClass, result);
        }
      }
      else {
        final PsiMember conflict = aClass.findFieldByName(newName, false);
        if (conflict == null) continue;
        findMemberHidesOuterMemberCollisions(member, conflict, memberClass, result);
      }
    }
  }

  private static void findMemberHidesOuterMemberCollisions(PsiMember member,
                                                           PsiMember anotherMember,
                                                           PsiClass memberClass, 
                                                           List<? super UsageInfo> result) {
    ReferencesSearch.search(anotherMember).forEach(reference -> {
      PsiElement refElement = reference.getElement();
      if (refElement instanceof PsiReferenceExpression && ((PsiReferenceExpression)refElement).isQualified()) return true;
      if (PsiTreeUtil.isAncestor(memberClass, refElement, false)) {
        MemberHidesOuterMemberUsageInfo info = new MemberHidesOuterMemberUsageInfo(refElement, member);
        result.add(info);
      }
      return true;
    });
  }

  protected static void qualifyOuterMemberReferences(final List<? extends MemberHidesOuterMemberUsageInfo> outerHides) throws IncorrectOperationException {
    for (MemberHidesOuterMemberUsageInfo usage : outerHides) {
      final PsiElement element = usage.getElement();