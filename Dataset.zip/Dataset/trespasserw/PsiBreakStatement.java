<<>>java/java-psi-api/src/com/intellij/psi/PsiBreakStatement.java<<>>
<<>> 21 Nov 2018<<>>

package com.intellij.psi;

import com.intellij.psi.util.PsiTreeUtil;
import org.jetbrains.annotations.Nullable;

/**
 * Represents a Java {@code break} statement.
 */
public interface PsiBreakStatement extends PsiStatement {
  /**
   * Returns the label expression iff it is present, is an unqualified reference, and the statement is not inside a switch expression,
   * {@code null} otherwise.
   */
  @Nullable PsiReferenceExpression getLabelExpression();

  /**
   * Returns the value expression iff it is present and the statement is inside a switch expression, {@code null} otherwise.
   */
  @Nullable PsiExpression getValueExpression();

  /**
   * Returns the label or value expression, or {@code null} if the statement is empty.
   *
   * @see #getLabelExpression()
   * @see #getValueExpression()
   */
  @Nullable PsiExpression getExpression();

	@@ -25,7 +33,15 @@
   */
  @Nullable PsiElement findExitedElement();

  /** @deprecated doesn't support switch expressions; use {@link #getLabelExpression()}} instead */
  @Deprecated
  @SuppressWarnings("DeprecatedIsStillUsed")
  default PsiIdentifier getLabelIdentifier() {
    PsiReferenceExpression expression = getLabelExpression();
    return expression != null ? PsiTreeUtil.getChildOfType(expression, PsiIdentifier.class) : null;
  }

  /** @deprecated doesn't support switch expressions; use {@link #findExitedElement()} instead */
  @Deprecated
  @SuppressWarnings("DeprecatedIsStillUsed")
  default PsiStatement findExitedStatement() 