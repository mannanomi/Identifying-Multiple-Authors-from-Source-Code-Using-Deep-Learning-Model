<<>>platform/platform-impl/src/com/intellij/diagnostic/DialogAppender.java<<>>
<<>> 3 March 2021 <<>>

package com.intellij.diagnostic;

import com.intellij.idea.Main;
import com.intellij.openapi.diagnostic.*;
import com.intellij.util.ExceptionUtil;
import com.intellij.util.concurrency.AppExecutorUtil;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;
	@@ -26,7 +24,7 @@
  private static final int MAX_EARLY_LOGGING_EVENTS = 5;
  private static final int MAX_ASYNC_LOGGING_EVENTS = 5;

  private final Queue<IdeaLoggingEvent> myEarlyEvents = new ArrayDeque<>();
  private final AtomicInteger myPendingAppendCounts = new AtomicInteger();
  private volatile Runnable myDialogRunnable;

	@@ -36,24 +34,34 @@ protected synchronized void append(@NotNull LoggingEvent event) {
      return;  // the dialog appender doesn't deal with non-critical errors and is meaningless when there is no frame to show an error icon
    }

    IdeaLoggingEvent ideaEvent;
    Object messageObject = event.getMessage();
    if (messageObject instanceof IdeaLoggingEvent) {
      ideaEvent = (IdeaLoggingEvent)messageObject;
    }
    else {
      ThrowableInformation info = event.getThrowableInformation();
      if (info == null || info.getThrowable() == null) return;
      ideaEvent = extractLoggingEvent(messageObject, info.getThrowable());
    }

    if (LoadingState.COMPONENTS_LOADED.isOccurred()) {
      IdeaLoggingEvent queued;
      while ((queued = myEarlyEvents.poll()) != null) queueAppend(queued);
      queueAppend(ideaEvent);
    }
    else if (myEarlyEvents.size() < MAX_EARLY_LOGGING_EVENTS) {
      myEarlyEvents.add(ideaEvent);
    }
  }

  private void queueAppend(IdeaLoggingEvent event) {
    if (myPendingAppendCounts.incrementAndGet() > MAX_ASYNC_LOGGING_EVENTS) {
      // Stop adding requests to the queue or we can get OOME on pending logging requests (IDEA-95327)
      myPendingAppendCounts.decrementAndGet(); // number of pending logging events should not increase
    }
    else {
      // Note, we MUST avoid SYNCHRONOUS invokeAndWait to prevent deadlocks
      SwingUtilities.invokeLater(() -> {
        try {
          appendToLoggers(event, LOGGERS);
	@@ -65,31 +73,20 @@ private void queueAppend(@NotNull LoggingEvent event) {
    }
  }

  void appendToLoggers(@NotNull IdeaLoggingEvent event, ErrorLogger @NotNull [] errorLoggers) {
    if (myDialogRunnable != null) {
      return;
    }

    for (int i = errorLoggers.length - 1; i >= 0; i--) {
      ErrorLogger logger = errorLoggers[i];
      if (!logger.canHandle(event)) {
        continue;
      }
      //noinspection NonAtomicOperationOnVolatileField
      myDialogRunnable = () -> {
        try {
          logger.handle(event);
        }
        finally {
          myDialogRunnable = null;
	@@ -137,4 +134,4 @@ public boolean requiresLayout() {

  @Override
  public void close() { }
}