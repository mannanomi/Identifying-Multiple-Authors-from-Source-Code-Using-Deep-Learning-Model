<<>>java/java-tests/testSrc/com/intellij/java/codeInsight/completion/SmartTypeCompletionTest.java<<>>
<<>> 21 Nov 2018<<>>

  public void testBreakLabel() {
    myFixture.configureByText(
      "a.java",
      "class a{{\n" +
      "  foo: while (true) break <caret>\n" +
      "}}");
    complete();
    myFixture.checkResult(
      "class a{{\n" +
      "  foo: while (true) break foo;<caret>\n" +
      "}}");
  }

  public void testContinueLabel() {
    myFixture.configureByText(
      "a.java",
      "class a{{\n" +
      "  foo: while (true) continue <caret>\n" +
      "}}");
    complete();
    myFixture.checkResult(
      "class a{{\n" +
      "  foo: while (true) continue foo;<caret>\n" +
      "}}");
  }