<<>>platform/bootstrap/src/com/intellij/ide/startup/StartupActionScriptManager.java<<>>
<<>> 17 March 2021 <<>>

package com.intellij.ide.startup;

import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.util.io.FileUtilRt;
import com.intellij.util.io.Decompressor;
import org.jetbrains.annotations.ApiStatus;
	@@ -60,23 +59,24 @@ public static synchronized void addActionCommands(@NotNull List<? extends Action
      for (ActionCommand command : commands) {
        command.execute();
      }
    }
    else {
      Path scriptFile = getActionScriptFile();
      List<ActionCommand> savedScript = loadActionScript(scriptFile);
      List<ActionCommand> script = new ArrayList<>(savedScript.size() + commands.size());
      script.addAll(savedScript);
      script.addAll(commands);
      try {
        saveActionScript(script, scriptFile);
      }
      catch (Throwable t) {
        try {
          saveActionScript(savedScript, scriptFile);
        }
        catch (Throwable tt) { t.addSuppressed(tt); }
        throw t;
      }
    }
  }

  private static Path getActionScriptFile() {
	@@ -104,15 +104,17 @@ else if (data instanceof List && ((List<?>)data).isEmpty()) {
    }
  }

  public static void saveActionScript(@NotNull List<ActionCommand> commands, @NotNull Path scriptFile) throws IOException {
    Files.createDirectories(scriptFile.getParent());
    try (ObjectOutput oos = new ObjectOutputStream(Files.newOutputStream(scriptFile))) {
      oos.writeObject(commands.toArray(new ActionCommand[0]));
    }
    catch (Throwable t) {
      try {
        Files.deleteIfExists(scriptFile);
      }
      catch (IOException e) { t.addSuppressed(e); }
      throw t;
    }
  }


<<>> 17 March 2021 <<>>

private static ActionCommand mapPaths(ActionCommand command, Path oldTarget, Path newTarget) {
    if (command instanceof CopyCommand) {
      Path destination = mapPath(((CopyCommand)command)._destination(), oldTarget, newTarget);
      if (destination != null) {
        return new CopyCommand(Paths.get(((CopyCommand)command)._source()), destination);
      }
    }
    else if (command instanceof UnzipCommand) {
	@@ -160,39 +160,51 @@ else if (command instanceof DeleteCommand) {
  public static final class CopyCommand implements Serializable, ActionCommand {
    private static final long serialVersionUID = 201708031943L;

    private final String mySource;
    private final String myDestination;
    @SuppressWarnings("FieldMayBeStatic") private final String source = null;
    @SuppressWarnings("FieldMayBeStatic") private final String destination = null;

    public CopyCommand(@NotNull Path source, @NotNull Path destination) {
      mySource = source.toAbsolutePath().toString();
      myDestination = destination.toAbsolutePath().toString();
    }

    /** @deprecated Use {@link #CopyCommand(Path, Path)} */
    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
    public CopyCommand(@NotNull File source, @NotNull File destination) {
      mySource = source.getAbsolutePath();
      myDestination = destination.getAbsolutePath();
    }

    @SuppressWarnings("ConstantConditions")
    private String _source() {
      return mySource != null ? mySource : source;
    }

    @SuppressWarnings("ConstantConditions")
    private String _destination() {
      return myDestination != null ? myDestination : destination;
    }

    @Override
    public void execute() throws IOException {
      Path source = Path.of(_source()), destination = Path.of(_destination());
      if (!Files.isRegularFile(source)) {
        throw new IOException("Source file missing: " + source);
      }
      Files.createDirectories(destination.getParent());
      Files.copy(source, destination);
    }

    @Override
    public String toString() {
      return "copy[" + _source() + ',' + _destination() + ']';
    }

    public String getSource() {
      return _source();
    }
  }

	@@ -231,7 +243,7 @@ public void execute() throws IOException {

    @Override
    public String toString() {
      return "unzip[" + mySource + ',' + myDestination + ',' + myFilenameFilter + ']';
    }

    public String getSource() {
	@@ -262,7 +274,7 @@ public void execute() throws IOException {

    @Override
    public String toString() {
      return "delete[" + mySource + ']';
    }
  }
}