<<>>platform/platform-api/src/com/intellij/openapi/ui/popup/util/PopupUtil.java<<>>
<<>> 17 Mar 2021 <<>>


package com.intellij.openapi.ui.popup.util;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.actionSystem.ActionButtonComponent;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
	@@ -22,6 +24,7 @@
import javax.swing.plaf.basic.ComboPopup;
import java.awt.*;
import java.awt.event.ComponentEvent;
import java.awt.event.InputEvent;
import java.lang.reflect.Method;

public final class PopupUtil {
	@@ -189,4 +192,20 @@ public static boolean handleEscKeyEvent() {
    }
    return true;
  }

  public static void showForActionButtonEvent(@NotNull JBPopup popup, @NotNull AnActionEvent e) {
    InputEvent inputEvent = e.getInputEvent();
    if (inputEvent == null) {
      popup.showInFocusCenter();
    }
    else {
      Component component = inputEvent.getComponent();
      if (component instanceof ActionButtonComponent) {
        popup.showUnderneathOf(component);
      }
      else {
        popup.showInCenterOf(component);
      }
    }
  }
}