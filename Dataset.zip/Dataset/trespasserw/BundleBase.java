<<>>platform/util-rt/src/com/intellij/BundleBase.java<<>>
<<>> 7 Dec 2018<<>>

  public static final char MNEMONIC = 0x1B;
  public static final String MNEMONIC_STRING = Character.toString(MNEMONIC);

  private static boolean assertOnMissedKeys = false;

  public static void assertOnMissedKeys(boolean doAssert) {
    assertOnMissedKeys = doAssert;
  }

  @NotNull
  public static String message(@NotNull ResourceBundle bundle, @NotNull String key, @NotNull Object... params) {
    return messageOrDefault(bundle, key, null, params);
  }

  public static String messageOrDefault(@Nullable ResourceBundle bundle,
                                        @NotNull String key,
	@@ -36,7 +45,7 @@ public static String messageOrDefault(@Nullable ResourceBundle bundle,
      }
      else {
        value = "!" + key + "!";
        if (assertOnMissedKeys) {
          assert false : "'" + key + "' is not found in " + bundle;
        }
      }
	@@ -56,59 +65,44 @@ public static String messageOrDefault(@Nullable ResourceBundle bundle,

  @NotNull
  public static String format(@NotNull String value, @NotNull Object... params) {
    return params.length > 0 && value.indexOf('{') >= 0 ? MessageFormat.format(value, params) : value;
  }

  public static String replaceMnemonicAmpersand(@Nullable String value) {
    if (value == null || value.indexOf('&') < 0) {
      return value;
    }

    StringBuilder builder = new StringBuilder();
    boolean macMnemonic = value.contains("&&");
    int i = 0;
    while (i < value.length()) {
      char c = value.charAt(i);
      if (c == '\\') {
        if (i < value.length() - 1 && value.charAt(i + 1) == '&') {
          builder.append('&');
          i++;
        }
        else {
          builder.append(c);
        }
      }
      else if (c == '&') {
        if (i < value.length() - 1 && value.charAt(i + 1) == '&') {
          if (SystemInfoRt.isMac) {
            builder.append(MNEMONIC);
          }
          i++;
        }
        else if (!SystemInfoRt.isMac || !macMnemonic) {
          builder.append(MNEMONIC);
        }
      }
      else {
        builder.append(c);
      }
      i++;
    }
    return builder.toString();
  }
}