<<>>platform/analysis-api/src/com/intellij/lang/annotation/HighlightSeverity.java<<>>
<<>> 5 Dec 2018 <<>>
// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.lang.annotation;

import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.JDOMExternalizerUtil;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;
import org.jetbrains.annotations.NotNull;

/**
 * Defines a highlighting severity level for an annotation.
 *
 * @author max
 * @see Annotation
 */
public class HighlightSeverity implements Comparable<HighlightSeverity> {
  public final String myName;
  public final int myVal;
	@@ -38,21 +22,18 @@
   */
  public static final HighlightSeverity INFORMATION = new HighlightSeverity("INFORMATION", 10);

  /**
   * The severity level for errors or warnings obtained from server.
   */
  public static final HighlightSeverity GENERIC_SERVER_ERROR_OR_WARNING = new HighlightSeverity("SERVER PROBLEM", 100);

  /**
   * The standard severity level for 'weak' :) warning annotations.
   */
  @Deprecated
  @SuppressWarnings("DeprecatedIsStillUsed")
  public static final HighlightSeverity INFO = new HighlightSeverity("INFO", 200);

  public static final HighlightSeverity WEAK_WARNING = new HighlightSeverity("WEAK WARNING", 200);

  /**
	@@ -66,8 +47,9 @@
  public static final HighlightSeverity ERROR = new HighlightSeverity("ERROR", 400);

  /**
   * Standard severity levels.
   */
  @SuppressWarnings("deprecation")
  public static final HighlightSeverity[] DEFAULT_SEVERITIES = {INFORMATION, GENERIC_SERVER_ERROR_OR_WARNING, INFO, WEAK_WARNING, WARNING, ERROR};

  /**
	@@ -78,28 +60,33 @@
   *             if two annotations with different severity levels cover the same text range, only
   *             the annotation with a higher severity level is displayed.
   */
  public HighlightSeverity(@NotNull String name, int val) {
    myName = name;
    myVal = val;
  }

  public HighlightSeverity(@NotNull Element element) {
    this(readField(element, "myName"), Integer.valueOf(readField(element, "myVal")));
  }

  private static String readField(Element element, String name) {
    String value = JDOMExternalizerUtil.readField(element, name);
    if (value == null) throw new IllegalArgumentException("Element '" + element + "' misses attribute '" + name + "'");
    return value;
  }

  @NotNull
  public String getName() {
    return myName;
  }

  @Override
  public int compareTo(@NotNull HighlightSeverity highlightSeverity) {
    return myVal - highlightSeverity.myVal;
  }

  @SuppressWarnings("deprecation")
  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
  }

	@@ -120,8 +107,8 @@ public int hashCode() {
    return 31 * result + myVal;
  }

  @Override
  public String toString() {
    return myName;
  }
}