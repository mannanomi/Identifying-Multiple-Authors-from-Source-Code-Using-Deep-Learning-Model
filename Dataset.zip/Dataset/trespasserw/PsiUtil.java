<<>>java/java-psi-api/src/com/intellij/psi/util/PsiUtil.java<<>>

<<>> 5 Dec 2018<<>>

PsiFile containingFile = element.getContainingFile();
    if (containingFile instanceof PsiClassOwner) {
      return StringUtil.isEmpty(((PsiClassOwner)containingFile).getPackageName());
    }

    if (containingFile instanceof JavaCodeFragment) {
      PsiElement context = containingFile.getContext();
      if (context instanceof PsiPackage) {
        return StringUtil.isEmpty(((PsiPackage)context).getName());
      }
      if (context != null && context != containingFile) {
        return isFromDefaultPackage(context);
      }
    }

    return false;