<<>>platform/platform-impl/src/com/intellij/openapi/updateSettings/impl/UpdateChecker.java<<>>
<<>> 25 Mar 2021 <<>>


import com.intellij.ide.plugins.marketplace.MarketplaceRequests
import com.intellij.notification.*
import com.intellij.notification.impl.NotificationsConfigurationImpl
import com.intellij.openapi.actionSystem.PlatformDataKeys
import com.intellij.openapi.application.*
import com.intellij.openapi.application.ex.ApplicationInfoEx
	@@ -62,15 +61,15 @@ object UpdateChecker {
  private const val DISABLED_PLUGIN_UPDATE = "plugin_disabled_updates.txt"
  private const val PRODUCT_DATA_TTL_MS = 300_000L

  private enum class NotificationKind { PLATFORM, PLUGINS, EXTERNAL }

  private val updateUrl: String
    get() = System.getProperty("idea.updates.url") ?: ApplicationInfoEx.getInstanceEx().updateUrls!!.checkingUrl

  private val productDataLock = ReentrantLock()
  private var productDataCache: SoftReference<Result<Product?>>? = null
  private val ourUpdatedPlugins: MutableMap<PluginId, PluginDownloader> = HashMap()
  private val ourShownNotifications = MultiMap<NotificationKind, Notification>()

  
   * Adding a plugin ID to this collection allows to exclude a plugin from a regular update check.
	@@ -518,7 +517,7 @@ object UpdateChecker {

    if (updatedChannel != null && newBuild != null) {
      if (userInitiated) {
        ourShownNotifications.remove(NotificationKind.PLATFORM)?.forEach { it.expire() }
      }

      val runnable = {
	@@ -535,11 +534,13 @@ object UpdateChecker {

        if (userInitiated) {
          IdeUpdateUsageTriggerCollector.trigger("notification.shown")
          val message = IdeBundle.message("updates.new.build.notification.title", ApplicationNamesInfo.getInstance().fullProductName, newBuild.version)
          showNotification(
            project, NotificationKind.PLATFORM, "ide.update.available", "", message,
            NotificationAction.createSimpleExpiring(IdeBundle.message("updates.notification.update.action")) {
              IdeUpdateUsageTriggerCollector.trigger("notification.clicked")
              runnable()
            })
        }
      }

	@@ -548,7 +549,7 @@ object UpdateChecker {

    if (enabledPlugins.isNotEmpty()) {
      if (userInitiated) {
        ourShownNotifications.remove(NotificationKind.PLUGINS)?.forEach { it.expire() }
      }

      val runnable = { PluginUpdateDialog(project, updatedPlugins, customRepoPlugins).show() }
	@@ -560,45 +561,36 @@ object UpdateChecker {
        UpdateSettingsEntryPointActionProvider.newPluginUpdates(updatedPlugins, customRepoPlugins)

        if (userInitiated) {
          val (title, message) = when (updatedPlugins.size) {
            1 -> "" to IdeBundle.message("updates.plugin.ready.title", updatedPlugins[0].pluginName)
            else -> IdeBundle.message("updates.plugins.ready.title") to updatedPlugins.joinToString { "\"${it.pluginName}\"" }
          }
          showNotification(
            project, NotificationKind.PLUGINS, "plugins.update.available", title, message,
            NotificationAction.createExpiring(IdeBundle.message("updates.all.plugins.action", updatedPlugins.size)) { e, _ ->
              PluginUpdateDialog.runUpdateAll(updatedPlugins, e.getData(PlatformDataKeys.CONTEXT_COMPONENT) as JComponent?, null)
            },
            NotificationAction.createSimpleExpiring(IdeBundle.message("updates.plugins.dialog.action"), runnable),
            NotificationAction.createSimpleExpiring(IdeBundle.message("updates.ignore.updates.link", updatedPlugins.size)) {
              ignorePlugins(updatedPlugins.map { it.descriptor })
            })
        }
      }
    }

    if (externalUpdates.isNotEmpty()) {
      ourShownNotifications.remove(NotificationKind.EXTERNAL)?.forEach { it.expire() }

      for (update in externalUpdates) {
        val runnable = { update.source.installUpdates(update.components) }
        if (forceDialog) {
          runnable()
        }
        else {
          val message = IdeBundle.message("updates.external.ready.message", update.components.size, update.components.joinToString(", "))
          showNotification(
            project, NotificationKind.EXTERNAL, "external.components.available", "", message,
            NotificationAction.createSimpleExpiring(IdeBundle.message("updates.notification.update.action"), runnable))
        }
      }
    }
	@@ -608,8 +600,8 @@ object UpdateChecker {
        NoUpdatesDialog(showSettingsLink).show()
      }
      else if (userInitiated) {
        val message = IdeBundle.message("updates.no.updates.notification")
        showNotification(project, NotificationKind.PLUGINS, "no.updates.available", "", message)
      }
    }
  }
	@@ -619,26 +611,18 @@ object UpdateChecker {
    NotificationsConfigurationImpl.getSettings(getNotificationGroup().displayId).displayType != NotificationDisplayType.NONE

  private fun showNotification(project: Project?,
                               kind: NotificationKind,
                               displayId: String,
                               @NlsContexts.NotificationTitle title: String,
                               @NlsContexts.NotificationContent message: String,
                               vararg actions: NotificationAction) {
    val type = if (kind == NotificationKind.PLATFORM) NotificationType.IDE_UPDATE else NotificationType.INFORMATION
    val notification = getNotificationGroup().createNotification(title, XmlStringUtil.wrapInHtml(message), type, null, displayId)
    notification.collapseActionsDirection = Notification.CollapseActionsDirection.KEEP_LEFTMOST
    notification.whenExpired { ourShownNotifications.remove(kind, notification) }
    actions.forEach { notification.addAction(it) }
    notification.notify(project)
    ourShownNotifications.putValue(kind, notification)
  }

  @JvmStatic


  <<>> 25 March 2021 <<>>

  else {
        UpdateSettingsEntryPointActionProvider.newPluginUpdates(updatedPlugins, customRepoPlugins)

        if (userInitiated) {
          val names = updatedPlugins.joinToString { downloader -> StringUtil.wrapWithDoubleQuote(downloader.pluginName) }
          val title = if (updatedPlugins.size == 1) IdeBundle.message("updates.plugin.ready.short.title.available", names)
          else IdeBundle.message("updates.plugins.ready.short.title.available")
          val message = if (updatedPlugins.size == 1) "" else names

          showNotification(project, title, message, runnable, { notification ->
            notification.actions[0].templatePresentation.text = IdeBundle.message("plugin.settings.link.title")
            val text = if (updatedPlugins.size == 1) IdeBundle.message("plugins.configurable.update.button")
            else IdeBundle.message("plugin.manager.update.all")
            notification.actions.add(0, object : NotificationAction(text) {
              override fun actionPerformed(e: AnActionEvent, notification: Notification) {
                notification.expire()
                PluginUpdateDialog.runUpdateAll(updatedPlugins, e.getData(PlatformDataKeys.CONTEXT_COMPONENT) as JComponent?, null)
              }
            })
            notification.addAction(object : NotificationAction(IdeBundle.message("updates.ignore.updates.link", updatedPlugins.size)) {
              override fun actionPerformed(e: AnActionEvent, notification: Notification) {
                notification.expire()
                ignorePlugins(updatedPlugins.map { it.descriptor })
              }
            })
          }, NotificationUniqueType.PLUGINS, "plugins.update.available")
        }
      }
    }
	

<< 25 March 2021 <<>>

        val names = updatedPlugins.joinToString { downloader -> StringUtil.wrapWithDoubleQuote(downloader.pluginName) }
        val title = if (updatedPlugins.size == 1) IdeBundle.message("updates.plugin.ready.short.title.available", names)
        else IdeBundle.message("updates.plugins.ready.short.title.available")
        val message = if (updatedPlugins.size == 1) "" else names

        showNotification(project, title, message, runnable, { notification ->
          notification.actions[0].templatePresentation.text = IdeBundle.message("plugin.settings.link.title")
          val text = if (updatedPlugins.size == 1) IdeBundle.message("plugins.configurable.update.button")
          else IdeBundle.message("plugin.manager.update.all")
          notification.actions.add(0, object : NotificationAction(text) {
            override fun actionPerformed(e: AnActionEvent, notification: Notification) {
              notification.expire()
              PluginUpdateDialog.runUpdateAll(updatedPlugins, e.getData(PlatformDataKeys.CONTEXT_COMPONENT) as JComponent?, null)
            }
          })
          notification.addAction(object : NotificationAction(IdeBundle.message("updates.ignore.updates.link", updatedPlugins.size)) {
            override fun actionPerformed(e: AnActionEvent, notification: Notification) {
              notification.expire()
              ignorePlugins(updatedPlugins.map { it.descriptor })
            }
          })
        }, NotificationUniqueType.PLUGINS, "plugins.update.available")
      }
    }


<<>> 17 March 2021 <<>>

import com.intellij.util.containers.MultiMap
import com.intellij.util.io.HttpRequests
import com.intellij.util.io.URLUtil
import com.intellij.util.ui.UIUtil
import com.intellij.xml.util.XmlStringUtil
import org.jdom.JDOMException
  @@ -43,7 +42,7 @@ import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.nio.file.Files
import java.nio.file.Path
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
  @@ -57,6 +56,7 @@ object UpdateChecker {
  private val LOG = logger<UpdateChecker>()

  private const val DISABLED_UPDATE = "disabled_update.txt"
  private const val DISABLED_PLUGIN_UPDATE = "plugin_disabled_updates.txt"
  private const val PRODUCT_DATA_TTL_MS = 300_000L

  private enum class NotificationUniqueType { PLATFORM, PLUGINS, EXTERNAL }
  @@ -66,8 +66,6 @@ object UpdateChecker {

  private val productDataLock = ReentrantLock()
  private var productDataCache: SoftReference<Product>? = null
  private val ourUpdatedPlugins: MutableMap<PluginId, PluginDownloader> = HashMap()
  private val ourShownNotifications = MultiMap<NotificationUniqueType, Notification>()

  @@ -548,16 +546,10 @@ object UpdateChecker {
    }
  }

  private fun getAllUpdatedPlugins(pluginUpdates: CheckPluginsUpdateResult): List<PluginDownloader> =
    ((pluginUpdates.availableUpdates ?: emptyList()).asSequence() + pluginUpdates.availableDisabledUpdates.asSequence())
      .filter { !isIgnored(it.descriptor) }
      .toList()

  private fun showUpdateResult(project: Project?,
                               checkForUpdateResult: CheckForUpdateResult,
  @@ -629,7 +621,7 @@ object UpdateChecker {
          notification.addAction(object : NotificationAction(IdeBundle.message("updates.ignore.updates.link", updatedPlugins.size)) {
            override fun actionPerformed(e: AnActionEvent, notification: Notification) {
              notification.expire()
              ignorePlugins(updatedPlugins.map { it.descriptor })
            }
          })
        }, NotificationUniqueType.PLUGINS, "plugins.update.available")
  @@ -698,40 +690,42 @@ object UpdateChecker {
  }

  @JvmStatic
  val disabledToUpdate: Set<PluginId> by lazy { TreeSet(readConfigLines(DISABLED_UPDATE).map { PluginId.getId(it) }) }

  @JvmStatic
  fun saveDisabledToUpdatePlugins() {
    runCatching { DisabledPluginsState.savePluginsList(disabledToUpdate, Path.of(PathManager.getConfigPath(), DISABLED_UPDATE)) }
      .onFailure { LOG.error(it) }
  }

  @JvmStatic
  fun isIgnored(descriptor: IdeaPluginDescriptor): Boolean =
    descriptor.ignoredKey in ignoredPlugins

  @JvmStatic
  @JvmName("ignorePlugins")
  internal fun ignorePlugins(descriptors: List<IdeaPluginDescriptor>) {
    ignoredPlugins += descriptors.map { it.ignoredKey }
    runCatching { Files.write(Path.of(PathManager.getConfigPath(), DISABLED_PLUGIN_UPDATE), ignoredPlugins) }
      .onFailure { LOG.error(it) }
    SettingsEntryPointAction.removePluginsUpdate(descriptors)
  }

  private val ignoredPlugins: MutableSet<String> by lazy { TreeSet(readConfigLines(DISABLED_PLUGIN_UPDATE)) }

  private val IdeaPluginDescriptor.ignoredKey: String
    get() = "${pluginId.idString}+${version}"

  private fun readConfigLines(fileName: String): List<String> {
    if (!ApplicationManager.getApplication().isUnitTestMode) {
      runCatching {
        val file = Path.of(PathManager.getConfigPath(), fileName)
        if (Files.isRegularFile(file)) {
          return Files.readAllLines(file)
        }
      }.onFailure { LOG.error(it) }
    }
    return emptyList()
  }

  private var ourHasFailedPlugins = false
  
    
