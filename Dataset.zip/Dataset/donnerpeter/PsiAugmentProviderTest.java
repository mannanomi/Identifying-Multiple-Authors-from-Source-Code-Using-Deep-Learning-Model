<<>>java/java-tests/testSrc/com/intellij/java/codeInsight/daemon/PsiAugmentProviderTest.java<<>>
<<>> 14 Aug 2020 <<>>

import com.intellij.JavaTestUtil;
import com.intellij.codeInsight.daemon.impl.analysis.JavaGenericsUtil;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.psi.*;
import com.intellij.psi.augment.PsiAugmentProvider;
import com.intellij.psi.impl.light.LightFieldBuilder;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.util.PsiUtilCore;
import com.intellij.psi.util.TypeConversionUtil;
import com.intellij.testFramework.fixtures.LightJavaCodeInsightFixtureTestCase;
import com.intellij.util.ref.GCUtil;
	@@ -65,6 +67,20 @@ public void testDuplicatesFromSeveralAugmenterCallsAreIgnored() {
    assertSame(field, psiClass.findFieldByName(AUGMENTED_FIELD, false));
  }

  public void testDoNotCacheInvalidAugmentedFields() {
    PsiClass psiClass = myFixture.addClass("class C {}");

    WriteCommandAction.runWriteCommandAction(getProject(), () -> {
      PsiField field = psiClass.findFieldByName(AUGMENTED_FIELD, false);
      assertTrue(field.isValid());

      getPsiManager().dropPsiCaches();
      assertFalse(field.isValid());

      PsiUtilCore.ensureValid(psiClass.findFieldByName(AUGMENTED_FIELD, false));
    });
  }

  private static class TestAugmentProvider extends PsiAugmentProvider {
    private static final String LOMBOK_VAL_FQN = "lombok.val";
    private static final String LOMBOK_VAL_SHORT_NAME = "val";
	@@ -113,9 +129,11 @@ protected PsiType inferType(@NotNull PsiTypeElement typeElement) {
    protected @NotNull <Psi extends PsiElement> List<Psi> getAugments(@NotNull PsiElement element,
                                                                      @NotNull Class<Psi> type,
                                                                      @Nullable String nameHint) {
      var manager = element.getManager();
      var count = manager.getModificationTracker().getModificationCount();
      if (type.equals(PsiField.class)) {
        //noinspection unchecked
        return (List<Psi>)Collections.singletonList(new LightFieldBuilder(manager, AUGMENTED_FIELD, PsiType.BOOLEAN) {
          @Override
          public int hashCode() {
            return 0;
	@@ -125,6 +143,11 @@ public int hashCode() {
          public boolean equals(Object obj) {
            return obj.getClass() == getClass();
          }

          @Override
          public boolean isValid() {
            return count == manager.getModificationTracker().getModificationCount();
          }
        });
      }
      return super.getAugments(element, type, nameHint);
	