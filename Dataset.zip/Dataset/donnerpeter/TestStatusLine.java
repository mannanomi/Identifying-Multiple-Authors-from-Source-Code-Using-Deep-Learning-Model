<<>>platform/testRunner/src/com/intellij/execution/testframework/ui/TestStatusLine.java<<>>
<<>> 11 Sep 2020 <<>>


import com.intellij.execution.testframework.TestIconMapper;
import com.intellij.execution.testframework.TestRunnerBundle;
import com.intellij.execution.testframework.sm.runner.states.TestStateInfo;
import com.intellij.icons.AllIcons;
import com.intellij.openapi.progress.util.ColorProgressBar;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.ui.SimpleColoredComponent;
import com.intellij.ui.SimpleTextAttributes;
import com.intellij.ui.components.panels.NonOpaquePanel;
import com.intellij.util.ui.EdtInvocationManager;
import com.intellij.util.ui.JBDimension;
import com.intellij.util.ui.JBUI;
import com.intellij.util.ui.UIUtil;
import org.jetbrains.annotations.*;

	@@ -42,7 +44,7 @@
  protected final JProgressBar myProgressBar = new JProgressBar();
  protected final SimpleColoredComponent myState = new SimpleColoredComponent();
  private final JPanel myProgressPanel;
  private final JLabel myWarning = new JLabel();

  public TestStatusLine() {
    super(new BorderLayout());
	@@ -52,9 +54,17 @@ public TestStatusLine() {
    myProgressBar.putClientProperty("ProgressBar.stripeWidth", 3);
    myProgressBar.putClientProperty("ProgressBar.flatEnds", Boolean.TRUE);
    setStatusColor(ColorProgressBar.GREEN);

    JPanel stateWrapper = new NonOpaquePanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    myState.setOpaque(false);
    stateWrapper.add(myState);

    myWarning.setOpaque(false);
    myWarning.setVisible(false);
    myWarning.setIcon(AllIcons.General.Warning);
    myWarning.setBorder(JBUI.Borders.emptyLeft(10));
    stateWrapper.add(myWarning);

    add(stateWrapper, BorderLayout.CENTER);
    myState.append(ExecutionBundle.message("junit.runing.info.starting.label"));
  }
	@@ -65,7 +75,14 @@ public void formatTestMessage(final int testsTotal,
                                final int ignoredTestsCount,
                                final Long duration,
                                final long endTime) {
    UIUtil.invokeLaterIfNeeded(() -> {
      doFormatTestMessage(testsTotal, finishedTestsCount, failuresCount, ignoredTestsCount, duration, endTime);
      updateWarningVisibility();
    });
  }

  private void updateWarningVisibility() {
    myWarning.setVisible(myState.getCharSequence(false).length() > 0 && StringUtil.isNotEmpty(myWarning.getText()));
  }

  private void doFormatTestMessage(int testsTotal,
	@@ -83,7 +100,6 @@ private void doFormatTestMessage(int testsTotal,
    if (duration == null || endTime == 0) {
      //running tests
      formatCounts(failuresCount, ignoredTestsCount, passedCount, testsTotal);
      return;
    }

	@@ -96,7 +112,6 @@ private void doFormatTestMessage(int testsTotal,
    formatCounts(failuresCount, ignoredTestsCount, passedCount, testsTotal);

    myState.append(" – " + StringUtil.formatDuration(duration, "\u2009"), SimpleTextAttributes.GRAY_ATTRIBUTES);
  }

  private void formatCounts(int failuresCount, int ignoredTestsCount, int passedCount, int testsTotal) {
	@@ -173,7 +188,7 @@ public void setText(@Nls String progressStatus_text) {
    UIUtil.invokeLaterIfNeeded(() -> {
      myState.clear();
      myState.append(progressStatus_text);
      myWarning.setVisible(!progressStatus_text.isEmpty());
    });
  }

	@@ -184,7 +199,8 @@ public String getStateText() {
  }

  @ApiStatus.Internal
  public void setWarning(@Nls @NotNull String suffix) {
    myWarning.setText(suffix);
    updateWarningVisibility();
  }
}