<<>>platform/lang-impl/src/com/intellij/refactoring/move/moveFilesOrDirectories/MoveFilesOrDirectoriesProcessor.java<<>>
<<>> 24 Sep 2020<<>>


import com.intellij.ide.util.EditorHelper;
import com.intellij.lang.FileASTNode;
import com.intellij.model.BranchableUsageInfo;
import com.intellij.model.ModelBranch;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.paths.PsiDynaReference;
	@@ -27,6 +29,7 @@
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.ObjectUtils;
import com.intellij.util.containers.ContainerUtil;
import one.util.streamex.EntryStream;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

	@@ -81,11 +84,10 @@ protected UsageViewDescriptor createUsageViewDescriptor(UsageInfo @NotNull [] us
  @Override
  protected UsageInfo @NotNull [] findUsages() {
    List<UsageInfo> result = new ArrayList<>();
    for (PsiElement element : myElementsToMove) {
      if (mySearchForReferences) {
        for (PsiReference reference : ReferencesSearch.search(element, GlobalSearchScope.projectScope(myProject))) {
          result.add(new MyUsageInfo(reference, element));
        }
      }
      findElementUsages(result, element);
	@@ -127,19 +129,51 @@ protected void performPsiSpoilingRefactoring() {
  }

  @Override
  protected boolean canPerformRefactoringInBranch() {
    return getClass() == MoveFilesOrDirectoriesProcessor.class;
  }

  @Override
  protected void performRefactoring(UsageInfo @NotNull [] usages) {
    performRefactoringInBranch(usages, null);
  }

  @Override
  protected void performRefactoringInBranch(UsageInfo @NotNull [] _usages, @Nullable ModelBranch branch) {
    try {
      List<PsiElement> toChange = new ArrayList<>();
      for (PsiElement element : myElementsToMove) {
        if (branch != null) {
          element = branch.obtainPsiCopy(element);
        }
        toChange.add(element);
      }

      PsiDirectory newParent = branch != null ? branch.obtainPsiCopy(myNewParent) : myNewParent;

      List<UsageInfo> codeUsages = new ArrayList<>();
      List<NonCodeUsageInfo> nonCodeUsages = new ArrayList<>();
      for (UsageInfo usage : _usages) {
        if (branch != null) {
          usage = ((BranchableUsageInfo) usage).obtainBranchCopy(branch);
        }
        if (usage instanceof NonCodeUsageInfo) {
          nonCodeUsages.add((NonCodeUsageInfo)usage);
        }
        else {
          codeUsages.add(usage);
        }
      }

      Map<PsiFile, List<UsageInfo>> foundUsages = branch == null ? myFoundUsages : EntryStream
        .of(myFoundUsages)
        .mapValues(infos -> ContainerUtil.map(infos, info -> ((BranchableUsageInfo) info).obtainBranchCopy(branch)))
        .toMap();

      Map<SmartPsiElementPointer<PsiFile>, FileASTNode> movedFiles = new LinkedHashMap<>();
      final Map<PsiElement, PsiElement> oldToNewMap = new HashMap<>();
      if (mySearchForReferences) {
        for (PsiElement element : toChange) {
          if (element instanceof PsiDirectory) {
            encodeDirectoryFiles(element, movedFiles);
          }
	@@ -151,36 +185,50 @@ else if (element instanceof PsiFile) {

      List<RefactoringElementListener> listeners = ContainerUtil.map(myElementsToMove, item -> getTransaction().getElementListener(item));

      List<Runnable> notifyListeners = new ArrayList<>();
      for (int i = 0; i < myElementsToMove.length; i++) {
        PsiElement element = toChange.get(i);
        if (element instanceof PsiDirectory) {
          MoveFilesOrDirectoriesUtil.doMoveDirectory((PsiDirectory)element, newParent);
          for (PsiElement psiElement : element.getChildren()) {
            processDirectoryFiles(movedFiles, oldToNewMap, psiElement);
          }
        }
        else if (element instanceof PsiFile) {
          final PsiFile movedFile = (PsiFile)element;
          FileASTNode node = movedFile.getNode();
          MoveFileHandler.forElement(movedFile).prepareMovedFile(movedFile, newParent, oldToNewMap);

          PsiFile moving = newParent.findFile(movedFile.getName());
          if (moving == null) {
            MoveFilesOrDirectoriesUtil.doMoveFile(movedFile, newParent);
          }
          moving = newParent.findFile(movedFile.getName());
          if (moving != null) {
            movedFiles.put(SmartPointerManager.createPointer(moving), moving.getNode());
            ObjectUtils.reachabilityFence(node);
          }
        }

        if (element.isValid()) {
          RefactoringElementListener listener = listeners.get(i);
          SmartPsiElementPointer<PsiElement> pointer = SmartPointerManager.createPointer(element);
          notifyListeners.add(() -> {
            PsiElement restored = pointer.getElement();
            if (branch != null && restored != null) restored = branch.findOriginalPsi(restored);
            if (restored != null) {
              listener.elementMoved(restored);
            }
          });
        }
      }
      // sort by offset descending to process correctly several usages in one PsiElement [IDEADEV-33013]
      UsageInfo[] usages = codeUsages.toArray(UsageInfo.EMPTY_ARRAY);
      CommonRefactoringUtil.sortDepthFirstRightLeftOrder(usages);

      if (branch == null) {
        DumbService.getInstance(myProject).completeJustSubmittedTasks();
      }

      // fix references in moved files to outer files
      for (SmartPsiElementPointer<PsiFile> pointer : movedFiles.keySet()) {
	@@ -193,18 +241,24 @@ else if (element instanceof PsiFile) {

      retargetUsages(usages, oldToNewMap);

      for (Map.Entry<PsiFile, List<UsageInfo>> entry : foundUsages.entrySet()) {
        MoveFileHandler.forElement(entry.getKey()).retargetUsages(entry.getValue(), oldToNewMap);
      }

      if (branch != null) {
        RenameUtil.renameNonCodeUsages(myProject, nonCodeUsages.toArray(new NonCodeUsageInfo[0]));
      } else {
        myNonCodeUsages = nonCodeUsages.toArray(new NonCodeUsageInfo[0]);
      }

      if (branch != null) {
        branch.runAfterMerge(() -> {
          PsiDocumentManager.getInstance(myProject).commitAllDocuments();
          afterMove(branch, movedFiles.keySet(), notifyListeners);
        });
      } else {
        afterMove(null, movedFiles.keySet(), notifyListeners);
      }
    }
    catch (IncorrectOperationException e) {
      Throwable cause = e.getCause();
	@@ -219,6 +273,21 @@ else if (element instanceof PsiFile) {
    }
  }

  private void afterMove(@Nullable ModelBranch branch, Set<SmartPsiElementPointer<PsiFile>> movedFiles, List<Runnable> notifyListeners) {
    notifyListeners.forEach(Runnable::run);
    if (myMoveCallback != null) {
      myMoveCallback.refactoringCompleted();
    }
    if (MoveFilesOrDirectoriesDialog.isOpenInEditorProperty()) {
      List<PsiFile> justFiles = ContainerUtil.mapNotNull(movedFiles, pointer -> {
        PsiFile element = pointer.getElement();
        return branch == null || element == null ? element : branch.findOriginalPsi(element);
      });
      ApplicationManager.getApplication().invokeLater(
        () -> EditorHelper.openFilesInEditor(justFiles.stream().filter(PsiElement::isValid).toArray(PsiFile[]::new)));
    }
  }

  @Nullable
  @Override
  protected String getRefactoringId() {
	@@ -267,11 +336,10 @@ else if (psiElement instanceof PsiDirectory) {
  }

  protected void retargetUsages(UsageInfo @NotNull [] usages, @NotNull Map<PsiElement, PsiElement> oldToNewMap) {
    for (UsageInfo usageInfo : usages) {
      if (usageInfo instanceof MyUsageInfo) {
        final MyUsageInfo info = (MyUsageInfo)usageInfo;
        PsiElement element = info.myTarget;

        if (info.getReference() instanceof FileReference || info.getReference() instanceof PsiDynaReference) {
          final PsiElement usageElement = info.getElement();
	@@ -287,16 +355,8 @@ protected void retargetUsages(UsageInfo @NotNull [] usages, @NotNull Map<PsiElem
        if (refElement.isValid()) {
          info.myReference.bindToElement(element);
        }
      }
    }
  }

  @NotNull
	@@ -311,14 +371,19 @@ protected boolean shouldDisableAccessChecks() {
    return true;
  }

  private static class MyUsageInfo extends UsageInfo implements BranchableUsageInfo {
    private final PsiElement myTarget;
    final PsiReference myReference;

    MyUsageInfo(@NotNull PsiReference reference, @NotNull PsiElement target) {
      super(reference);
      myReference = reference;
      myTarget = target;
    }

    @Override
    public @NotNull UsageInfo obtainBranchCopy(@NotNull ModelBranch branch) {
      return new MyUsageInfo(branch.obtainReferenceCopy(myReference), branch.obtainPsiCopy(myTarget));
    }
  }
}