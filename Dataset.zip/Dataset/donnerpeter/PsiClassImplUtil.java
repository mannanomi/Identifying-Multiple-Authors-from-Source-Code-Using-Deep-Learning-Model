<<>>java/java-psi-impl/src/com/intellij/psi/impl/PsiClassImplUtil.java<<>>
<<>> 7 Aug 2020 <<>>


 return byMap.isEmpty() ? null : (PsiClass)byMap.get(0);
  }

  public static boolean processAllMembersWithoutSubstitutors(@NotNull PsiClass psiClass, @NotNull PsiScopeProcessor processor, @NotNull ResolveState state) {
    ElementClassHint classHint = processor.getHint(ElementClassHint.KEY);

    NameHint nameHint = processor.getHint(NameHint.KEY);
    String name = nameHint == null ? null : nameHint.getName(state);

    if ((classHint == null || classHint.shouldProcess(ElementClassHint.DeclarationKind.METHOD)) &&
        !processMembers(state, processor, getMap(psiClass, MemberType.METHOD).get(name == null ? ALL : name))) {
      return false;
    }
    if ((classHint == null || classHint.shouldProcess(ElementClassHint.DeclarationKind.FIELD)) &&
        !processMembers(state, processor, getMap(psiClass, MemberType.FIELD).get(name == null ? ALL : name))) {
      return false;
    }
    if ((classHint == null || classHint.shouldProcess(ElementClassHint.DeclarationKind.CLASS)) &&
        !processMembers(state, processor, getMap(psiClass, MemberType.CLASS).get(name == null ? ALL : name))) {
      return false;
    }
    return true;
  }

  private static boolean processMembers(ResolveState state, PsiScopeProcessor processor, PsiMember @Nullable[] members) {
    if (members == null) return true;
    for (PsiMember member : members) {
      if (!processor.execute(member, state)) {
        return false;
      }
    }
    return true;
  }

  @NotNull
  private static List<PsiMember> findByMap(@NotNull PsiClass aClass, String name, boolean checkBases, @NotNull MemberType type) {
    if (name == null) return Collections.emptyList();
	@@ -630,9 +661,7 @@ private static boolean processClassMembersWithAllNames(@NotNull PsiClass aClass,
    ElementClassHint classHint = processor.getHint(ElementClassHint.KEY);

    if (classHint == null || classHint.shouldProcess(ElementClassHint.DeclarationKind.FIELD)) {
      if (!processMembers(state, processor, aClass.getFields())) return false;
    }

    PsiElementFactory factory = JavaPsiFacade.getElementFactory(aClass.getProject());
	@@ -654,9 +683,7 @@ private static boolean processClassMembersWithAllNames(@NotNull PsiClass aClass,
      }

      if (!(last instanceof PsiReferenceList) && !(last instanceof PsiModifierList)) {
        if (!processMembers(state, processor, aClass.getInnerClasses())) return false;
      }
    }