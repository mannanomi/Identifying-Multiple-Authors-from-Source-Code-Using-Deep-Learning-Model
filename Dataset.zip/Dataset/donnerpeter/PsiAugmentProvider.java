<<>>java/java-psi-api/src/com/intellij/psi/augment/PsiAugmentProvider.java<<>>
<<>> 11 Sep 2020 <<>>


import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Some code is not what it seems to be!
	@@ -80,6 +81,14 @@ protected PsiType inferType(@NotNull PsiTypeElement typeElement) {
    return null;
  }

  /**
   * @return whether this extension might infer the type for the given PSI,
   * preferably checked in a lightweight way without actually inferring the type.
   */
  protected boolean canInferType(@NotNull PsiTypeElement typeElement) {
    return inferType(typeElement) != null;
  }

  /**
   * Intercepts {@link PsiModifierList#hasModifierProperty(String)}, so that plugins can add imaginary modifiers or hide existing ones.
   */
	@@ -155,6 +164,20 @@ public static PsiType getInferredType(@NotNull PsiTypeElement typeElement) {
    return result.get();
  }

  public static boolean isInferredType(@NotNull PsiTypeElement typeElement) {
    AtomicBoolean result = new AtomicBoolean();

    forEach(typeElement.getProject(), provider -> {
      boolean canInfer = provider.canInferType(typeElement);
      if (canInfer) {
        result.set(true);
      }
      return !canInfer;
    });

    return result.get();
  }

  @NotNull
  public static Set<String> transformModifierProperties(@NotNull PsiModifierList modifierList,
                                                        @NotNull Project project,