<<>>platform/lang-impl/src/com/intellij/codeInsight/template/impl/LiveTemplateTree.java<<>>
<<>> 9 Oct 2020 <<>>

package com.intellij.codeInsight.template.impl;

import com.intellij.ide.CopyProvider;
import com.intellij.ide.DeleteProvider;
import com.intellij.ide.PasteProvider;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.DataProvider;
	@@ -30,7 +31,7 @@
/**
 * @author peter
 */
class LiveTemplateTree extends CheckboxTree implements DataProvider, CopyProvider, PasteProvider, DeleteProvider {
  private final TemplateListPanel myConfigurable;

  LiveTemplateTree(final CheckboxTreeCellRenderer renderer, final CheckedTreeNode root, TemplateListPanel configurable) {
	@@ -70,7 +71,9 @@ protected void installSpeedSearch() {
  @Nullable
  @Override
  public Object getData(@NotNull @NonNls String dataId) {
    if (PlatformDataKeys.COPY_PROVIDER.is(dataId) ||
        PlatformDataKeys.PASTE_PROVIDER.is(dataId) ||
        PlatformDataKeys.DELETE_ELEMENT_PROVIDER.is(dataId)) {
      return this;
    }
    return null;
	@@ -136,6 +139,16 @@ public void performPaste(@NotNull DataContext dataContext) {
    }
  }

  @Override
  public void deleteElement(@NotNull DataContext dataContext) {
    myConfigurable.removeRows();
  }

  @Override
  public boolean canDeleteElement(@NotNull DataContext dataContext) {
    return !myConfigurable.getSelectedTemplates().isEmpty();
  }

  private static class SubstringSpeedSearchComparator extends SpeedSearchComparator {
    @Override
    public int matchingDegree(String pattern, String text) {