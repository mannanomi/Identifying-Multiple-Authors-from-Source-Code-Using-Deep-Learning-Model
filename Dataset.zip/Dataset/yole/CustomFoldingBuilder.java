<<>> platform/core-api/src/com/intellij/lang/folding/CustomFoldingBuilder.java <<>>
<<>> 7 Jan 2021 <<>>

 @Override
  public final boolean isCollapsedByDefault(@NotNull FoldingDescriptor descriptor) {
    if (isCustomRegionStart(descriptor.getElement())) {
      return isCustomRegionCollapsedByDefault(descriptor.getElement());
    }
    return isRegionCollapsedByDefault(descriptor);
  }

  private boolean isCustomRegionCollapsedByDefault(@NotNull ASTNode node) {
    String childText = node.getText();
    CustomFoldingProvider defaultProvider = getDefaultProvider(childText);
    return defaultProvider != null && defaultProvider.isCollapsedByDefault(childText);
  }