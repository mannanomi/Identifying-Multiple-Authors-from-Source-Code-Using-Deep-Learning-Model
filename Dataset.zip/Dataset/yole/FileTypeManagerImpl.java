<<>>platform/platform-impl/src/com/intellij/openapi/fileTypes/impl/FileTypeManagerImpl.java<<>>
<<>> 10 April 2021 <<>>

private static void handleFileTypesConflict(FileTypeBean bean, FileTypeBean otherBean) {
    Application application = ApplicationManager.getApplication();
    if (application != null) {
      PluginConflictReporter conflictReporter = application.getService(PluginConflictReporter.class);
      if (conflictReporter != null) {
        Set<PluginId> conflictingPlugins = new HashSet<>();
        if (bean.getPluginId() != null) {
          conflictingPlugins.add(bean.getPluginId());
        }
        if (otherBean.getPluginId() != null) {
          conflictingPlugins.add(otherBean.getPluginId());
        }
        boolean hasConflictWithPlatform = bean.getPluginId() == null || otherBean.getPluginId() == null;
        conflictReporter.reportConflict(conflictingPlugins, hasConflictWithPlatform);
        return;
      }
    }

    LOG.error(new PluginException("Trying to override already registered file type '" + bean.name + "'", bean.getPluginId()));
  }