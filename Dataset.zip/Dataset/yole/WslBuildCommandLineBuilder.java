<<>>java/compiler/impl/src/com/intellij/compiler/server/WslBuildCommandLineBuilder.java<<>>
<<>> 24 Mar 2021 <<>>


 @Override
  public void copyPathToTarget(File file) {
    if (myClasspathDirectory != null && myHostClasspathDirectory != null) {
      Path targetPath = myHostClasspathDirectory.resolve(file.getName());
      if (!targetPath.toFile().exists()) {
        try {
          FileUtil.copyFileOrDir(file, targetPath.toFile());
        }
        catch (IOException e) {
          // ignore
        }
      }
    }
  }

