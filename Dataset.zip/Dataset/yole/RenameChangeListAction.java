<<>>platform/vcs-impl/src/com/intellij/openapi/vcs/changes/actions/RenameChangeListAction.java<<>>

<<>> 9 May 2028 <<>>

 LocalChangeList target = getTargetChangeList(e);
    if (target != null) {
      new EditChangelistDialog(project, target).show();
    }
  }

  @Nullable
  private static LocalChangeList getTargetChangeList(AnActionEvent e) {
    Project project = e.getProject();
    if (project == null) return null;
    ChangeList[] lists = e.getData(VcsDataKeys.CHANGE_LISTS);
    if (lists != null && lists.length > 0) {
      if (lists.length == 1) {
        return ChangeListManager.getInstance(project).findChangeList(lists[0].getName());
      }
      return null;
    }
    Change[] changes = e.getData(VcsDataKeys.CHANGES);
    if (changes == null) return null;

    LocalChangeList result = null;
    for (Change change : changes) {
      LocalChangeList cl = ChangeListManager.getInstance(project).getChangeList(change);
      if (result == null)
        result = cl;
      else if (cl != null && cl != result)
        return null;
    }
    return result;
  }
}