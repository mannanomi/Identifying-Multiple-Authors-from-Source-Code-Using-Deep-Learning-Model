<<>>plugins/ant/src/com/intellij/lang/ant/config/execution/ExecutionHandler.java<<>>
<<>> 15 April 2021 <<>>

javaParameters = builder.getCommandLine();

      WslTargetEnvironmentConfiguration wslConfiguration = JavaCommandLineState.checkCreateWslConfiguration(javaParameters.getJdk());
      if (wslConfiguration != null) {
        factory = new WslTargetEnvironmentFactory(wslConfiguration);
        configuration = wslConfiguration;
      }
      else {
        factory = new LocalTargetEnvironmentFactory();
        configuration = null;
      }


<<>> 15 April 2021 <<>>


 TargetEnvironmentRequest request = factory.createRequest();
          TargetedCommandLineBuilder builder = javaParameters.toCommandLine(request, configuration);
          TargetEnvironment environment = factory.prepareRemoteEnvironment(request, TargetEnvironmentAwareRunProfileState.TargetProgressIndicator.EMPTY);
          TargetedCommandLine commandLine = builder.build();

          messageView.setBuildCommandLine(commandLine.getCommandPresentation(environment));

          ProcessHandler handler = runBuild(indicator, messageView, buildFile, listenerWrapper, commandLine, environment);

          
