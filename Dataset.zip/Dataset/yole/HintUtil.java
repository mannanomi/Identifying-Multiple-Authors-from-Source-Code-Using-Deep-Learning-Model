<<>>platform/platform-impl/src/com/intellij/codeInsight/hint/HintUtil.java<<>>
<<>> 30 Jul 2018 <<>>

@Nullable
  public static String getHintLabel(JComponent hintComponent) {
    if (hintComponent instanceof HintLabel) {
      return ((HintLabel) hintComponent).getText();
    }
    return null;
  }

  @Nullable
  public static Icon getHintIcon(JComponent hintComponent) {
    if (hintComponent instanceof HintLabel) {
      return ((HintLabel) hintComponent).getIcon();
    }
    return null;
  }

<<>> 30 Jul 2018 <<>>

  return "Hint: text='" + getText() + "'";
    }

    public String getText() {
      return myPane != null ? myPane.getText() : "";
    }

    @Nullable
    public Icon getIcon() {
      return myIcon != null ? myIcon.getIcon() : null;