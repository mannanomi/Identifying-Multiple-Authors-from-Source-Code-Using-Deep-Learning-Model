
<<>> plugins/devkit/devkit-core/src/dom/Unregister.java <<>>
<<>> 17 Aug 2018<<>>


package org.jetbrains.idea.devkit.dom;

import com.intellij.util.xml.Convert;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.GenericAttributeValue;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.devkit.dom.impl.ActionOrGroupResolveConverter;

/**
 * @author yole
 */
public interface Unregister extends DomElement {
  @NotNull
  @Convert(ActionOrGroupResolveConverter.class)
  GenericAttributeValue<ActionOrGroup> getId();
}