<<>>java/testFramework/src/com/intellij/testFramework/CompilerTester.java<<>>
<<>> 17 Mar 2021 <<>>

 public CompilerTester(@NotNull Project project,
                        @NotNull List<? extends Module> modules,
                        @Nullable Disposable disposable) throws Exception {
    this(project, modules, disposable, true);
  }

  public CompilerTester(@NotNull Project project,
                        @NotNull List<? extends Module> modules,
                        @Nullable Disposable disposable,
                        boolean overrideJdkAndOutput) throws Exception {

<<>> 17 Mar 2021 <<>>

  if (overrideJdkAndOutput) {
      WriteCommandAction.writeCommandAction(getProject()).run(() -> {
        Objects.requireNonNull(CompilerProjectExtension.getInstance(getProject())).setCompilerOutputUrl(myMainOutput.findOrCreateDir("out").getUrl());
        if (!myModules.isEmpty()) {
          JavaAwareProjectJdkTableImpl projectJdkTable = JavaAwareProjectJdkTableImpl.getInstanceEx();
          for (Module module : myModules) {
            ModuleRootModificationUtil.setModuleSdk(module, projectJdkTable.getInternalJdk());
          }                       