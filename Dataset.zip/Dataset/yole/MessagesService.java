<<>>platform/platform-api/src/com/intellij/openapi/ui/messages/MessagesService.java<<>>
<<>> 20 Aug 2018 <<>>


    try {
      return (MessagesService) MessagesService.class.getClassLoader().loadClass("com.intellij.ui.messages.MessagesServiceImpl").newInstance();
    }
    catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
      throw new RuntimeException(e);
    }
  }
}