<<>> jps/model-serialization/src/org/jetbrains/jps/model/serialization/JpsWslPathMapper.java<<>>
<<>> 25 Nov 2020 <<>>


import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.util.io.StreamUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.jps.util.JpsPathUtil;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

<<>> 25 Nov 2020 <<>>

if (url.startsWith(JpsPathUtil.FILE_URL_PREFIX)) {
      return JpsPathUtil.FILE_URL_PREFIX + mapPath(url.substring(JpsPathUtil.FILE_URL_PREFIX.length()));
    }
    if (url.startsWith(JpsPathUtil.JAR_URL_PREFIX)) {
      int index = url.indexOf(JpsPathUtil.JAR_SEPARATOR);
      if (index >= 0) {
        return JpsPathUtil.JAR_URL_PREFIX + mapPath(url.substring(JpsPathUtil.JAR_URL_PREFIX.length(), index)) + url.substring(index);
      }
    }

 <<>> 25 Nov 2020 <<>>   


  @NotNull
  private String mapPath(@NotNull String path) {
    if (myWslRootPrefix == null || path.indexOf(':') != 1) {
      String wslPath;
      try {
        wslPath = runWslPath(path);
      }
      catch (IOException | InterruptedException e) {
        return path;
      }
      if (path.indexOf(':') == 1) {
        int pathLengthAfterDriveLetter = path.length() - 2;
        myWslRootPrefix = wslPath.substring(0, wslPath.length() - pathLengthAfterDriveLetter - 2 /* slash and drive letter */);
      }
      return wslPath;
    }

    return myWslRootPrefix + Character.toLowerCase(path.charAt(0)) + FileUtil.toSystemIndependentName(path.substring(2));
  }

  private static String runWslPath(String path) throws IOException, InterruptedException {
    ProcessBuilder processBuilder = new ProcessBuilder("/usr/bin/wslpath", path);
    Process process = processBuilder.start();
    process.waitFor();
    return StreamUtil.readText(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
  }


  <<>> 20 Nov 2020 <<>>

package org.jetbrains.jps.model.serialization;

public class JpsWslPathMapper implements JpsPathMapper {
  private static final String WSL_PREFIX = "//wsl$/";

  @Override
  public String mapUrl(String url) {
    if (url.contains(WSL_PREFIX)) {
      int startPos = url.indexOf(WSL_PREFIX);
      int endPos = url.indexOf('/', startPos + WSL_PREFIX.length());
      if (endPos >= 0) {
        return url.substring(0, startPos) + url.substring(endPos);
      }
    }
    return url;
  }
}