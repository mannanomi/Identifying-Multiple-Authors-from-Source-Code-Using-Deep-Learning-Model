<<>>platform/core-impl/src/com/intellij/ide/plugins/PluginLoadingResult.java<<>>
<<>> 31 Mar 2021 <<>>

PluginLoadingError error = PluginLoadingError.create(
          descriptor,
          () -> CoreBundle.message("plugin.loading.error.long.compatible.with.intellij.idea.only", descriptor.getName()),
          () -> CoreBundle.message("plugin.loading.error.short.compatible.with.intellij.idea.only"));
        addIncompletePlugin(descriptor, error);