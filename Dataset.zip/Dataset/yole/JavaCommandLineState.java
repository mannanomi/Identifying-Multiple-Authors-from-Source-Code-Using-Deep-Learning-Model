<<>>java/execution/impl/src/com/intellij/execution/configurations/JavaCommandLineState.java<<>>

<<>> 25 Nov 2020<<>>

@Override
  public TargetEnvironmentFactory createCustomTargetEnvironmentFactory() {
    try {
      JavaParameters parameters = getJavaParameters();
      return checkCreateWslFactory(parameters);
    }
    catch (ExecutionException e) {
      // ignore
    }
    return null;
  }

  @Nullable
  private static WslTargetEnvironmentFactory checkCreateWslFactory(JavaParameters parameters) {
    String path;
    try {
      path = parameters.getJdkPath();
    }
    catch (CantRunException e) {
      return null;
    }
    Pair<String, @Nullable WSLDistribution> pathInWsl = WslDistributionManager.getInstance().parseWslPath(path);
    Sdk jdk = parameters.getJdk();
    if (jdk != null && pathInWsl != null && pathInWsl.second != null) {
      WslTargetEnvironmentConfiguration config = new WslTargetEnvironmentConfiguration(pathInWsl.second);
      JavaLanguageRuntimeConfiguration javaConfig = new JavaLanguageRuntimeConfiguration();
      javaConfig.setHomePath(pathInWsl.first);
      String jdkVersionString = jdk.getVersionString();
      if (jdkVersionString != null) {
        javaConfig.setJavaVersionString(jdkVersionString);
      }
      config.addLanguageRuntime(javaConfig);
      return new WslTargetEnvironmentFactory(config);
    }
    return null;
  }

 <<>> 25 Nov 2020<<>>


   TargetEnvironment.TargetPortBinding portRequest = myDebuggerPortRequest;
    if (portRequest != null) {
      setRemoteConnectionPort(environment.getTargetPortBindings().get(portRequest));
    }
  }

  public void setRemoteConnectionPort(int port) {
    RemoteConnection c = myRemoteConnection;
    if (c != null) {
      c.setDebuggerHostName("localhost");
      c.setDebuggerAddress(String.valueOf(port));
    }
  }

  private synchronized void prepareRemoteConnection(
    @NotNull TargetEnvironmentRequest request,
    @Nullable TargetEnvironmentConfiguration configuration
  ) {
    myDebuggerPortRequest = null;
    final int remotePort;
    {
      Integer remotePort2 = requiredDebuggerTargetPort(request);
      if (remotePort2 == null) {
        myRemoteConnection = null;
        return;
      }
      remotePort = remotePort2;
    }

    try {
      final String remoteAddressForVmParams;

      final boolean java9plus = Optional.ofNullable(configuration)
        .map(TargetEnvironmentConfiguration::getRuntimes)
        .map(list -> list.findByType(JavaLanguageRuntimeConfiguration.class))
        .map(JavaLanguageRuntimeConfiguration::getJavaVersionString)
        .filter(StringUtil::isNotEmpty)
        .map(JavaSdkVersion::fromVersionString)
        .map(v -> v.isAtLeast(JavaSdkVersion.JDK_1_9))
        .orElse(false);

      if (java9plus) {
        // IDEA-225182 - hack: pass "host:port" to construct correct VM params, then adjust the connection
        remoteAddressForVmParams = "*:" + remotePort;
      }
      else {
        remoteAddressForVmParams = String.valueOf(remotePort);
      }

      RemoteConnection remoteConnection = new RemoteConnectionBuilder(false, DebuggerSettings.SOCKET_TRANSPORT, remoteAddressForVmParams)
        .suspend(true)
        .create(getJavaParameters());

      remoteConnection.setApplicationAddress(String.valueOf(remotePort));
      if (java9plus) {
        remoteConnection.setApplicationHostName("*");
      }

      myDebuggerPortRequest = new TargetEnvironment.TargetPortBinding(null, remotePort);

      myRemoteConnection = remoteConnection;
    }
    catch (ExecutionException e) {
      myRemoteConnection = null;
    }
  }

  @Nullable
  @Override
  public RemoteConnection createRemoteConnection(ExecutionEnvironment environment) {
    return myRemoteConnection;
  }

  @Override
  public boolean isPollConnection() {
    return true;

 <<>> 25 Nov 2020<<>>


   public @Nullable Integer requiredDebuggerTargetPort(@NotNull TargetEnvironmentRequest request) {
    // TODO Checking for a specific target is a gap in the idea of API. This check was introduced because the Java debugger
    //  runs in the server mode for local targets and in the client mode for other targets. But why?
    //  Anyway, the server mode requires a remote TCP forwarding that can't always be acquired for the Docker target.
    //  Maybe replace this method with something like `if (!request.isLocalPortForwardingSupported())`?
    if (DefaultDebugExecutor.EXECUTOR_ID.equalsIgnoreCase(getEnvironment().getExecutor().getId()) &&
        !(request instanceof LocalTargetEnvironmentRequest)) {
      return 12345;
    }
    else {
      return null;
    }
  }