<<>> platform/lang-impl/src/com/intellij/codeInsight/completion/impl/CompletionServiceImpl.java<<>>
<<>> 17 Aug 2018<<>>

 @Override
  public void performCompletion(final CompletionParameters parameters, final Consumer<CompletionResult> consumer) {
    myApiCompletionProcess = parameters.getProcess();
    try {
      final Set<LookupElement> lookupSet = ContainerUtil.newConcurrentSet();

      getVariantsFromContributors(parameters, null, result -> {
        if (lookupSet.add(result.getLookupElement())) {
          consumer.consume(result);
        }
      });
    }
    finally {
      myApiCompletionProcess = null;
    }
  }

  <<>> 17 Aug 2018<<>>

  public CompletionProcess getCurrentCompletion() {
    CompletionProgressIndicator indicator = getCurrentCompletionProgressIndicator();
    return indicator != null ? indicator : myApiCompletionProcess;
  }

  public static CompletionProgressIndicator getCurrentCompletionProgressIndicator() {