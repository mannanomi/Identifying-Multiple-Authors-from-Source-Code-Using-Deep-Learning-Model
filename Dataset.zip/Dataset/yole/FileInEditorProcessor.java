<<>>platform/lang-impl/src/com/intellij/codeInsight/actions/FileInEditorProcessor.java<<>>
<<>> 2 Feb 2021 <<>>

 return new ShowReformatDialogRunnable(myEditor);
    }
  }

  private static class ShowReformatDialogRunnable implements Runnable {
    private final Editor myEditor;

    private ShowReformatDialogRunnable(Editor editor) {
      myEditor = editor;
    }

    @Override
    public void run() {
      AnAction action = ActionManager.getInstance().getAction("ShowReformatFileDialog");
      DataManager manager = DataManager.getInstance();
      if (manager != null) {
        DataContext context = manager.getDataContext(myEditor.getContentComponent());
        action.actionPerformed(AnActionEvent.createFromAnAction(action, null, "", context));
      }