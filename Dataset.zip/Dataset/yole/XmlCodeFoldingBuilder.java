<<>> xml/xml-psi-impl/src/com/intellij/lang/XmlCodeFoldingBuilder.java<<>>
<<>> 7 Jan 2021 <<>>

private boolean isPsiElementCollapsedByDefault(PsiElement psi) {
    final XmlCodeFoldingSettings foldingSettings = getFoldingSettings();
    return psi instanceof XmlTag && foldingSettings.isCollapseXmlTags() ||
           psi instanceof XmlAttribute && (foldStyle((XmlAttribute)psi, foldingSettings) || foldSrc((XmlAttribute)psi, foldingSettings)) ||
           isEntity(psi) && foldingSettings.isCollapseEntities() && hasEntityPlaceholder(psi);
  }

  @Override
  public boolean isRegionCollapsedByDefault(@NotNull FoldingDescriptor foldingDescriptor) {
    final PsiElement psi = foldingDescriptor.getElement().getPsi();
    FoldingBuilder foldingBuilder = LanguageFolding.INSTANCE.forLanguage(psi.getLanguage());

    if (foldingBuilder == this || foldingBuilder instanceof CompositeFoldingBuilder) {
      return isPsiElementCollapsedByDefault(psi);
    }
    return foldingBuilder.isCollapsedByDefault(foldingDescriptor);
  }