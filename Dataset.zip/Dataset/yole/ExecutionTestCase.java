<<>>java/testFramework/src/com/intellij/execution/ExecutionTestCase.java<<>>
<<>> 17 Mar 2021 <<>>   

 if (FileUtil.isAncestor(ourOutputRoot.toFile(), myModuleOutputDir.toFile(), false)) {
        VirtualFile vDir = LocalFileSystem.getInstance().refreshAndFindFileByNioFile(ourOutputRoot);
        assertNotNull(ourOutputRoot.toString(), vDir);
      }

      compileProject();
    }
  }

  protected void compileProject() throws Exception {
    // JDK added by compilerTester is used after compilation, so, we don't dispose compilerTester after rebuild
    CompilerTester compilerTester = new CompilerTester(myProject, Arrays.asList(ModuleManager.getInstance(myProject).getModules()),
                                                       getTestRootDisposable(), overrideCompileJdkAndOutput());
    List<CompilerMessage> messages = compilerTester.rebuild();
    for (CompilerMessage message : messages) {
      if (message.getCategory() == CompilerMessageCategory.ERROR) {
        FileUtil.delete(myModuleOutputDir);
        fail("Compilation failed: " + message + " " + message.getVirtualFile());

  <<>> 17 Mar 2021 <<>>   

    @NotNull
  protected Path getModuleOutputDir() {
    return ourOutputRoot.resolve(PathUtil.getFileName(getTestAppPath()));
  }

  protected boolean overrideCompileJdkAndOutput() {
    return true;
  }