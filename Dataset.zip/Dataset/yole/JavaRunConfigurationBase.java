<<>>java/execution/impl/src/com/intellij/execution/JavaRunConfigurationBase.java<<>>
<<>> 25 Nov 2020 <<>>

protected boolean runsUnderWslJdk() {
    String path = getAlternativeJrePath();
    if (path != null) {
      return WslDistributionManager.getInstance().isWslPath(path);
    }
    Module module = getConfigurationModule().getModule();
    if (module != null) {
      Sdk sdk;
      try {
        sdk = JavaParameters.getValidJdkToRunModule(module, false);
      }
      catch (CantRunException e) {
        return false;
      }
      String sdkHomePath = sdk.getHomePath();
      return sdkHomePath != null && WslDistributionManager.getInstance().isWslPath(sdkHomePath);
    }
    return false;
  }