<<>> plugins/groovy/src/org/jetbrains/plugins/groovy/runner/GroovyScriptRunConfiguration.java<<>>
<<>> 28 Nov 2020 <<>>

 Module module = getConfigurationModule().getModule();
    if (module != null) return module;
    return getFirstValidModule();
  }

  @Nullable
  private Module getFirstValidModule() {
    final GroovyScriptRunner scriptRunner = getScriptRunner();
    Module[] modules = ModuleManager.getInstance(getProject()).getModules();
    if (scriptRunner == null) {
      return modules[0];
    }
    for (Module module : modules) {
      if (scriptRunner.isValidModule(module)) {
        return module;
      }
    }
    return null;
  