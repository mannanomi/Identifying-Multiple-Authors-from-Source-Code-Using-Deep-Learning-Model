<<>>java/compiler/impl/src/com/intellij/compiler/server/BuildManager.java<<>>
<<>>24 Mar 2021<<>>

for (BuildProcessParametersProvider buildProcessParametersProvider : BuildProcessParametersProvider.EP_NAME.getExtensions(project)) {
      List<String> pluginPaths = buildProcessParametersProvider.getAdditionalPluginPaths();
      for (String path : pluginPaths) {
        cmdLine.copyPathToTarget(new File(path));
      }
    }

<<>> 19 Mar 2021 <<>>

      if (StringUtil.contains(errorsOnLaunch, "io.netty.channel.ConnectTimeoutException") && wslDistribution != null) {
                    msg.append(JavaCompilerBundle.message("wsl.network.connection.failure"));
                  }
                  else {
                    msg.append("\n").append(errorsOnLaunch);
                    if (StringUtil.contains(errorsOnLaunch, "java.lang.NoSuchMethodError")) {
                      msg.append(
                        "\nThe error may be caused by JARs in Java Extensions directory which conflicts with libraries used by the external build process.")
                        .append(
                          "\nTry adding -Djava.ext.dirs=\"\" argument to 'Build process VM options' in File | Settings | Build, Execution, Deployment | Compiler to fix the problem.");
                    }


 <<>> 17 Mar 2021 <<>>

                      Project project = findProjectByProjectPath(entry.getKey());
              Function<String, String> pathMapper = Function.identity();
              if (project != null) {
                WSLDistribution wslDistribution = findWSLDistributionForBuild(project);
                if (wslDistribution != null) {
                  pathMapper = (path) -> getWslPathFromInternedPath(path, wslDistribution);
                }
              }
              CmdlineRemoteProto.Message.ControllerMessage.FSEvent event = data.createNextEvent(pathMapper);


 <<>> 17 Mar 2021 <<>>             


 @Nullable
  private static Project findProjectByProjectPath(String projectPath) {
    return ContainerUtil.find(ProjectManager.getInstance().getOpenProjects(), (project) -> getProjectPath(project).equals(projectPath));
  }

  // interned paths collapse repeated slashes so \\wsl$ ends up /wsl$
  private static String getWslPathFromInternedPath(String path, WSLDistribution distribution) {
    if (path.startsWith("/wsl$")) {
      return distribution.getWslPath("/" + path);
    }
    return path;
  }