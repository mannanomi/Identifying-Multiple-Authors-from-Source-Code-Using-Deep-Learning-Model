<<>> updater/src/com/intellij/updater/Runner.java <<>>
<<>> 28 Nov 2020 <<>>

List<String> effectiveArgs = new ArrayList<>();
      for (String arg : args) {
        if (arg.startsWith("@")) {
          FileInputStream fis = new FileInputStream(arg.substring(1));
          try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));
            while (true) {
              String line = reader.readLine();
              if (line == null) break;
              effectiveArgs.add(line);
            }
          }
          finally {
            fis.close();
          }
        }
        else {
          effectiveArgs.add(arg);
        }
      }
      _main(effectiveArgs.toArray(new String[0]));