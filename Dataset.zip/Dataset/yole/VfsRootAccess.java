<<>>platform/platform-impl/src/com/intellij/openapi/vfs/newvfs/impl/VfsRootAccess.java<<>>
<<>> 17 Mar 2021 <<>>

 for (Module module : ModuleManager.getInstance(project).getModules()) {
          Sdk moduleSdk = ModuleRootManager.getInstance(module).getSdk();
          if (moduleSdk != null) {
            String homePath = moduleSdk.getHomePath();
            if (homePath != null) {
              allowed.add(homePath);
            }
          }
        }