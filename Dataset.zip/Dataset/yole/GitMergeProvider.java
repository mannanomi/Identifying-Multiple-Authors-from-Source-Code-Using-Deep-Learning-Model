<<>>plugins/git4idea/src/git4idea/merge/GitMergeProvider.java<<>>
<<>> 14 May 2018 <<>>

 @Nullable
  public String resolveMergeBranch(@NotNull VirtualFile file) {
    GitRepository repository = GitRepositoryManager.getInstance(myProject).getRepositoryForFile(file);
    if (repository == null) {
      return null;
    }
    return resolveMergeBranch(repository);
  }

  @Nullable
  private String resolveMergeBranch(GitRepository repository) {
    GitRevisionNumber mergeHeadRevisionNumber;
    try {
      mergeHeadRevisionNumber = GitRevisionNumber.resolve(myProject, repository.getRoot(), MERGE_HEAD);
    }
    catch (VcsException e) {
      return null;
    }
    Collection<GitLocalBranch>
      localBranchesByHash = repository.getBranches().findLocalBranchesByHash(HashImpl.build(mergeHeadRevisionNumber.asString()));
    if (localBranchesByHash.size() == 1) {
      return localBranchesByHash.iterator().next().getName();
    }
    return null;
  }



  <<>> 14 May 2018 <<>>

  return new GitDefaultMergeDialogCustomizer(this);
  }

  private static String calcName(boolean isTheirs, @Nullable String branchName) {
    String title = isTheirs ? GitBundle.message("merge.tool.column.theirs.status") : GitBundle.message("merge.tool.column.yours.status");
    return branchName != null
           ? title + " (" + StringUtil.shortenTextWithEllipsis(branchName, 15, 7, true) + ")"
           : title;
  }

  @Nullable
  public String getSingleMergeBranchName(Collection<VirtualFile> roots) {
    return roots
      .stream()
      .map(root -> resolveMergeBranch(root))
      .collect(MoreCollectors.onlyOne())
      .orElse(null);
  }

  @Nullable
  public String getSingleCurrentBranchName(Collection<VirtualFile> roots) {
    return roots
      .stream()
      .map(root -> GitRepositoryManager.getInstance(myProject).getRepositoryForFile(root))
      .map(repo -> repo == null ? null : repo.getCurrentBranchName())
      .collect(MoreCollectors.onlyOne())
      .orElse(null);




      <<>>14 May 2018 <<>>

       @Nullable
  public String resolveMergeBranchOrCherryPick(@NotNull VirtualFile file) {
    GitRepository repository = GitRepositoryManager.getInstance(myProject).getRepositoryForFile(file);
    if (repository == null) {
      return null;
    }
    String mergeBranch = resolveMergeBranch(repository);
    if (mergeBranch != null) {
      return mergeBranch;
    }

    try {
      GitRevisionNumber.resolve(myProject, repository.getRoot(), CHERRY_PICK_HEAD);
      return "cherry-pick";
    }
    catch (VcsException e) {
      return null;
    }
  }