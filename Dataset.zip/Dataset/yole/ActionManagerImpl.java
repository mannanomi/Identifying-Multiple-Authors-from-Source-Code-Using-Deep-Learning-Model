<<>>platform/platform-impl/src/com/intellij/openapi/actionSystem/impl/ActionManagerImpl.java<<>>
<<>> 17 Aug 2018<<>>

private void processUnregisterNode(Element element, PluginId pluginId) {
    String id = element.getAttributeValue(ID_ATTR_NAME);
    if (id == null) {
      reportActionError(pluginId, "'id' attribute is required for 'unregister' elements");
      return;
    }
    AnAction action = getAction(id);
    if (action == null) {
      reportActionError(pluginId, "Trying to unregister non-existing action " + id);
      return;
    }

    AbbreviationManager.getInstance().removeAllAbbreviations(id);
    for (AnAction anAction : myId2Action.values()) {
      if (anAction instanceof DefaultActionGroup) {
        ((DefaultActionGroup) anAction).remove(action, id);
      }
    }

    unregisterAction(id);
  }