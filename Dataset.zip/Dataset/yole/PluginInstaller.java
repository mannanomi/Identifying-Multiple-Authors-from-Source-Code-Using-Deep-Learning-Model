<<>>platform/platform-impl/src/com/intellij/ide/plugins/PluginInstaller.java<<>>
<<>> 31 Mar 2021 <<>>

boolean uninstalledWithoutRestart = true;
    if (pluginDescriptor.isEnabled()) {
      DynamicPlugins.UnloadPluginOptions options = new DynamicPlugins.UnloadPluginOptions()
        .withUpdate(isUpdate)
        .withWaitForClassloaderUnload(true);

      uninstalledWithoutRestart = parentComponent != null ?
                                  DynamicPlugins.unloadPluginWithProgress(null, parentComponent, pluginDescriptor, options) :
                                  DynamicPlugins.unloadPlugin(pluginDescriptor, options);
    }