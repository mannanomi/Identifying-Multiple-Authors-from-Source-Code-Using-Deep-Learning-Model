<<>>platform/lang-impl/src/com/intellij/openapi/projectRoots/impl/JavaHomeFinderWsl.java<<>>

<<>> 18 Mar 2021<<>>

List<String> list = new ArrayList<>();
    for (String defaultPath : JavaHomeFinder.DEFAULT_JAVA_LINUX_PATHS) {
      String path = distro.getWindowsPath(defaultPath);
      if (path != null) {
        list.add(path);
      }
    }
    String home = distro.getUserHome();
    if (home != null) {
      list.add(distro.getWindowsPath(home + "/.jdks"));
    }
    return ArrayUtil.toStringArray(list);