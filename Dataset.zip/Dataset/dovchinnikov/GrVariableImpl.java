<<>>plugins/groovy/groovy-psi/src/org/jetbrains/plugins/groovy/lang/psi/impl/statements/GrVariableImpl.java<<>>
<<>> 8 April 2021 <<>>

import org.jetbrains.annotations.Nullable;
import org.jetbrains.plugins.groovy.lang.parser.GroovyStubElementTypes;
import org.jetbrains.plugins.groovy.lang.psi.GroovyElementVisitor;
import org.jetbrains.plugins.groovy.lang.psi.api.auxiliary.GrListOrMap;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.GrVariable;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.GrVariableDeclaration;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.expressions.GrExpression;
	@@ -64,6 +65,30 @@ protected Icon getElementIcon(int flags) {
    return JetgroovyIcons.Groovy.Variable;
  }

  @Override
  public @Nullable GrExpression getInitializerGroovy() {
    final PsiElement parent = getParent();
    if (parent instanceof GrVariableDeclaration) {
      GrVariableDeclaration declaration = (GrVariableDeclaration)parent;
      if (declaration.isTuple()) {
        GrExpression rValue = declaration.getTupleInitializer();
        if (!(rValue instanceof GrListOrMap)) {
          return null;
        }
        int position = ArrayUtil.indexOf(declaration.getVariables(), this);
        if (position < 0) {
          return null;
        }
        final GrExpression[] initializers = ((GrListOrMap)rValue).getInitializers();
        if (position < initializers.length) {
          return initializers[position];
        }
        return null;
      }
    }
    return super.getInitializerGroovy();
  }

  @Override
  public @Nullable PsiType getInitializerType() {
    PsiElement parent = getParent();
      
      
      
      
  <<>> 8 April 2021 <<>>    
      
import com.intellij.lang.ASTNode;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiType;
import com.intellij.psi.search.SearchScope;
import com.intellij.util.ArrayUtil;
import icons.JetgroovyIcons;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.plugins.groovy.lang.parser.GroovyStubElementTypes;
import org.jetbrains.plugins.groovy.lang.psi.GroovyElementVisitor;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.GrVariable;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.GrVariableDeclaration;
import org.jetbrains.plugins.groovy.lang.psi.api.statements.expressions.GrExpression;
import org.jetbrains.plugins.groovy.lang.psi.impl.synthetic.GrScriptField;
import org.jetbrains.plugins.groovy.lang.psi.stubs.GrVariableStub;
import org.jetbrains.plugins.groovy.lang.resolve.ResolveUtil;

import javax.swing.*;

import static org.jetbrains.plugins.groovy.lang.typing.TuplesKt.getMultiAssignmentType;

/**
 * @author Dmitry.Krasilschikov
 * @date 11.04.2007
	@@ -57,4 +63,24 @@ public SearchScope getUseScope() {
  protected Icon getElementIcon(int flags) {
    return JetgroovyIcons.Groovy.Variable;
  }

  @Override
  public @Nullable PsiType getInitializerType() {
    PsiElement parent = getParent();
    if (parent instanceof GrVariableDeclaration) {
      GrVariableDeclaration declaration = (GrVariableDeclaration)parent;
      if (declaration.isTuple()) {
        GrExpression rValue = declaration.getTupleInitializer();
        if (rValue == null) {
          return null;
        }
        int position = ArrayUtil.indexOf(declaration.getVariables(), this);
        if (position < 0) {
          return null;
        }
        return getMultiAssignmentType(rValue, position);
      }
    }
    return super.getInitializerType();
  }
}
      