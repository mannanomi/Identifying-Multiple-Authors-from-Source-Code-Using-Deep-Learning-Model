<<>>plugins/groovy/groovy-psi/src/org/jetbrains/plugins/groovy/lang/psi/impl/GrMapType.java<<>>
<<>> 28 Ffeb 2019<<>>

package org.jetbrains.plugins.groovy.lang.psi.impl;

import com.intellij.openapi.util.Couple;
	@@ -16,10 +16,9 @@
import org.jetbrains.plugins.groovy.lang.psi.api.statements.arguments.GrNamedArgument;
import org.jetbrains.plugins.groovy.lang.psi.util.GroovyCommonClassNames;

import java.util.*;

import static com.intellij.psi.CommonClassNames.JAVA_LANG_STRING;


 * @author peter
	@@ -69,10 +68,27 @@ protected String getJavaClassName() {
  public abstract boolean isEmpty();

  @NotNull
  protected PsiType[] getAllKeyTypes() {
    Set<PsiType> result = new HashSet<>();
    if (!getStringEntries().isEmpty()) {
      result.add(GroovyPsiManager.getInstance(myFacade.getProject()).createTypeByFQClassName(JAVA_LANG_STRING, getResolveScope()));
    }
    for (Couple<PsiType> entry : getOtherEntries()) {
      result.add(entry.first);
    }
    result.remove(null);
    return result.toArray(createArray(result.size()));
  }

  @NotNull
  protected PsiType[] getAllValueTypes() {
    Set<PsiType> result = new HashSet<>(getStringEntries().values());
    for (Couple<PsiType> entry : getOtherEntries()) {
      result.add(entry.second);
    }
    result.remove(null);
    return result.toArray(createArray(result.size()));
  }

  @NotNull
  protected abstract List<Couple<PsiType>> getOtherEntries();
	