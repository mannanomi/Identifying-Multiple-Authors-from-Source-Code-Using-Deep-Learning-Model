<<>> java/java-impl/src/com/intellij/codeInsight/daemon/impl/quickfix/StaticImportMethodQuestionAction.java<<>>
<<>> 29 April 2021 <<>>

package com.intellij.codeInsight.daemon.impl.quickfix;

import com.intellij.codeInsight.FileModificationService;
	@@ -153,70 +139,67 @@ public Icon getIconFor(T aValue) {
      };

    final ListPopupImpl popup = new ListPopupImpl(project, step) {
      @Override
      protected ListCellRenderer<T> getListElementRenderer() {
        final PopupListElementRenderer<T> rightArrow = new PopupListElementRenderer<>(this);
        final StaticMemberRenderer psiRenderer = new StaticMemberRenderer();
        return new ListCellRenderer<>() {
          @Override
          public Component getListCellRendererComponent(JList<? extends T> list,
                                                        T value,
                                                        int index,
                                                        boolean isSelected,
                                                        boolean cellHasFocus) {
            JPanel panel = new JPanel(new BorderLayout());
            Component psiRendererComponent = psiRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            rightArrow.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            JLabel arrowLabel = rightArrow.getNextStepLabel();
            arrowLabel.setBackground(psiRendererComponent.getBackground());
            panel.setBackground(psiRendererComponent.getBackground());
            panel.add(psiRendererComponent, BorderLayout.CENTER);
            panel.add(arrowLabel, BorderLayout.EAST);
            return panel;
          }
        };
      }
    };
    popup.showInBestPositionFor(editor);
  }

  private static final class StaticMemberRenderer extends PsiElementListCellRenderer<PsiMember> {

    @Override
    public String getElementText(PsiMember element) {
      return getElementPresentableName(element);
    }

    @Override
    public String getContainerText(final PsiMember element, final String name) {
      return PsiClassListCellRenderer.getContainerTextStatic(element);
    }

    @Override
    public int getIconFlags() {
      return 0;
    }

    @Nullable
    @Override
    protected TextAttributes getNavigationItemAttributes(Object value) {
      TextAttributes attrs = super.getNavigationItemAttributes(value);
      if (value instanceof PsiDocCommentOwner && !((PsiDocCommentOwner)value).isDeprecated()) {
        PsiClass psiClass = ((PsiMember)value).getContainingClass();
        if (psiClass != null && psiClass.isDeprecated()) {
          return TextAttributes.merge(attrs, super.getNavigationItemAttributes(psiClass));
        }
      }
      return attrs;
    }
  }

  private static @NlsSafe String getElementPresentableName(PsiMember element) {
    final PsiClass aClass = element.getContainingClass();
    LOG.assertTrue(aClass != null);
    return ClassPresentationUtil.getNameForClass(aClass, false) + "." + element.getName();
  }
}