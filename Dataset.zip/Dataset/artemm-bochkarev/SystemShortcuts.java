<<>>platformplatform-implsrccomintellijopenapikeymapimplSystemShortcuts.java<<>>
<<>> 15 Oct 2019 <<>>

 updateKeymapConflicts(keymap);
    final int unmutedConflicts = getUnmutedConflictsCount();
    final boolean hasOtherConflicts = unmutedConflicts > 1;

    final AnAction act = ActionManager.getInstance().getAction(actionId);
    final String actText = act == null ? actionId : act.getTemplateText(); // TODO: fix action ids from services domain
    final String message;
    if (hasOtherConflicts) {
      message = actText + " and " + (unmutedConflicts - 1) + " more shortcut conflict with macOS shortcuts. Modify these shortcuts or change macOS system settings.";
    } else {
      message = "The " + actText + " shortcut conflicts with macOS shortcut" + (macOsShortcutAction == null ? "" : " '" + macOsShortcutAction + "'") + ". Modify this shortcut or change macOS system settings.";
    }

<<>> 15 Oct 2019 <<>>

if (hasOtherConflicts) {
      final AnAction showKeymapPanelAction = DumbAwareAction.create("Modify shortcuts", e -> {
          new EditKeymapsDialog(null, actionId, true).show();
          updateKeymapConflicts(myKeymap);
        }
      );
      notification.addAction(showKeymapPanelAction);
    } else {
      final AnAction configureShortcut = DumbAwareAction.create("Modify shortcut",  e -> {
        Component component = e.getDataContext().getData(PlatformDataKeys.CONTEXT_COMPONENT);
        if (component == null) {
          Window[] frames = Window.getWindows();
          component = frames == null || frames.length == 0 ? null : frames[0];
          if (component == null) {
            LOG.error("can't show KeyboardShortcutDialog (parent component wasn't found)");
            return;
          }

<<>> 15 Oct 2019 <<>>

if (result == null)
      return ourUnknownSysAction;

    // shorten description when the result string looks like:
    // "com.apple.Safari - Search With %WebSearchProvider@ - searchWithWebSearchProvider"
    final String delimiter = " - ";
    final int pos0 = result.indexOf(delimiter);
    if (pos0 < 0)
      return result;
    final int pos1 = result.indexOf(delimiter, pos0 + delimiter.length());
    if (pos1 < 0)
      return result;

    return result.substring(pos0 + delimiter.length(), pos1).replace("%", "").replace("@", "");

