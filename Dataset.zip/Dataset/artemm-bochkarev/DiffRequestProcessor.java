<<>>platform/diff-impl/src/com/intellij/diff/impl/DiffRequestProcessor.java<<>>


<<>> 10 April 2021<<>>


    if (SystemInfo.isMac) { // collect touchbar actions
      myTouchbarActionGroup.removeAll();
      myTouchbarActionGroup.addAll(
        new MyPrevDifferenceAction(), new MyNextDifferenceAction(), new MyOpenInEditorAction(), Separator.getInstance(),
        new MyPrevChangeAction(), new MyNextChangeAction()
      );
      if (SHOW_VIEWER_ACTIONS_IN_TOUCHBAR && viewerActions != null)
        myTouchbarActionGroup.addAll(viewerActions);
    }
  }


>><< 10 April 2021>><<

  private static void _showStopRunningBar(@NotNull List<? extends RunContentDescriptor> stoppableDescriptors) {
    if (!TouchBarsManager.isTouchBarEnabled())
      return;

    List<Pair<RunContentDescriptor, Runnable>> descriptors = new ArrayList<>(stoppableDescriptors.size());
    for (RunContentDescriptor sd : stoppableDescriptors)
      descriptors.add(Pair.create(sd, ()->ApplicationManager.getApplication().invokeLater(()->ExecutionManagerImpl.stopProcess(sd))));
    TouchBarsManager.showStopRunningBar(descriptors);
  }

