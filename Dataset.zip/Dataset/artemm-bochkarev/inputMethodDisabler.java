<<>>
platform/platform-impl/src/com/intellij/idea/inputMethodDisabler.kt
<<>>
<<>> 14 April 2021<<>>




if (!IS_NOTIFICATION_REGISTERED) {
    IS_NOTIFICATION_REGISTERED = true
    NotificationsConfiguration.getNotificationsConfiguration().register(
      NOTIFICATION_GROUP,
      NotificationDisplayType.STICKY_BALLOON,
      true)
  }

  val title = IdeBundle.message("notification.title.input.method.disabler")
  val message = IdeBundle.message("notification.content.input.method.disabler")
  val notification = Notification(NOTIFICATION_GROUP, title, message, NotificationType.WARNING, null)

  val disableIMAction: AnAction = DumbAwareAction.create(IdeBundle.message("action.text.disable.input.methods")
  ) { e: AnActionEvent? ->
    disableInputMethdosImpl();
    notification.expire()
  }
  notification.addAction(disableIMAction)
  notification.notify(null)
}

private fun disableInputMethdosImpl() {
  try {
    val componentClass = ReflectionUtil.forName("java.awt.Component")
    val method = ReflectionUtil.getMethod(componentClass, "disableInputMethodSupport") ?: return
    method.invoke(componentClass)

    getLogger().info("Input method disabler: disabled for any java.awt.Component.")

    val frames = WindowManagerEx.getInstanceEx().projectFrameHelpers
      .map { fh -> SwingUtilities.getRoot(fh.frame) }
      .filter { с -> с != null }

    ApplicationManager.getApplication().executeOnPooledThread {
      val startMs = System.currentTimeMillis()
      for (frameRoot in frames) {
        freeIMRecursively(frameRoot)


<<>> 14 April 2021<<>>

private const val PERSISTENT_SETTING_KEY = "input.method.disabler.muted"
private const val NOTIFICATION_GROUP = "Input method disabler";

private var IS_NOTIFICATION_REGISTERED = false;

// TODO: consider to detect IM-freezes and then notify user (offer to disable IM)

internal fun disableInputMethodsIfPossible() {
  if (!SystemInfo.isXWindow || !SystemInfo.isJetBrainsJvm) {
    return
  }

  val muted = PropertiesComponent.getInstance().isTrueValue(PERSISTENT_SETTING_KEY)
  if (muted) {


<<>>14 April 2021<<>>

 getLogger().info("Input methods was disabled for any java.awt.Component.")

      val frames = WindowManagerEx.getInstanceEx().projectFrameHelpers
        .map { fh -> SwingUtilities.getRoot(fh.frame) }
        .filter { с -> с != null }

      ForkJoinPool.commonPool().execute {
        val startMs = System.currentTimeMillis()
        for (frameRoot in frames) {
          freeIMRecursively(frameRoot)
        }
        getLogger().info("Resources of input methods were released, spent " + (System.currentTimeMillis() - startMs) + " ms.")


