<<>>platform/platform-impl/src/com/intellij/ui/mac/touchbar/TouchBar.java<<>>
<<>> 27 April 2020<<>>

if (checks != null) {
        final String actId = ActionManager.getInstance().getId(item.getAnAction());
        if ("Resume".equals(actId))
          checks[0] = !presentation.isEnabled();
        else if ("Pause".equals(actId))
          checks[1] = !presentation.isEnabled();
      }

<<>> 27 April 2020<<>>

if (checks != null) {
      final boolean isNonActive = checks[0] && checks[1];
      if (!isNonActive)
        myLastActiveNs = startNs;
      if (isNonActive && myLastActiveNs > 0) {
        if (myAutoCloseTimer == null) {
          myAutoCloseTimer = new Timer(1500, __ -> _closeSelf());
          myAutoCloseTimer.setRepeats(false);
          myAutoCloseTimer.start();
        }
      } else {
        if (myAutoCloseTimer != null) {
          myAutoCloseTimer.stop();
          myAutoCloseTimer = null;
        }
      }
    }

