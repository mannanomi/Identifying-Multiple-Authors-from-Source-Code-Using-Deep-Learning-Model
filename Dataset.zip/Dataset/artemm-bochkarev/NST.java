<<>>platform/platform-impl/src/com/intellij/ui/mac/touchbar/NST.java<<>>
<<>>12 November 2020<<>>

long ptr = 0;
    try {
      // 1. calculate size
      int byteCount = 2;
      for (int c = 0; c < itemsCount; ++c) {
        TBItemScrubber.ItemData id = items.get(fromIndex + c);
        id.offset = byteCount;
        if (c >= visibleItems) {
          byteCount += 6;
          continue;
        }
        byteCount += 2 + (withText && id.getTextBytes() != null ? id.getTextBytes().length + 1 : 0);

        id.darkIcon =
          withImages && id.getIcon() != null && !(id.getIcon() instanceof EmptyIcon) && id.getIcon().getIconWidth() > 0 && id.getIcon().getIconHeight() > 0 ?
          IconLoader.getDarkIcon(id.getIcon(), true) : null;

        if (id.darkIcon != null) {
          id.fMulX = getIconScaleForTouchbar(id.getIcon());
          id.scaledWidth = Math.round(id.getIcon().getIconWidth()*id.fMulX);
          id.scaledHeight = Math.round(id.getIcon().getIconHeight()*id.fMulX);
          final int sizeInBytes = id.scaledWidth * id.scaledHeight * 4;
          final int totalSize = sizeInBytes + 4;
          byteCount += totalSize;
        } else
          byteCount += 4;



<<>>12 November 2020<<>>


final Pointer result = new Pointer(ptr = Native.malloc(byteCount));
      result.setShort(0, (short)itemsCount);
      int offset = 2;
      for (int c = 0; c < itemsCount; ++c) {
        TBItemScrubber.ItemData id = items.get(fromIndex + c);
        if (id.offset != offset)
          throw new Exception("Offset mismatch: scrubber item " + c + ", id.offset=" + id.offset + " offset=" + offset);
        if (c >= visibleItems) {
          result.setShort(offset, (short)0);
          result.setShort(offset + 2, (short)0);
          result.setShort(offset + 4, (short)0);
          offset += 6;
          continue;
        }

        final byte[] txtBytes = withText ? id.getTextBytes() : null;
        if (txtBytes != null && txtBytes.length > 0) {
          result.setShort(offset, (short)txtBytes.length);
          offset += 2;
          result.write(offset, txtBytes, 0, txtBytes.length);
          offset += txtBytes.length;
          result.setByte(offset, (byte)0);
          offset += 1;
        } else {
          result.setShort(offset, (short)0);
          offset += 2;
        }

        if (withImages && id.darkIcon != null) {
          offset += _writeIconRaster(id.darkIcon, id.fMulX, result, offset, byteCount);
        } else {
          final boolean hasIcon = id.getIcon() != null && !(id.getIcon() instanceof EmptyIcon) && id.getIcon().getIconWidth() > 0 && id.getIcon().getIconHeight() > 0;
          result.setShort(offset, hasIcon ? (short) 1: (short)0);
          result.setShort(offset + 2, (short)0);
          offset += 4;
        }

<<>>12 November 2020<<>>

if (w <= 0 || h <= 0) {
      throw new Exception("Incorrect icon sizes: " + icon.getIconWidth() + "x" + icon.getIconHeight() + ", scale=" + scale);
    }

    final int rasterSizeInBytes = w * h * 4;
    final int totalSize = rasterSizeInBytes + 4;

    if (offset + totalSize > totalMemoryBytes) {
      throw new Exception("Incorrect memory offset: offset=" + offset + ", rasterSize=" + rasterSizeInBytes + ", totalMemoryBytes=" + totalMemoryBytes);
    }