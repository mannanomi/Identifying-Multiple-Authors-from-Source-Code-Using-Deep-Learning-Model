<<>>javajava-analysis-implsrccomintellijcodeInsightdaemonimplanalysisHighlightFixUtil.java<<>>
<<>> 23 April 2021<<>>

  static void registerFixesForExpressionStatement(HighlightInfo info, PsiElement statement) {
    if (info == null) return;
    if (!(statement instanceof PsiExpressionStatement)) return;
    PsiCodeBlock block = ObjectUtils.tryCast(statement.getParent(), PsiCodeBlock.class);
    if (block == null) return;
    PsiExpression expression = ((PsiExpressionStatement)statement).getExpression();
    if (expression instanceof PsiAssignmentExpression) return;
    PsiType type = expression.getType();
    if (type == null) return;
    if (!type.equals(PsiType.VOID)) {
      QuickFixAction.registerQuickFixAction(info, QUICK_FIX_FACTORY.createIntroduceVariableAction(expression));
      QuickFixAction.registerQuickFixAction(info, PriorityIntentionActionWrapper
        .highPriority(QUICK_FIX_FACTORY.createIterateFix(expression)));
    }
    if (PsiTreeUtil.skipWhitespacesAndCommentsForward(statement) == block.getRBrace()) {
      PsiElement blockParent = block.getParent();
      if (blockParent instanceof PsiMethod) {
        PsiType returnType = ((PsiMethod)blockParent).getReturnType();
        if (returnType != null && returnType.isAssignableFrom(type)) {
          QuickFixAction.registerQuickFixAction(info, QUICK_FIX_FACTORY.createInsertReturnFix(expression));
        }
      }
    }
  }

