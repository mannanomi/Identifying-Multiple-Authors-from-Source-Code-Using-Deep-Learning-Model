<<>>java/execution/openapi/src/com/intellij/execution/filters/ExceptionFilter.java<<>>
<<>> 24 jan 2019 <<>>

 if (!(e instanceof PsiKeyword) || !(e.textMatches(PsiKeyword.NEW))) return false;
      PsiNewExpression newExpression = ObjectUtils.tryCast(e.getParent(), PsiNewExpression.class);
      if (newExpression == null) return false;
      PsiType type = newExpression.getType();
      return type != null && type.equalsToText(exceptionName);



 <<>> 24 jan 2019 <<>>

  PsiElementFilter specificFilter = getExceptionSpecificFilter(exceptionName);
    if (specificFilter == null) return throwFilter;
    return element -> throwFilter.isAccepted(element) || specificFilter.isAccepted(element);
  }

  @Nullable
  private static PsiElementFilter getExceptionSpecificFilter(String exceptionName) {
    switch (exceptionName) {
      case "java.lang.ArrayIndexOutOfBoundsException":
        return e -> e instanceof PsiJavaToken &&
                    e.textMatches("[") &&
                    e.getParent() instanceof PsiArrayAccessExpression;
      case "java.lang.ArrayStoreException":
        return e -> {
          if (e instanceof PsiJavaToken && e.textMatches("=") && e.getParent() instanceof PsiAssignmentExpression) {
            PsiExpression lExpression = ((PsiAssignmentExpression)e.getParent()).getLExpression();
            return PsiUtil.skipParenthesizedExprDown(lExpression) instanceof PsiArrayAccessExpression;
          }
          return false;
        };
      default:
        return null;

        

<<>> 18 jan 2019<<>>


  @Nullable
  private static String getExceptionFromMessage(String line) {
    int firstSpace = line.indexOf(' ');
    if (firstSpace == -1) {
      return getExceptionFromMessage(line, 0, line.length());
    }
    if (firstSpace == "Caused".length() && line.startsWith(CAUSED_BY)) {
      int colonPos = line.indexOf(':', CAUSED_BY.length());
      return getExceptionFromMessage(line, CAUSED_BY.length(), colonPos == -1 ? line.length() : colonPos);
    }
    if (firstSpace == "Exception".length() && line.startsWith(EXCEPTION_IN_THREAD)) {
      int nextQuotePos = line.indexOf("\" ", EXCEPTION_IN_THREAD.length());
      if (nextQuotePos == -1) return null;
      int start = nextQuotePos + "\" ".length();
      int colonPos = line.indexOf(':', start);
      return getExceptionFromMessage(line, start, colonPos == -1 ? line.length() : colonPos);
    }
    if (firstSpace > 2 && line.charAt(firstSpace - 1) == ':') {
      return getExceptionFromMessage(line, 0, firstSpace - 1);
    }
    return null;
  }

  /**
   * Returns a substring of {@code line} from {@code from} to {@code to} position after heuristically checking that
   * given substring could be an exception class name. Currently all names which are not very long, consist of 
   * alphanumeric symbols, have at least one dot and not two adjacent dots are considered to be possible 
   * exception names by this method.
   * 
   * @param line line to extract exception name from
   * @param from start index
   * @param to end index (exclusive)
   * @return a substring between from and to or null if it doesn't look like an exception name.
   */
  private static String getExceptionFromMessage(String line, int from, int to) {
    if (to - from > 200) return null;
    boolean hasDot = false;
    char prev = '.';
    for(int i= from; i<to; i++) {
      char c = line.charAt(i);
      if ((c < 'A' || c > 'Z') && (c < 'a' || c > 'z') && (prev == '.' || ((c < '0' || c > '9') && c != '.'))) {
        return null;
      }
      prev = c;
      hasDot |= c == '.';
    }
    if (!hasDot) return null;
    return line.substring(from, to);
  }
