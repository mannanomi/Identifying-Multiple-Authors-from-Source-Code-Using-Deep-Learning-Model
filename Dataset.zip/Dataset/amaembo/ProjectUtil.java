<<>>platformplatform-implsrccomintellijideimplProjectUtil.java<<>>
<<>>26 April 2021<<>>

return confirmOpenNewProject(isNewProject, null);
  }

  /**
   * @param isNewProject true if the project is just created
   * @param projectName name of the project to open (can be displayed to the user)
   * @return {@link GeneralSettings#OPEN_PROJECT_SAME_WINDOW} or
   *         {@link GeneralSettings#OPEN_PROJECT_NEW_WINDOW} or
   *         {@link Messages#CANCEL} (when a user cancels the dialog)
   */
  public static int confirmOpenNewProject(boolean isNewProject, @Nullable String projectName) {


