<<>>plugins/IntentionPowerPak/testSrc/com/siyeh/ipp/constant/ConstantSubexpressionIntentionTest.java<<>>
<<>> 23 jan 2019 <<>>

package com.siyeh.ipp.constant;

import com.siyeh.ipp.IPPTestCase;

public class ConstantSubexpressionIntentionTest extends IPPTestCase {

  public void testPlus() {
    doTest("class X {\n" +
           "  void test(int a) { int res = a + 1 /*_Compute constant value of '1 + 2'*/+ 2 + 3; }\n" +
           "}",
           "class X {\n" +
           "  void test(int a) { int res = a + 3 + 3; }\n" +
           "}");
  }

  public void testMinus() {
    doTestIntentionNotAvailable("class X {\n" +
                                "  void test(int a) { int res = a - 1 /*_Compute constant value of '1 - 2'*/- 2 - 3; }\n" +
                                "}");
  }
}