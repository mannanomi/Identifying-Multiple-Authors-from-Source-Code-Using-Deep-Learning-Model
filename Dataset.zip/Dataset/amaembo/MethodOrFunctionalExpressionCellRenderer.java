<<>>java/java-impl/src/com/intellij/ide/util/MethodOrFunctionalExpressionCellRenderer.java<<>>
<<>>23 April 2021 <<>>

public class MethodOrFunctionalExpressionCellRenderer extends DelegatingPsiElementCellRenderer<NavigatablePsiElement> {
  public static class MethodOrFunctionalExpressionCellRenderingInfo
    implements PsiElementCellRenderingInfo<NavigatablePsiElement> {
    private final MethodCellRenderer.MethodCellRenderingInfo myMethodCellRenderer;

    public MethodOrFunctionalExpressionCellRenderingInfo(boolean showMethodNames, @PsiFormatUtil.FormatMethodOptions int options) {
      myMethodCellRenderer = new MethodCellRenderer.MethodCellRenderingInfo(showMethodNames, options);
    }

    @Override
    public String getElementText(NavigatablePsiElement element) {
      return element instanceof PsiMethod ? myMethodCellRenderer.getElementText((PsiMethod)element)
                                          : ClassPresentationUtil.getFunctionalExpressionPresentation((PsiFunctionalExpression)element, false);
    }

    @Override
    public String getContainerText(final NavigatablePsiElement element, final String name) {
      return element instanceof PsiMethod ? myMethodCellRenderer.getContainerText((PsiMethod)element, name)
                                          : PsiClassListCellRenderer.getContainerTextStatic(element);
    }

    @Override
    public int getIconFlags() {
      return PsiClassListCellRenderer.INFO.getIconFlags();
    }

    @Override
    public Icon getIcon(PsiElement element) {
      return element instanceof PsiMethod ? myMethodCellRenderer.getIcon(element) : PsiElementCellRenderingInfo.super.getIcon(element);
    }
  }



<<>>23 April 2021 <<>>



