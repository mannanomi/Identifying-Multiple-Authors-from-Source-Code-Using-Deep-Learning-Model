<<>>java/java-analysis-impl/src/com/intellij/codeInspection/dataFlow/InstructionVisitor.java<<>>
<<>> 23 April 2021<<>>

public DfaInstructionState[] visitEnsure(@NotNull EnsureInstruction instruction,
                                           @NotNull DataFlowRunner runner,
                                           @NotNull DfaMemoryState memState) {
    DfaValue tosValue = memState.peek();
    DfaControlTransferValue transfer = instruction.getExceptionTransfer();
    DfaCondition cond = instruction.createCondition(tosValue);

