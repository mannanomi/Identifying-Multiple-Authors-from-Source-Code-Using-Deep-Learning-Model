<<>>java/java-impl/src/com/intellij/codeInsight/daemon/impl/quickfix/IterateOverIterableIntention.java<<>>
<<>> 23 April 2021<<>>

 private final @Nullable PsiExpression myExpression;
  private @IntentionName String myText;

  public IterateOverIterableIntention() {
    this(null);
  }

  public IterateOverIterableIntention(@Nullable PsiExpression expression) {
    myExpression = expression;
  }

<<>> 23 April 2021<<>>

if (template == null) return false;
    int offset = editor.getCaretModel().getOffset();
    int startOffset = offset;
    if (editor.getSelectionModel().hasSelection()) {
      final int selStart = editor.getSelectionModel().getSelectionStart();
      final int selEnd = editor.getSelectionModel().getSelectionEnd();
      startOffset = (offset == selStart) ? selEnd : selStart;

<<>> 23 April 2021<<>>

PsiElement element = file.findElementAt(startOffset);
    while (element instanceof PsiWhiteSpace) {
      element = element.getPrevSibling();
    }
    PsiStatement psiStatement = PsiTreeUtil.getParentOfType(element, PsiStatement.class, false);
    if (myExpression == null && psiStatement instanceof PsiExpressionStatement &&
        startOffset == offset && startOffset == psiStatement.getTextRange().getEndOffset() &&
        psiStatement.getLastChild() instanceof PsiErrorElement) {
      // At this position, we provide a quick-fix for error
      return false;
    }
    if (psiStatement != null) {
      startOffset = psiStatement.getTextRange().getStartOffset();
    }
    if (template.isDeactivated() ||
        (!TemplateManagerImpl.isApplicable(file, offset, template) &&
         (!TemplateManagerImpl.isApplicable(file, startOffset, template)))) {
      return false;
    }
    PsiExpression expression = getIterableExpression(editor, file);
    if (expression == null) return false;
    myText = JavaBundle.message("intention.name.iterate.over", Objects.requireNonNull(expression.getType()).getPresentableText());
    return true;

<<>> 23 April 2021<<>>

private PsiExpression getIterableExpression(Editor editor, PsiFile file) {
    if (myExpression != null) {
      if (!myExpression.isValid()) return null;
      final PsiType type = myExpression.getType();
      if (type instanceof PsiArrayType || InheritanceUtil.isInheritor(type, CommonClassNames.JAVA_LANG_ITERABLE)) return myExpression;
      return null;
    }


