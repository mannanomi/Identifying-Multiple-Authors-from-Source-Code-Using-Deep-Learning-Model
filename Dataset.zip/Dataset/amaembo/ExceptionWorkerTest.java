<<>>java/java-tests/testSrc/com/intellij/java/execution/filters/ExceptionWorkerTest.java<<>>
<<>> 18 jan 2019 <<>>




Trinity.create("Exception in thread \"main\" java.lang.RuntimeException: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 0\n", null, null),
      Trinity.create("\tat SomeClass$Inner.run(SomeClass.java:12)\n", 12, 9),
      Trinity.create("\tat SomeClass$1X$1.run(SomeClass.java:27)\n", 27, 19),
      Trinity.create("\tat SomeClass$1X.run(SomeClass.java:29)\n", 29, 11),
      Trinity.create("\tat SomeClass.main(SomeClass.java:32)\n", 32, 13),
      Trinity.create("Caused by: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 0\n", null, null),
      Trinity.create("\tat SomeClass.<init>(SomeClass.java:4)\n", 4, 36),
      Trinity.create("\tat SomeClass$1.<init>(SomeClass.java:18)\n", 18, 9),
      Trinity.create("\tat SomeClass.test(SomeClass.java:18)\n", 18, 9),
      Trinity.create("\tat SomeClass$Inner.run(SomeClass.java:10)\n", 10, 54));
