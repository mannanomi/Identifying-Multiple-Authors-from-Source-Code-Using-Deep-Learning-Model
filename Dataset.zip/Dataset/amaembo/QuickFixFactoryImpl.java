<<>>javajava-implsrccomintellijcodeInsightintentionimplconfigQuickFixFactoryImpl.java<<>>
<<>> 23 April 2021 <<>>


  @Override
  public @NotNull IntentionAction createInsertReturnFix(@NotNull PsiExpression expression) {
    return new ConvertExpressionToReturnFix(expression);
  }

  @Override
  public @NotNull IntentionAction createIterateFix(@NotNull PsiExpression expression) {
    return new IterateOverIterableIntention(expression);
  }

