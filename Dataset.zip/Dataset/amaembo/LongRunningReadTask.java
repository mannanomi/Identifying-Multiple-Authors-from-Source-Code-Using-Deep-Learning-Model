<<>>pluginskotlinideasrcorgjetbrainskotlinideautilLongRunningReadTask.java<<>>
<<>> 23 April 2021 <<>>

ApplicationManager.getApplication().executeOnPooledThread(
                () -> runWithWriteActionPriority(
                        progressIndicator, parentDisposable,
                        () -> {
                            ResultData resultData = null;
                            try {
                                resultData = processRequest(requestInfoCopy);
                            } finally {
                                // Back to GUI thread for submitting result
                                final ResultData finalResult = resultData;
                                ApplicationManager.getApplication().invokeLater(() -> resultReady(finalResult));
                            }
                        }));


