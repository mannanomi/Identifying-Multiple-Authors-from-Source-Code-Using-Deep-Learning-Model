<<>>java/java-analysis-impl/src/com/intellij/codeInspection/dataFlow/DfaPsiUtil.java <<>>
<<>> 23 April 2021 <<>>


  @Nullable
  public static TextRange getRange(@Nullable PsiExpression expression, int myLastOperand) {
    if (myLastOperand != -1 && expression instanceof PsiPolyadicExpression) {
      PsiPolyadicExpression anchor = (PsiPolyadicExpression)expression;
      PsiExpression[] operands = anchor.getOperands();
      if (operands.length > myLastOperand + 1) {
        return new TextRange(0, operands[myLastOperand].getStartOffsetInParent()+operands[myLastOperand].getTextLength());
      }
    }
    return null;
  }


<<>> 19 April 2021 <<>>

@param type Java token
   * @return RelationType
   */
  @Nullable
  public static RelationType getRelationByToken(IElementType type) {
    if(JavaTokenType.EQEQ.equals(type)) {
      return RelationType.EQ;
    }
    if(JavaTokenType.NE.equals(type)) {
      return RelationType.NE;
    }
    if(JavaTokenType.LT.equals(type)) {
      return RelationType.LT;
    }
    if(JavaTokenType.GT.equals(type)) {
      return RelationType.GT;
    }
    if(JavaTokenType.LE.equals(type)) {
      return RelationType.LE;
    }
    if(JavaTokenType.GE.equals(type)) {
      return RelationType.GE;
    }
    if(JavaTokenType.INSTANCEOF_KEYWORD.equals(type)) {
      return RelationType.IS;
    }
    return null;
  }

  /**
   * Tries to convert {@link DfType} to {@link PsiType}.
   *
   * @param project project
   * @param dfType DfType to convert
   * @return converted DfType; null if no corresponding PsiType found.
   */
  public static @Nullable PsiType dfTypeToPsiType(@NotNull Project project, @Nullable DfType dfType) {
    if (dfType instanceof DfPrimitiveType) {
      return ((DfPrimitiveType)dfType).getPsiType();
    }
    if (dfType instanceof DfReferenceType) {
      return ((DfReferenceType)dfType).getConstraint().getPsiType(project);
    }
    return null;
  }

<<>>19 April 2021<<>>

 @param value constant value
   * @return human readable representation of the value
   */
  public static @NlsSafe String renderValue(Object value) {
    if (value == null) return "null";
    if (value instanceof String) return '"' + StringUtil.escapeStringCharacters((String)value) + '"';
    if (value instanceof Float) return value + "f";
    if (value instanceof Long) return value + "L";
    if (value instanceof PsiField) {
      PsiField field = (PsiField)value;
      PsiClass containingClass = field.getContainingClass();
      return containingClass == null ? field.getName() : containingClass.getName() + "." + field.getName();
    }
    if (value instanceof PsiType) {
      return ((PsiType)value).getPresentableText();
    }
    return value.toString();
  }


