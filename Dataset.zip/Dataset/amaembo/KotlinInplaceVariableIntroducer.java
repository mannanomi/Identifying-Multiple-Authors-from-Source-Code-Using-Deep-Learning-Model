<<>>pluginskotlinideasrcorgjetbrainskotlinidearefactoringintroduceintroduceVariableKotlinInplaceVariableIntroducer.java<<>>
<<>> 23 April 2021 <<>>


                      () -> {
                                    if (exprTypeCheckbox.isSelected()) {
                                        String renderedType =
                                                IdeDescriptorRenderers.SOURCE_CODE_SHORT_NAMES_NO_ANNOTATIONS.renderType(myExprType);
                                        myDeclaration.setTypeReference(new KtPsiFactory(myProject).createType(renderedType));
                                    } else {
                                        myDeclaration.setTypeReference(null);



<<>> 23 April 2021 <<>>

 ApplicationManager.getApplication().runReadAction(() -> {
            ASTNode identifier = myDeclaration.getNode().findChildByType(KtTokens.IDENTIFIER);
            if (identifier != null) {
                TextRange range = identifier.getTextRange();
                RangeHighlighter[] highlighters = myEditor.getMarkupModel().getAllHighlighters();
                for (RangeHighlighter highlighter : highlighters) {
                    if (highlighter.getStartOffset() == range.getStartOffset()) {
                        if (highlighter.getEndOffset() == range.getEndOffset()) {
                            highlighter.setGreedyToRight(greedyToRight.get());