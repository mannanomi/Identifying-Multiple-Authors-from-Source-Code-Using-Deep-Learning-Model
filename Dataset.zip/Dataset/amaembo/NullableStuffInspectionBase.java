<<>>java/java-analysis-impl/src/com/intellij/codeInspection/nullable/NullableStuffInspectionBase.java<<>>
<<>> 14 Dec 2020<<>>

 @return if owner has a @NotNull or @Nullable annotation, 
   * or is in scope of @ParametersAreNullableByDefault or ParametersAreNonnullByDefault
   */
  private static boolean hasNullability(NullableNotNullManager manager, @NotNull PsiModifierListOwner owner) {
    NullabilityAnnotationInfo info = manager.findEffectiveNullabilityInfo(owner);
    return info != null && info.getNullability() != Nullability.UNKNOWN && info.getInheritedFrom() == null;
  }

<<>> 14 Dec 2020<<>>

 NullabilityAnnotationInfo info = manager.findEffectiveNullabilityInfo(owner);
    if (info == null || info.isInferred() || info.getNullability() != Nullability.NOT_NULL) return false;
    if (!checkBases && info.getInheritedFrom() != null) return false;
    if (skipExternal && info.isExternal()) return false;