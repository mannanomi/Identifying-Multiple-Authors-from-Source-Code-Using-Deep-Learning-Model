<<>>java/java-impl/src/com/intellij/codeInspection/CollectionAddAllCanBeReplacedWithConstructorInspection.java<<>>
<<>> 14 Dec 2020 <<>>


      private boolean mayInheritComparator(PsiExpression[] args, PsiType argType, PsiNewExpression assignmentExpression) {
        PsiType type = assignmentExpression.getType();
        PsiClass collectionType = Objects.requireNonNull(PsiUtil.resolveClassInClassTypeOnly(type));
        String name = Objects.requireNonNull(collectionType.getQualifiedName());
        switch (name) {
          case "java.util.TreeSet":
          case "java.util.concurrent.ConcurrentSkipListSet":
            // If declared arg type inherits SortedSet, the (SortedSet) copy constructor will be invoked, which inherits the comparator
            return InheritanceUtil.isInheritor(argType, "java.util.SortedSet");
          case "java.util.TreeMap":
          case "java.util.concurrent.ConcurrentSkipListMap":
            // If declared arg type inherits SortedMap, the (SortedMap) copy constructor will be invoked, which inherits the comparator
            return InheritanceUtil.isInheritor(argType, "java.util.SortedMap");
          case "java.util.PriorityQueue":
          case "java.util.concurrent.PriorityBlockingQueue":
            // Here even (Collection) copy constructor inherits the comparator using runtime type checks, so we should be more conservative
            TypeConstraint constraint = TypeConstraint.fromDfType(CommonDataflow.getDfType(args[0]));
            PsiClassType sortedSet = JavaPsiFacade.getElementFactory(holder.getProject()).createTypeByFQClassName("java.util.SortedSet");
            return constraint.meet(TypeConstraints.instanceOf(sortedSet)) != TypeConstraints.BOTTOM ||
                   constraint.meet(TypeConstraints.instanceOf(type)) != TypeConstraints.BOTTOM;
          default:
            return false;
        }
      }

