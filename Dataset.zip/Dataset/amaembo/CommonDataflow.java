<<>> java/java-analysis-impl/src/com/intellij/codeInspection/dataFlow/CommonDataflow.java<<>>
<<>>23 jan 2019<<>>

private static class DataflowPoint {
    // null = top; empty = bottom
    @Nullable DfaFactMap myFacts = null;
    // empty = top; null = bottom
    @Nullable Set<Object> myPossibleValues = Collections.emptySet();
    // null = top; empty = bottom
    @Nullable Set<Object> myNotValues = null;


    <<>>23 jan 2019<<>>

    void addValue(DfaMemoryStateImpl memState, DfaValue value) {
      if (myPossibleValues == null) return;
      DfaConstValue constantValue = memState.getConstantValue(value);
      if (constantValue == null) {
        myPossibleValues = null;
        return;
      }
      Object newValue = constantValue.getValue();
      if (myPossibleValues.contains(newValue)) return;
      myNotValues = null;
      if (myPossibleValues.isEmpty()) {
        myPossibleValues = Collections.singleton(newValue);
      }
      else {
        myPossibleValues = new THashSet<>(myPossibleValues);
        myPossibleValues.add(newValue);

  <<>>23 jan 2019<<>>

        void addFacts(DfaMemoryStateImpl memState, DfaValue value) {
      if (myFacts == DfaFactMap.EMPTY) return;
      DfaFactMap newMap = DataflowResult.getFactMap(memState, value);
      if (value instanceof DfaVariableValue) {
        SpecialField field = SpecialField.fromQualifierType(value.getType());
        if (field != null) {
          DfaValue specialField = field.createValue(value.getFactory(), value);
          if (specialField instanceof DfaVariableValue) {
            DfaConstValue constantValue = memState.getConstantValue(specialField);
            specialField = constantValue != null
                           ? constantValue
                           : specialField.getFactory().getFactFactory().createValue(DataflowResult.getFactMap(memState, specialField));
          }
          if (specialField instanceof DfaConstValue || specialField instanceof DfaFactMapValue) {
            newMap = newMap.with(DfaFactType.SPECIAL_FIELD_VALUE, field.withValue(specialField));

 <<>>23 jan 2019<<>>


               }
      myFacts = myFacts == null ? newMap : myFacts.unite(newMap);
    }
  }

  /**
   * Represents the result of dataflow applied to some code fragment (usually a method)
   */
  public static class DataflowResult {
    private final Map<PsiExpression, DataflowPoint> myData = new HashMap<>();



<<>>23 jan 2019<<>>


    DataflowResult copy() {
      DataflowResult copy = new DataflowResult();
      myData.forEach((expression, point) -> copy.myData.put(expression, new DataflowPoint(point)));
      return copy;
    }

    void add(PsiExpression expression, DfaMemoryStateImpl memState, DfaValue value) {
      DataflowPoint point = myData.computeIfAbsent(expression, e -> new DataflowPoint());
      if (point.myFacts != DfaFactMap.EMPTY) {


<<>>23 jan 2019<<>>

      @NotNull
    public Set<Object> getExpressionValues(@Nullable PsiExpression expression) {
      DataflowPoint point = myData.get(expression);
      if (point == null) return Collections.emptySet();
      Set<Object> values = point.myPossibleValues;
      return values == null ? Collections.emptySet() : Collections.unmodifiableSet(values);