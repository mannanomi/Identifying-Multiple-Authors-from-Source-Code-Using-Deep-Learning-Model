<<>>java/java-psi-api/src/com/intellij/codeInsight/NullabilityAnnotationInfo.java<<>>
<<>> 14 Dec 2020 <<>>



 this(annotation, nullability, null, container);
  }

  NullabilityAnnotationInfo(@NotNull PsiAnnotation annotation,
                            @NotNull Nullability nullability,
                            @Nullable PsiModifierListOwner inheritedFrom,
                            boolean container) {

<<>> 14 Dec 2020 <<>>

 @return an element the annotation was inherited from (PsiParameter or PsiMethod), or null if the annotation was not inherited.
   */
  public @Nullable PsiModifierListOwner getInheritedFrom() {
    return myInheritedFrom;
  }

  NullabilityAnnotationInfo withInheritedFrom(PsiModifierListOwner owner) {
    return new NullabilityAnnotationInfo(myAnnotation, myNullability, owner, myContainer);
  }

<<>> 14 Dec 2020 <<>>

  boolean lambdaParameter = owner instanceof PsiParameter && owner.getParent() instanceof PsiParameterList &&
                              owner.getParent().getParent() instanceof PsiLambdaExpression;

    if (!lambdaParameter) {
      // For lambda parameter, inherited annotation overrides the default one
      NullabilityAnnotationInfo defaultInfo = findNullityDefaultInHierarchy(owner);
      if (defaultInfo != null && (defaultInfo.getNullability() == Nullability.NULLABLE || !hasHardcodedContracts(owner))) {
        return defaultInfo;
      }
    }

<<>> 14 Dec 2020 <<>>

  if (lambdaParameter) {
      NullabilityAnnotationInfo defaultInfo = findNullityDefaultInHierarchy(owner);
      if (defaultInfo != null && (defaultInfo.getNullability() == Nullability.NULLABLE || !hasHardcodedContracts(owner))) {
        return defaultInfo;
      }

<<>> 14 Dec 2020 <<>>


 private static @Nullable AnnotationAndOwner findPlainAnnotation(
    @NotNull PsiModifierListOwner owner, @NotNull Set<String> qualifiedNames, boolean checkBases, boolean skipExternal) {
    AnnotationAndOwner memberAnno;
    if (checkBases && owner instanceof PsiMethod) {
      memberAnno = findAnnotationAndOwnerInHierarchy(owner, qualifiedNames, skipExternal);
    }
    else {
      PsiAnnotation annotation = findAnnotation(owner, qualifiedNames, skipExternal);
      memberAnno = annotation == null ? null : new AnnotationAndOwner(owner, annotation);
    }


<<>> 14 Dec 2020 <<>>

  if (type != null) {
        for (PsiAnnotation typeAnno : type.getApplicableAnnotations()) {
          if (areDifferentNullityAnnotations(memberAnno.annotation, typeAnno)) {
            if (typeAnno != memberAnno.annotation && !qualifiedNames.contains(typeAnno.getQualifiedName())) return null;
            return new AnnotationAndOwner(owner, typeAnno);
          }