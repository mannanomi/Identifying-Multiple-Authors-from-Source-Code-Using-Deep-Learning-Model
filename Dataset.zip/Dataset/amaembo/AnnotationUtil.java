<<>>java/java-psi-api/src/com/intellij/codeInsight/AnnotationUtil.java<<>>
<<>> 14 Dec 2020 <<>>

  AnnotationAndOwner result = findAnnotationAndOwnerInHierarchy(listOwner, annotationNames, skipExternal);
    return result == null ? null : result.annotation;
  }

  static final class AnnotationAndOwner {
    final @NotNull PsiModifierListOwner owner;
    final @NotNull PsiAnnotation annotation;

    AnnotationAndOwner(@NotNull PsiModifierListOwner owner, @NotNull PsiAnnotation annotation) {
      this.owner = owner;
      this.annotation = annotation;
    }
  }

  @Nullable
  static AnnotationAndOwner findAnnotationAndOwnerInHierarchy(@NotNull final PsiModifierListOwner listOwner,
                                                                                     @NotNull Set<String> annotationNames,
                                                                                     boolean skipExternal) {

