<<>> java/java-tests/testData/inspection/dataFlow/fixture/InlineSimpleMethods.java<<>>
<<>> 21 jan 2019<<>>

int[] array;

  private int readValue() {
    return array[0];
  }

  void testArraySize() {
    if(readValue() > 0 && <warning descr="Condition 'array.length > 0' is always 'true' when reached">array.length > 0</warning>) {}
  }

  Object element;

  private String getString() {
    return ((String)element);
  }

  void testGetString() {
    if(!getString().isEmpty() && <warning descr="Condition 'element instanceof String' is always 'true' when reached">element instanceof String</warning>) {}
  }