<<>>plugins/kotlin/jvm/src/org/jetbrains/kotlin/idea/framework/ui/ConfigureDialogWithModulesAndVersion.java<<>>
<<>>23 April 2021 <<>>

    ApplicationManager.getApplication().invokeLater(() -> {
            infoPanel.remove(processIcon);
            infoPanel.add(new JLabel(UIUtil.getBalloonWarningIcon()), BorderLayout.CENTER);
            infoPanel.setToolTipText(KotlinJvmBundle.message("configure.kotlin.cant.load.versions"));
            infoPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            infoPanel.updateUI();


