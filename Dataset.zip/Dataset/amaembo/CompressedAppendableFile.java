<<>>platform/util/src/com/intellij/util/io/CompressedAppendableFile.java<<>>
<<>> 26 April 2021<<>>


  long toSkip = offset;
    while (toSkip > 0) {
      long skipped = in.skip(toSkip);
      if (skipped == 0) {
        throw new EOFException("Unable to skip " + offset + " bytes: end-of-file reached");
      }
      toSkip -= skipped;


