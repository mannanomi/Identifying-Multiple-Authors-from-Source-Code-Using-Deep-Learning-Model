

<<>>plugins/InspectionGadgets/testsrc/com/siyeh/ig/fixes/controlflow/ExcessiveRangeCheckInspectionFixTest.java<<>>
<<>> 22 jan 2019 <<>>




package com.siyeh.ig.fixes.controlflow;

import com.intellij.codeInsight.daemon.quickFix.LightQuickFixParameterizedTestCase;
import com.intellij.codeInspection.LocalInspectionTool;
import com.intellij.openapi.application.ex.PathManagerEx;
import com.siyeh.ig.LightInspectionTestCase;
import com.siyeh.ig.controlflow.ExcessiveRangeCheckInspection;
import org.jetbrains.annotations.NotNull;

public class ExcessiveRangeCheckInspectionFixTest extends LightQuickFixParameterizedTestCase {
  @NotNull
  @Override
  protected LocalInspectionTool[] configureLocalInspectionTools() {
    return new LocalInspectionTool[]{new ExcessiveRangeCheckInspection()};
  }

  @Override
  protected String getBasePath() {
    return "/com/siyeh/igfixes/controlflow/excessive_range_check";
  }

  @NotNull
  @Override
  protected String getTestDataPath() {
    return PathManagerEx.getCommunityHomePath() + LightInspectionTestCase.INSPECTION_GADGETS_TEST_DATA_PATH;
  }
}
