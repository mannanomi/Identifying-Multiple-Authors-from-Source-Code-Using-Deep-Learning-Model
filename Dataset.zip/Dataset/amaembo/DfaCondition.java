<<>>java/java-analysis-impl/src/com/intellij/codeInspection/dataFlow/value/DfaCondition.java<<>>
<<>> 23 April 2021 <<>>

  @Nullable
  static Exact tryEvaluate(@NotNull DfType leftType, @NotNull RelationType relationType, @NotNull DfType rightType) {
    if (relationType == RelationType.IS || relationType == RelationType.IS_NOT) {
      boolean isSuperState = rightType.isSuperType(leftType);
      if (isSuperState) {
        return Exact.fromBoolean(relationType == RelationType.IS);
      }
      boolean isDistinct = rightType.meet(leftType) == DfType.BOTTOM;
      if (isDistinct) {
        return Exact.fromBoolean(relationType == RelationType.IS_NOT);
      }
    } else {
      DfType meetRelation = leftType.meet(rightType.fromRelation(relationType));
      DfType meetNegatedRelation = leftType.meet(rightType.fromRelation(relationType.getNegated()));
      if (meetRelation == DfType.BOTTOM) {
        // both could be BOTTOM if declared type mismatches
        return meetNegatedRelation == DfType.BOTTOM ? null : Exact.FALSE;
      }
      if (meetNegatedRelation == DfType.BOTTOM) {
        return Exact.TRUE;
      }
    }

    return null;
  }