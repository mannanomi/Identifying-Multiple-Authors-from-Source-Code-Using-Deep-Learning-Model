<<>> plugins/InspectionGadgets/testsrc/com/siyeh/ig/controlflow/EnumSwitchStatementWhichMissesCasesInspectionTest.java<<>>
<<>> 23 jan 22020 <<>>

 public void testDfaPossibleValues() {
    doTest("enum E {A, B, C}\n" +
           "\n" +
           "class X {\n" +
           "  void m(E e) {\n" +
           "    if(e == E.A || e == E.B) {\n" +
           "      switch (e) {\n" +
           "        case A:\n" +
           "        case B:\n" +
           "      }\n" +
           "    }\n" +
           "  }\n" +
           "}");
  }

  public void testDfaPossibleValuesNotCovered() {
    doTest("enum E {A, B, C}\n" +
           "\n" +
           "class X {\n" +
           "  void m(E e) {\n" +
           "    if(e == E.A || e == E.B) {\n" +
           "      /*'switch' statement on enum type 'E' misses case 'B'*/switch/**/ (e) {\n" +
           "        case A:\n" +
           "      }\n" +
           "    }\n" +
           "  }\n" +
           "}");
  }

  