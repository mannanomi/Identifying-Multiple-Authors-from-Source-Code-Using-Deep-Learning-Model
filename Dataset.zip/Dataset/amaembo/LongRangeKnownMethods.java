<<>>java/java-tests/testData/inspection/dataFlow/fixture/LongRangeKnownMethods.java<<>>
<<>> 25 jan 2019<<>>


  void testNumberToString(int i, long j) {
    String s;
    s = Integer.toHexString(i);
    if (<warning descr="Condition 's.length() < 1' is always 'false'">s.length() < 1</warning>) {}
    if (s.length() < 2) {}
    if (s.length() > 7) {}
    if (<warning descr="Condition 's.length() > 8' is always 'false'">s.length() > 8</warning>) {}
    s = Integer.toOctalString(i);
    if (s.length() > 10) {}
    if (<warning descr="Condition 's.length() > 11' is always 'false'">s.length() > 11</warning>) {}
    s = Integer.toBinaryString(i);
    if (s.length() > 31) {}
    if (<warning descr="Condition 's.length() > 32' is always 'false'">s.length() > 32</warning>) {}
    s = Long.toHexString(j);
    if (<warning descr="Condition 's.length() < 1' is always 'false'">s.length() < 1</warning>) {}
    if (s.length() < 2) {}
    if (s.length() > 15) {}
    if (<warning descr="Condition 's.length() > 16' is always 'false'">s.length() > 16</warning>) {}
    s = Long.toOctalString(j);
    if (s.length() > 21) {}
    if (<warning descr="Condition 's.length() > 22' is always 'false'">s.length() > 22</warning>) {}
    s = Long.toBinaryString(j);
    if (s.length() > 63) {}
    if (<warning descr="Condition 's.length() > 64' is always 'false'">s.length() > 64</warning>) {}
    if (i >= 0 && i < 100) {
      s = Integer.toBinaryString(i);
      if (s.length() > 6) {}
      if (<warning descr="Condition 's.length() > 7' is always 'false'">s.length() > 7</warning>) {}
    }
  }

  void testNumberToStringExact(boolean b) {
    int i = b ? 123 : 456;
    String s = Integer.toString(i);
    if (<warning descr="Condition 's.equals(\"123\") || s.equals(\"456\")' is always 'true'">s.equals("123") || <warning descr="Condition 's.equals(\"456\")' is always 'true' when reached">s.equals("456")</warning></warning>) {}
  }