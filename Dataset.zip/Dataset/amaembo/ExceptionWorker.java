<<>>java/java-tests/testSrc/com/intellij/java/execution/filters/ExceptionWorkerTest.java<<>>
<<>> 24 jan 2019<<>>

private static class FunctionCallMatcher implements PsiElementFilter {
    @Override
    public boolean isAccepted(PsiElement element) {
      if (!(element instanceof PsiIdentifier)) return false;
      PsiElement parent = element.getParent();
      if (!(parent instanceof PsiReferenceExpression)) return false;
      PsiMethodCallExpression call = ObjectUtils.tryCast(parent.getParent(), PsiMethodCallExpression.class);
      if (call == null) return false;
      PsiMethod target = call.resolveMethod();
      if (target == null) return false;
      return LambdaUtil.getFunctionalInterfaceMethod(target.getContainingClass()) == target;
    }
  }

<<>> 18 jan 2019<<>>

 private boolean isTargetClass(PsiElement maybeClass) {
      if (!(maybeClass instanceof PsiClass)) return false;
      PsiClass declaredClass = (PsiClass)maybeClass;
      String declaredName = declaredClass.getQualifiedName();
      if (myClassName.equals(declaredName)) return true;
      PsiClass calledClass = ClassUtil.findPsiClass(maybeClass.getManager(), myClassName, declaredClass, true);
      if (calledClass == null) {
        calledClass = ClassUtil.findPsiClass(maybeClass.getManager(), myClassName, null, true);
      }
      return calledClass == declaredClass || declaredName != null && InheritanceUtil.isInheritor(calledClass, false, declaredName);

