<<>>plugins/InspectionGadgets/InspectionGadgetsAnalysis/src/com/siyeh/ig/numeric/IntegerMultiplicationImplicitCastToLongInspection.java<<>>
<<>> 17 jan 2019 <<>>

private boolean cannotOverflow(@NotNull PsiPolyadicExpression expression, PsiExpression[] operands, boolean shift) {
      CommonDataflow.DataflowResult dfr = CommonDataflow.getDataflowResult(expression);
      if (dfr != null) {
        long min = 1, max = 1;
        for (PsiExpression operand : operands) {
          LongRangeSet set = dfr.getExpressionFact(PsiUtil.skipParenthesizedExprDown(operand), DfaFactType.RANGE);
          if (set == null) return false;
          long nextMin = set.min();
          long nextMax = set.max();
          long r1, r2, r3, r4;
          if (shift) {
            nextMin &= 0x1F;
            nextMax &= 0x1F;
            r1 = min << nextMin;
            r2 = max << nextMin;
            r3 = min << nextMax;
            r4 = max << nextMax;
          } else {
            if (intOverflow(nextMin) || intOverflow(nextMax)) return false;
            r1 = min * nextMin;
            r2 = max * nextMin;
            r3 = min * nextMax;
            r4 = max * nextMax;
          }
          if (intOverflow(r1) || intOverflow(r2) || intOverflow(r3) || intOverflow(r4)) return false;
          min = Math.min(Math.min(r1, r2), Math.min(r3, r4));
          max = Math.max(Math.max(r1, r2), Math.max(r3, r4));
        }
      }
      return true;
    }

    private boolean intOverflow(long l) {
      return (int)l != l && l != Integer.MAX_VALUE + 1L;
    }

    