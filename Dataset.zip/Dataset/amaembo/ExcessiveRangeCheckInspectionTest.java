<<>>plugins/InspectionGadgets/testsrc/com/siyeh/ig/controlflow/ExcessiveRangeCheckInspectionTest.java<<>>
<<>> 22 jan 2019 <<>>

package com.siyeh.ig.controlflow;

import com.intellij.codeInspection.InspectionProfileEntry;
import com.siyeh.ig.LightInspectionTestCase;
import org.jetbrains.annotations.Nullable;

public class ExcessiveRangeCheckInspectionTest extends LightInspectionTestCase {

  public void testExcessiveRangeCheck() {
    doTest();
  }

  @Nullable
  @Override
  protected InspectionProfileEntry getInspection() {
    return new ExcessiveRangeCheckInspection();
  }
}