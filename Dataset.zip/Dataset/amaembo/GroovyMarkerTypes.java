<<>> plugins/groovy/src/org/jetbrains/plugins/groovy/codeInsight/GroovyMarkerTypes.java<<>>
<<>> 23 April 2021 <<>>

public static final MarkerType GR_OVERRIDDEN_METHOD =
    new MarkerType("GR_OVERRIDEN_METHOD", (NullableFunction<PsiElement, String>)element -> {
      PsiElement parent = element.getParent();
      if (!(parent instanceof GrMethod)) return null;
      GrMethod method = (GrMethod)parent;

      final PsiElementProcessor.CollectElementsWithLimit<PsiMethod> processor =
        new PsiElementProcessor.CollectElementsWithLimit<>(5);

      for (GrMethod m : PsiImplUtil.getMethodOrReflectedMethods(method)) {
        OverridingMethodsSearch.search(m).forEach(
          new ReadActionProcessor<>() {
            @Override
            public boolean processInReadAction(PsiMethod method) {
              if (method instanceof GrTraitMethod) {
                return true;
              }
              return processor.execute(method);
            }
          });
      }

      boolean isAbstract = method.hasModifierProperty(PsiModifier.ABSTRACT);

      if (processor.isOverflow()) {
        return isAbstract ? DaemonBundle.message("method.is.implemented.too.many") : DaemonBundle.message("method.is.overridden.too.many");
      }

      PsiMethod[] overridings = processor.toArray(new PsiMethod[processor.getCollection().size()]);
      if (overridings.length == 0) return null;

      Comparator<PsiMethod> comparator = new MethodCellRenderer.MethodCellRenderingInfo(false).getComparator();
      Arrays.sort(overridings, comparator);

      String start = isAbstract ? DaemonBundle.message("method.is.implemented.header") : DaemonBundle.message("method.is.overriden.header");
      @NonNls String pattern = "&nbsp;&nbsp;&nbsp;&nbsp;{1}";
      return GutterIconTooltipHelper.composeText(overridings, start, pattern);
    }, new LineMarkerNavigator() {