<<>>javajava-implsrccomintellijcodeInsightintentionimplIntroduceVariableIntentionAction.java<<>>
<<>> 23 April 2021<<>>

 if (expression.getParent() instanceof PsiExpressionStatement) {
      if (!PsiUtil.isStatement(expression.getParent()) ||
          expression.getParent().getLastChild() instanceof PsiErrorElement &&
          editor.getCaretModel().getOffset() == expression.getParent().getTextRange().getEndOffset()) {
        // Same action is available as an error quick-fix
        return false;
      }

