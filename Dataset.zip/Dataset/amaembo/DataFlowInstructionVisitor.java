<<>>java/java-analysis-impl/src/com/intellij/codeInspection/dataFlow/DataFlowInstructionVisitor.java<<>>
<<>> 23 April 2021<<>>

public void onConditionFailure(@NotNull PsiExpression anchor, boolean alwaysNegative) {
    if (anchor.getParent() instanceof PsiNewExpression) {
      myNegativeArraySizes.merge(anchor, ThreeState.fromBoolean(alwaysNegative), ThreeState::merge);
    }

