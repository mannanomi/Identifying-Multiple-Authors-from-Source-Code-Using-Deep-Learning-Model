<<>> java/java-impl/src/com/intellij/ide/util/MethodCellRenderer.java<<>>
<<>> 23 April 2021 <<>>

public class MethodCellRenderer extends DelegatingPsiElementCellRenderer<PsiMethod> {
  public static class MethodCellRenderingInfo implements PsiElementCellRenderingInfo<PsiMethod> {
    private final boolean myShowMethodNames;
    @PsiFormatUtil.FormatMethodOptions
    private final int myOptions;

<<>> 23 April 2021 <<>>

public MethodCellRenderingInfo(boolean showMethodNames) {
      this(showMethodNames, PsiFormatUtilBase.SHOW_NAME | PsiFormatUtilBase.SHOW_PARAMETERS);
    }
    public MethodCellRenderingInfo(boolean showMethodNames, @PsiFormatUtil.FormatMethodOptions int options) {
      myShowMethodNames = showMethodNames;
      myOptions = options;
    }

<<>> 23 April 2021 <<>>

 @Override
    public Icon getIcon(PsiElement element) {
      return PsiElementCellRenderingInfo.super.getIcon(myShowMethodNames ? element : fetchContainer((PsiMethod)element));
    }

    @Override
    public int getIconFlags() {
      return PsiClassListCellRenderer.INFO.getIconFlags();
    }

    @Override
    public String getElementText(PsiMethod element) {
      final PsiNamedElement container = fetchContainer(element);
      String text = container instanceof PsiClass ? PsiClassListCellRenderer.INFO.getElementText((PsiClass)container) : container.getName();
      if (myShowMethodNames) {
        text += "."+PsiFormatUtil.formatMethod(element, PsiSubstitutor.EMPTY, myOptions, PsiFormatUtilBase.SHOW_TYPE);
      }
      return text;
    }

    @Override
    public String getContainerText(PsiMethod element, String name) {
      return PsiClassListCellRenderer.getContainerTextStatic(element);


<<>> 23 April 2021 <<>>


public MethodCellRenderer(boolean showMethodNames) {
    this(showMethodNames, PsiFormatUtilBase.SHOW_NAME | PsiFormatUtilBase.SHOW_PARAMETERS);
  }

  public MethodCellRenderer(boolean showMethodNames, @PsiFormatUtil.FormatMethodOptions int options) {
    super(new MethodCellRenderingInfo(showMethodNames, options));





