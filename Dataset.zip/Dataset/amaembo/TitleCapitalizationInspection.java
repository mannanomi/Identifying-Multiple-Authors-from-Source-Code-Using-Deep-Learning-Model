<<>>plugins/java-i18n/src/com/intellij/codeInspection/i18n/TitleCapitalizationInspection.java<<>>
<<>> 22 Oct 2020<<>>

private int getMessagesForPart(int index) {
      MessagePattern.Part part = myPattern.getPart(index);
      if (part.getType() != MessagePattern.Part.Type.ARG_START) return 0;
      int limitPart = myPattern.getLimitPartIndex(index);
      int msgCount = 0;
      int nesting = -1;
      for (int i = index + 1; i < limitPart; i++) {
        part = myPattern.getPart(i);
        if (part.getType() == MessagePattern.Part.Type.MSG_START) {
          if (nesting == -1) {
            nesting = part.getValue();
          }
          else if (nesting != part.getValue()) {
            continue;
          }
          msgCount++;
        }
      }
      return msgCount;
    }

<<>> 22 Oct 2020<<>>


 int parts = myPattern.countParts();
      int maxMsgCount = IntStreamEx.range(parts).map(i -> getMessagesForPart(i)).append(1).max().orElse(1);
      String string = myPattern.getPatternString();
      for (int curIndex = 0; curIndex < maxMsgCount; curIndex++) {
        StringBuilder sample = new StringBuilder();
        int msgIndex = 0;
        int nestingLevel = 0;
        int curMsgCount = 0;
        boolean inMsg = false;
        for (int i = 1; i < parts; i++) {
          MessagePattern.Part part = myPattern.getPart(i);
          boolean shouldCopyPart = nestingLevel == 0 || inMsg && msgIndex == curIndex % curMsgCount + 1;
          if (shouldCopyPart) {
            sample.append(string, myPattern.getPart(i - 1).getLimit(), myPattern.getPatternIndex(i));
          }
          if (part.getType() == MessagePattern.Part.Type.ARG_START) {
            nestingLevel++;
            MessagePattern.ArgType argType = part.getArgType();
            if ((argType == MessagePattern.ArgType.SIMPLE || argType == MessagePattern.ArgType.NONE) && shouldCopyPart) {
              sample.append("_");


<<>> 22 Oct 2020<<>>

 msgIndex = 0;
            curMsgCount = Math.max(1, getMessagesForPart(i));
          }
          else if (part.getType() == MessagePattern.Part.Type.MSG_START) {
            msgIndex++;
            inMsg = true;
          }
          else if (part.getType() == MessagePattern.Part.Type.MSG_LIMIT) {
            inMsg = false;
          }
          else if (part.getType() == MessagePattern.Part.Type.ARG_LIMIT) {
            nestingLevel--;