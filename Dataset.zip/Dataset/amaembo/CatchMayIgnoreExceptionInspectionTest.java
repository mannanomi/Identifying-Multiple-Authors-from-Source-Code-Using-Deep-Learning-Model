<<>>plugins/InspectionGadgets/testsrc/com/siyeh/ig/errorhandling/CatchMayIgnoreExceptionInspectionTest.java<<>>
<<>> 26 April 2021 <<>>

 public void testSneakyThrow() {
    doTest("class Exc {\n" +
           "  Object apply() {\n" +
           "    try {\n" +
           "      return foo();\n" +
           "    } catch (Throwable t) {\n" +
           "      throw throwChecked(t);\n" +
           "    }\n" +
           "  }\n" +
           "  \n" +
           "  native Object foo() throws Exception;\n" +
           "  \n" +
           "  @SuppressWarnings(\"unchecked\")\n" +
           "  private static <T extends Throwable> RuntimeException throwChecked(Throwable t) throws T {\n" +
           "    throw (T) t;\n" +
           "  }\n" +
           "}\n");
  }

