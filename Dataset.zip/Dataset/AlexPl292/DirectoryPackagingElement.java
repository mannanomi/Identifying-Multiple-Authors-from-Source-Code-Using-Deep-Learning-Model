<<>>java/compiler/impl/src/com/intellij/packaging/impl/elements/DirectoryPackagingElement.java<<>>
<<>> 27 April 2021 <<>>

// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.packaging.impl.elements;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.packaging.elements.PackagingElement;
import com.intellij.packaging.impl.ui.DirectoryElementPresentation;
import com.intellij.packaging.ui.ArtifactEditorContext;
import com.intellij.packaging.ui.PackagingElementPresentation;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xmlb.XmlSerializerUtil;
import com.intellij.util.xmlb.annotations.Attribute;
import com.intellij.workspaceModel.storage.EntitySource;
import com.intellij.workspaceModel.storage.WorkspaceEntity;
import com.intellij.workspaceModel.storage.WorkspaceEntityStorageBuilder;
import com.intellij.workspaceModel.storage.bridgeEntities.BridgeModelModifiableEntitiesKt;
import com.intellij.workspaceModel.storage.bridgeEntities.ModifiableDirectoryPackagingElementEntity;
import com.intellij.workspaceModel.storage.bridgeEntities.PackagingElementEntity;
import kotlin.Unit;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * classpath is used for exploded WAR and EJB directories under exploded EAR
 */
	@@ -49,12 +60,24 @@ public String toString() {
  }

  public void setDirectoryName(String directoryName) {
    changeName(directoryName);
  }

  @Override
  public void rename(@NotNull String newName) {
    changeName(newName);
  }

  private void changeName(@NotNull String newName) {
    this.update(
      () -> myDirectoryName = newName,
      (builder, entity) -> {
        builder.modifyEntity(ModifiableDirectoryPackagingElementEntity.class, entity, ent ->{
          ent.setDirectoryName(newName);
          return Unit.INSTANCE;
        });
      }, true
    );
  }

  @Override
	@@ -67,6 +90,22 @@ public boolean isEqualTo(@NotNull PackagingElement<?> element) {
    return element instanceof DirectoryPackagingElement && ((DirectoryPackagingElement)element).getDirectoryName().equals(myDirectoryName);
  }

  @Override
  public WorkspaceEntity getOrAddEntity(@NotNull WorkspaceEntityStorageBuilder diff,
                                        @NotNull EntitySource source,
                                        @NotNull Project project) {
    WorkspaceEntity existingEntity = getExistingEntity(diff);
    if (existingEntity != null) return existingEntity;

    List<PackagingElementEntity> children = ContainerUtil.map(this.getChildren(), o -> {
      return (PackagingElementEntity)o.getOrAddEntity(diff, source, project);
    });

    var entity = BridgeModelModifiableEntitiesKt.addDirectoryPackagingElementEntity(diff, this.myDirectoryName, children, source);
    diff.getMutableExternalMapping("intellij.artifacts.packaging.elements").addMapping(entity, this);
    return entity;
  }

  @Override
  public void loadState(@NotNull DirectoryPackagingElement state) {
    XmlSerializerUtil.copyBean(state, this);