<<>>platform/lang-impl/src/com/intellij/internal/retype/RetypeSession.java <<>>
<<>> 29 Nov 2018 <<>>

import com.intellij.openapi.editor.actionSystem.LatencyRecorder
import com.intellij.openapi.editor.impl.EditorImpl
import com.intellij.openapi.fileEditor.FileDocumentManager
import com.intellij.openapi.fileEditor.FileEditor
import com.intellij.openapi.fileEditor.OpenFileDescriptor
import com.intellij.openapi.fileEditor.impl.text.PsiAwareTextEditorImpl
import com.intellij.openapi.project.Project
import com.intellij.openapi.roots.ProjectRootManager
import com.intellij.openapi.ui.playback.commands.ActionCommand
import com.intellij.openapi.util.Disposer
import com.intellij.openapi.util.Key
import com.intellij.openapi.vfs.VfsUtil
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.openapi.wm.IdeFocusManager
import com.intellij.ui.EditorNotificationPanel
import com.intellij.ui.EditorNotifications
import com.intellij.ui.LightColors
import com.intellij.util.Alarm
import java.awt.event.KeyEvent
import java.io.File
	@@ -148,6 +154,8 @@ class RetypeSession(
  private var stopInterfereFileChanger = false
  val interfereFileName = "IdeaRetypeBackgroundChanges.java"

  var retypePaused: Boolean = false

  init {
    if (editor.selectionModel.hasSelection()) {
      pos = editor.selectionModel.selectionStart
	@@ -186,6 +194,8 @@ class RetypeSession(
    }
    CodeInsightWorkspaceSettings.getInstance(project).optimizeImportsOnTheFly = false
    runInterfereFileChanger()
    EditorNotifications.getInstance(project).updateNotifications(editor.virtualFile)
    retypePaused = false
    queueNextOrStop()
  }

	@@ -217,6 +227,7 @@ class RetypeSession(
      startNextCallback?.invoke()
    }
    stopInterfereFileChanger = true
    EditorNotifications.getInstance(project).updateAllNotifications()
  }

  override fun dispose() {
	@@ -237,6 +248,18 @@ class RetypeSession(
  }

  private fun typeNextInEDT(timerTick: Long) {
    if (retypePaused) {
      if (editor.contentComponent == IdeFocusManager.findInstance().focusOwner) {
        // Resume retyping on editor focus
        retypePaused = false
      }
      else {
        queueNextOrStop()
        return
      }
    }

    EditorNotifications.getInstance(project).updateAllNotifications()
    waitingForTimerInvokeLater = false
    val processNextEvent = handleIdeaIntelligence()
    if (processNextEvent) return
	@@ -261,8 +284,10 @@ class RetypeSession(
      }
    }

    // Do not perform typing if editor is not in focus
    if (editor.contentComponent != IdeFocusManager.findInstance().focusOwner) retypePaused = true

    if (retypePaused) {
      queueNextOrStop()
      return
    }
	@@ -526,3 +551,29 @@ class RetypeSession(
}

val RETYPE_SESSION_KEY = Key.create<RetypeSession>("com.intellij.internal.retype.RetypeSession")
val RETYPE_SESSION_NOTIFICATION_KEY = Key.create<EditorNotificationPanel>("com.intellij.internal.retype.RetypeSessionNotification")


class RetypeEditorNotificationProvider : EditorNotifications.Provider<EditorNotificationPanel>() {
  override fun getKey(): Key<EditorNotificationPanel> = RETYPE_SESSION_NOTIFICATION_KEY

  override fun createNotificationPanel(file: VirtualFile, fileEditor: FileEditor): EditorNotificationPanel? {
    val retypeSession = (fileEditor as PsiAwareTextEditorImpl).editor.getUserData(RETYPE_SESSION_KEY)
    if (retypeSession == null) return null

    val panel: EditorNotificationPanel

    if (retypeSession.retypePaused) {
      panel = EditorNotificationPanel()
      panel.setText("Pause retyping. Click on editor to resume")
    }
    else {
      panel = EditorNotificationPanel(LightColors.SLIGHTLY_GREEN)
      panel.setText("Retyping")
    }
    panel.createActionLabel("Stop without report") {
      retypeSession.stop(false)
    }
      
      
      
      
      

<<>>23 Nov 2018<<>>

import com.intellij.openapi.vfs.VfsUtil
import com.intellij.util.Alarm
import java.io.File
import java.util.*

class RetypeSession(
  private val project: Project,
	@@ -131,53 +132,8 @@ class RetypeSession(
  private fun typeNext() {
    threadDumpAlarm.addRequest({ logThreadDump() }, threadDumpDelay)

    val processNextEvent = handleIdeaIntelligence()
    if (processNextEvent) return

    if (TemplateManager.getInstance(project).getActiveTemplate(editor) != null) {
      TemplateManager.getInstance(project).finishTemplate(editor)
	@@ -227,6 +183,122 @@ class RetypeSession(
    queueNextOrStop()
  }

  /**
   * @return if next queue event should be processed
   */
  private fun handleIdeaIntelligence(): Boolean {
    // This stack will contain autocompletion elements
    // E.g. "}", "]", "*/", "* @return"
    val completionStack = ArrayDeque<String>()

    if (document.text.take(pos) != originalText.take(pos)) {
      // Unexpected changes before current cursor position
      // (may be unwanted import)
      if (textBeforeLookupSelection != null) {
        // Unexpected changes was made by lookup.
        // Restore previous text state and set flag to skip further suggestions until whitespace will be typed
        WriteCommandAction.runWriteCommandAction(project) {
          document.replaceText(textBeforeLookupSelection ?: return@runWriteCommandAction, document.modificationStamp + 1)
        }
        skipLookupSuggestion = true
      }
      else {
        // There changes wasn't made by lookup, so we don't know how to handle them
        // Restore text as it should be at this point without any intelligence
        WriteCommandAction.runWriteCommandAction(project) {
          document.replaceText(originalText.take(pos) + originalText.takeLast(endPos), document.modificationStamp + 1)
        }
      }
    }

    if (editor.caretModel.offset > pos) {
      // Caret movement has been preformed
      // Move the caret forward until the characters match
      while (pos < document.textLength - tailLength
             && originalText[pos] == document.text[pos]
             && document.text[pos] !in listOf('\n') // Don't count line breakers because we want to enter "enter" explicitly
      ) {
        pos++
        completedChars++
      }
      if (editor.caretModel.offset > pos) {
        WriteCommandAction.runWriteCommandAction(project) {
          // Delete symbols not from original text and move caret
          document.deleteString(pos, editor.caretModel.offset)
        }
      }
      editor.caretModel.moveToOffset(pos)
    }

    if (document.textLength > pos + tailLength) {
      updateStack(completionStack)
      val firstCompletion = completionStack.peekLast()

      if (firstCompletion != null) {
        val origIndexOfFirstCompletion = originalText.substring(pos, endPos).trim().indexOf(firstCompletion)

        if (origIndexOfFirstCompletion == 0) {
          // Next non-whitespace chars from original tests are from complation stack
          val origIndexOfFirstComp = originalText.substring(pos, endPos).indexOf(firstCompletion)
          val docIndexOfFirstComp = document.text.indexOf(firstCompletion, startIndex = pos)
          if (originalText.substring(pos, (pos + origIndexOfFirstComp).coerceAtMost(originalText.length))
            != document.text.substring(pos, (pos + origIndexOfFirstComp).coerceAtMost(document.textLength))) {
            // We have some unexpected chars before completion. Remove them
            WriteCommandAction.runWriteCommandAction(project) {
              document.replaceString(pos, pos + docIndexOfFirstComp, originalText.substring(pos, pos + origIndexOfFirstComp))
            }
          }
          pos += origIndexOfFirstComp + firstCompletion.length
          editor.caretModel.moveToOffset(pos)
          completionStack.removeLast()
          queueNextOrStop()
          return true
        }
        else if (origIndexOfFirstCompletion < 0) {
          // Completion is wrong and original text doesn't contain it
          // Remove this completion
          val docIndexOfFirstComp = document.text.indexOf(firstCompletion, startIndex = pos)
          WriteCommandAction.runWriteCommandAction(project) {
            document.replaceString(pos, pos + docIndexOfFirstComp + firstCompletion.length, "")
          }
          completionStack.removeLast()
          queueNextOrStop()
          return true
        }
      }
    }
    else if (document.textLength == pos + tailLength && completionStack.isNotEmpty()) {
      // Text is as expected, but we have some extra completions in stack
      completionStack.clear()
    }
    return false
  }

  private fun updateStack(completionStack: Deque<String>) {
    val unexpectedCharsDoc = document.text.substring(pos, document.textLength - tailLength)

    var endPosDoc = unexpectedCharsDoc.length

    val completionIterator = completionStack.iterator()
    while (completionIterator.hasNext()) {
      // Validate all existing completions and add new completions if they are
      val completion = completionIterator.next()
      val lastIndexOfCompletion = unexpectedCharsDoc.lastIndexOf(completion, startIndex = endPosDoc - 1)
      if (lastIndexOfCompletion < 0) {
        completionIterator.remove()
        continue
      }
      endPosDoc = lastIndexOfCompletion
    }

    // Add new completion in stack
    unexpectedCharsDoc.substring(0, endPosDoc).trim().split("\\s+".toRegex()).map { it.trim() }.reversed().forEach {
      if (it.isNotEmpty()) {
        completionStack.add(it)
      }
    }
  }

  private fun queueNextOrStop() {
    if (pos < endPos) {
      queueNext()   
      
      
          
 <<>> 23 Nov 2018 <<>>     
      
import com.intellij.openapi.vfs.VfsUtil
import com.intellij.util.Alarm
import java.io.File
import java.util.*

class RetypeSession(
  private val project: Project,
	@@ -128,6 +129,8 @@ class RetypeSession(
    }
  }

  val completionStack = ArrayDeque<String>()

  private fun typeNext() {
    threadDumpAlarm.addRequest({ logThreadDump() }, threadDumpDelay)

	@@ -161,20 +164,33 @@ class RetypeSession(
        pos++
        completedChars++
      }
      WriteCommandAction.runWriteCommandAction(project) {
        document.deleteString(pos, editor.caretModel.offset)
        editor.caretModel.moveToOffset(pos)
      }
    }

    if (document.textLength > pos + tailLength) {
      checkStack()
      val firstCompletion = completionStack.peekLast()

      if (firstCompletion != null) {
        val indexOfFirstCompletion = originalText.substring(pos, endPos).trim().indexOf(firstCompletion.trim())
        // Handle -1

        if (indexOfFirstCompletion == 0) {
          val origIndexOfFirstComp = originalText.substring(pos, endPos).indexOf(firstCompletion.trim())
          val docIndexOfFirstComp = document.text.substring(pos).indexOf(firstCompletion.trim())
          if (originalText.substring(pos).take(origIndexOfFirstComp) != document.text.substring(pos).take(origIndexOfFirstComp)) {
            WriteCommandAction.runWriteCommandAction(project) {
              document.replaceString(pos, pos + docIndexOfFirstComp, originalText.substring(pos).take(origIndexOfFirstComp))
            }
          }
          pos += origIndexOfFirstComp + firstCompletion.trim().length
          editor.caretModel.moveToOffset(pos)
          completionStack.removeLast()
          queueNextOrStop()
          return
        }
      }
    }
	@@ -227,6 +243,28 @@ class RetypeSession(
    queueNextOrStop()
  }

  fun checkStack() {
    val unexpectedCharsDoc = document.text.substring(pos, document.textLength - tailLength)

    var endPosDoc = unexpectedCharsDoc.length

    val completionIterator = completionStack.iterator()
    while (completionIterator.hasNext()) {
      val completion = completionIterator.next()
      val lastIndexOfCompletion = unexpectedCharsDoc.substring(0, endPosDoc).lastIndexOf(completion.trim())
      if (lastIndexOfCompletion < 0) {
        completionIterator.remove()
        continue
      }
      endPosDoc = lastIndexOfCompletion
    }

    val unstackedCompletion = unexpectedCharsDoc.substring(0, endPosDoc)
    if (unstackedCompletion.trim().isNotEmpty()) {
      completionStack.add(unstackedCompletion.trim())
    }
  }

  private fun queueNextOrStop() {
    if (pos < endPos) {
      queueNext()
	    
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    return panel
  }
}