<<>>platform/lang-impl/src/com/intellij/codeInsight/daemon/impl/focusMode/FocusModePassFactory.java<<>>
<<>> 122 April 2019 <<>>


import com.intellij.codeHighlighting.TextEditorHighlightingPassRegistrar;
import com.intellij.lang.LanguageExtension;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.ex.EditorSettingsExternalizable;
import com.intellij.openapi.editor.ex.util.EditorUtil;
import com.intellij.openapi.editor.impl.EditorImpl;
import com.intellij.openapi.editor.impl.FocusModeModel;
import com.intellij.openapi.editor.impl.FocusRegion;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.util.Segment;
import com.intellij.psi.FileViewProvider;
	@@ -26,9 +26,12 @@
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FocusModePassFactory implements TextEditorHighlightingPassFactory {
  private static final Key<Set<FocusRegion>> FOCUS_REGIONS_FROM_PASS = Key.create("editor.focus.mode.segmentsFromPass");
  private static final LanguageExtension<FocusModeProvider> EP_NAME = new LanguageExtension<>("com.intellij.focusModeProvider");
  private static final long MAX_ALLOWED_TIME = 100;
  private static final Logger LOG = Logger.getInstance(FocusModePassFactory.class);
	@@ -81,14 +84,36 @@ private static boolean isEnabled() {
  }

  public static void setToEditor(@NotNull List<? extends Segment> zones, Editor editor) {
    mergeSegments(editor, zones);
  }

  private static void mergeSegments(Editor editor, @NotNull List<? extends Segment> zones) {
    if (!(editor instanceof EditorImpl)) return;
    FocusModeModel focusModeModel = ((EditorImpl)editor).getFocusModeModel();

    Set<FocusRegion> focusRegions = ((EditorImpl)editor).putUserDataIfAbsent(FOCUS_REGIONS_FROM_PASS, new HashSet<>());
    Set<FocusRegion> invalidFocusRegions = new HashSet<>(focusRegions);
    for (Segment zone : zones) {
      FocusRegion foundRegion = focusModeModel.findFocusRegion(zone.getStartOffset(), zone.getEndOffset());
      if (foundRegion == null) {
        FocusRegion newRegion = focusModeModel.createFocusRegion(zone.getStartOffset(), zone.getEndOffset());
        focusRegions.add(newRegion);
      }
      else {
        if (focusRegions.contains(foundRegion)) {
          // Region exists and belongs to this provider. Leave in focusRegions
          invalidFocusRegions.remove(foundRegion);
        }
        else {
          LOG.warn("Trying to add existing focus region. startOffset: " + zone.getStartOffset() + ", endOffset: " + zone.getEndOffset());
        }
      }
    }
    for (FocusRegion invalidFocusRegion : invalidFocusRegions) {
      // Dispose and delete invalid and removed focus markers
      focusModeModel.removeFocusRegion(invalidFocusRegion);
      focusRegions.remove(invalidFocusRegion);
    }
  }

  private static class FocusModePass extends EditorBoundHighlightingPass {