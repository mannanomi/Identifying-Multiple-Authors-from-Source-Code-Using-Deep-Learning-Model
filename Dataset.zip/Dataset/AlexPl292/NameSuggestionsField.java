<<>>platform/lang-impl/src/com/intellij/refactoring/ui/NameSuggestionsField.java<<>>
<<>> 15 Jan 2019 <<>>

 private boolean myNonHumanChange = false;

  private String[] myNameSuggestions;

  public NameSuggestionsField(Project project) {
    super(new BorderLayout());
    myProject = project;
    myComboBoxModel = new MyComboBoxModel();
    final ComboBox comboBox = new ComboBox(myComboBoxModel,-1);
    myComponent = comboBox;
    myNameSuggestions = ArrayUtil.EMPTY_STRING_ARRAY;
    add(myComponent, BorderLayout.CENTER);
    setupComboBox(comboBox, StdFileTypes.JAVA);
  }
	@@ -56,6 +59,7 @@ public NameSuggestionsField(String[] nameSuggestions, Project project) {
  public NameSuggestionsField(String[] nameSuggestions, Project project, FileType fileType) {
    super(new BorderLayout());
    myProject = project;
    myNameSuggestions = nameSuggestions;
    if (nameSuggestions == null || nameSuggestions.length <= 1) {
      myComponent = createTextFieldForName(nameSuggestions, fileType);
    }
	@@ -169,6 +173,15 @@ public String getEnteredName() {
    }
  }

  public void setEnteredName(String name) {
    if (myComponent instanceof JComboBox) {
      ((JComboBox)myComponent).getEditor().setItem(name);
    }
    else {
      ((EditorTextField)myComponent).setText(name);
    }
  }

  public boolean hasSuggestions() {
    return myComponent instanceof JComboBox;
  }
	@@ -187,6 +200,10 @@ private JComponent createTextFieldForName(String[] nameSuggestions, FileType fil
    return field;
  }

  public String[] getNameSuggestions() {
    return myNameSuggestions;
  }

  private static class MyComboBoxModel extends DefaultComboBoxModel {
    private String[] mySuggestions;