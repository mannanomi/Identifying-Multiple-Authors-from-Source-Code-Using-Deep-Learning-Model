<<>>java/compiler/impl/src/com/intellij/packaging/impl/artifacts/workspacemodel/ArtifactManagerBridge.java<<>>
<<>> 27 April 2021<<>>

package com.intellij.packaging.impl.artifacts.workspacemodel

import com.intellij.compiler.server.BuildManager
import com.intellij.openapi.Disposable
import com.intellij.openapi.application.WriteAction
import com.intellij.openapi.project.Project
import com.intellij.openapi.roots.ex.ProjectRootManagerEx
import com.intellij.openapi.util.JDOMUtil
import com.intellij.openapi.util.ModificationTracker
import com.intellij.openapi.util.SimpleModificationTracker
import com.intellij.openapi.util.ThrowableComputable
import com.intellij.openapi.vfs.VirtualFileManager
import com.intellij.packaging.artifacts.*
import com.intellij.packaging.elements.CompositePackagingElement
import com.intellij.packaging.elements.PackagingElement
import com.intellij.packaging.elements.PackagingElementFactory
import com.intellij.packaging.elements.PackagingElementResolvingContext
import com.intellij.packaging.impl.artifacts.ArtifactModelBase
import com.intellij.packaging.impl.artifacts.ArtifactPointerManagerImpl
import com.intellij.packaging.impl.artifacts.ArtifactVirtualFileListener
import com.intellij.packaging.impl.artifacts.DefaultPackagingElementResolvingContext
import com.intellij.util.concurrency.annotations.RequiresReadLock
import com.intellij.util.concurrency.annotations.RequiresWriteLock
import com.intellij.util.xmlb.XmlSerializer
import com.intellij.workspaceModel.ide.WorkspaceModel
import com.intellij.workspaceModel.storage.*
import com.intellij.workspaceModel.storage.bridgeEntities.ArtifactEntity
import com.intellij.workspaceModel.storage.bridgeEntities.ArtifactId
import com.intellij.workspaceModel.storage.bridgeEntities.CustomPackagingElementEntity
import com.intellij.workspaceModel.storage.bridgeEntities.ModifiableCustomPackagingElementEntity

class ArtifactManagerBridge(private val project: Project) : ArtifactManager(), Disposable {

  private val modificationTracker = SimpleModificationTracker()

  private val resolvingContext = DefaultPackagingElementResolvingContext(project)

  internal val artifactWithDiffs: MutableList<ArtifactBridge> = mutableListOf()

  init {
    (ArtifactPointerManager.getInstance(project) as ArtifactPointerManagerImpl).setArtifactManager(this)
    project.messageBus.connect(this).subscribe(VirtualFileManager.VFS_CHANGES, ArtifactVirtualFileListener(project, this))
    DynamicArtifactExtensionsLoaderBridge(this).installListeners(this)
  }

  @RequiresReadLock
  override fun getArtifacts(): Array<ArtifactBridge> {
    initBridges()

    val workspaceModel = WorkspaceModel.getInstance(project)
    val entityStorage = workspaceModel.entityStorage

    val store = entityStorage.current

    val artifacts = store
      .entities(ArtifactEntity::class.java)
      .map { store.artifactsMap.getDataByEntity(it) ?: error("All artifact bridges should be already created at this moment") }
      .filter { ArtifactModelBase.VALID_ARTIFACT_CONDITION.value(it) }
      .toList().toTypedArray()

    return artifacts
  }

  @RequiresReadLock
  override fun findArtifact(name: String): Artifact? {
    initBridges()

    val workspaceModel = WorkspaceModel.getInstance(project)
    val entityStorage = workspaceModel.entityStorage
    val store = entityStorage.current

    val artifactEntity = store.resolve(ArtifactId(name)) ?: return null

    return store.artifactsMap.getDataByEntity(artifactEntity)
           ?: error("All artifact bridges should be already created at this moment")
  }

  override fun getArtifactByOriginal(artifact: Artifact): Artifact = artifact

  override fun getOriginalArtifact(artifact: Artifact): Artifact = artifact

  @RequiresReadLock
  override fun getArtifactsByType(type: ArtifactType): List<ArtifactBridge> {
    initBridges()

    val workspaceModel = WorkspaceModel.getInstance(project)
    val entityStorage = workspaceModel.entityStorage
    val store = entityStorage.current
    val typeId = type.id

    return store
      .entities(ArtifactEntity::class.java)
      .filter { it.artifactType == typeId }
      .map { store.artifactsMap.getDataByEntity(it) ?: error("All artifact bridges should be already created at this moment") }
      .toList()
  }

  @RequiresReadLock
  override fun getAllArtifactsIncludingInvalid(): MutableList<out Artifact> {
    initBridges()

    val entityStorage = WorkspaceModel.getInstance(project).entityStorage
    val storage = entityStorage.current

    return storage
      .entities(ArtifactEntity::class.java)
      .map {
        storage.artifactsMap.getDataByEntity(it) ?: error("All artifact bridges should be already created at this moment")
      }
      .toMutableList()
  }

  override fun getSortedArtifacts(): Array<ArtifactBridge> {
    val artifacts = this.artifacts

    // TODO: 02.02.2021 Do not sort them each time
    artifacts.sortWith(ARTIFACT_COMPARATOR)
    return artifacts
  }

  override fun createModifiableModel(): ModifiableArtifactModel {
    val storage = WorkspaceModel.getInstance(project).entityStorage.current
    return ArtifactModifiableModelBridge(project, WorkspaceEntityStorageBuilder.from(storage), this)
  }

  override fun getResolvingContext(): PackagingElementResolvingContext = resolvingContext

  override fun addArtifact(name: String, type: ArtifactType, root: CompositePackagingElement<*>?): Artifact {
    return WriteAction.compute(ThrowableComputable<ModifiableArtifact, RuntimeException> {
      val model = createModifiableModel()
      val artifact = model.addArtifact(name, type)
      if (root != null) {
        artifact.rootElement = root
      }
      model.commit()
      artifact
    })
  }

  override fun addElementsToDirectory(artifact: Artifact, relativePath: String, elements: Collection<PackagingElement<*>>) {
    val model = createModifiableModel()
    val root = model.getOrCreateModifiableArtifact(artifact).rootElement
    PackagingElementFactory.getInstance().getOrCreateDirectory(root, relativePath).addOrFindChildren(elements)
    WriteAction.run<RuntimeException> { model.commit() }
  }

  override fun addElementsToDirectory(artifact: Artifact, relativePath: String, element: PackagingElement<*>) {
    addElementsToDirectory(artifact, relativePath, listOf(element))
  }

  override fun getModificationTracker(): ModificationTracker {
    return modificationTracker
  }

  @RequiresWriteLock
  fun commit(artifactModel: ArtifactModifiableModelBridge) {
    updateCustomElements(artifactModel.diff)

    val current = WorkspaceModel.getInstance(project).entityStorage.current
    val changes = artifactModel.diff.collectChanges(current)[ArtifactEntity::class.java] ?: emptyList()

    val removed = mutableSetOf<ArtifactBridge>()
    val added = mutableListOf<ArtifactBridge>()
    val changed = mutableListOf<Triple<ArtifactBridge, String, ArtifactBridge>>()
    val changedArtifacts: MutableList<ArtifactBridge> = mutableListOf()

    changes.forEach {
      when (it) {
        is EntityChange.Removed<*> -> current.artifactsMap.getDataByEntity(it.entity)?.let { it1 -> removed.add(it1) }
        is EntityChange.Added -> Unit
        is EntityChange.Replaced -> {
          // Collect changes and transfer info from the modifiable bridge artifact to the original artifact
          val originalArtifact = artifactModel.diff.artifactsMap.getDataByEntity(it.newEntity)!!
          val modifiableArtifact = artifactModel.modifiableToOriginal.getKeysByValue(originalArtifact)!!.single()
          if (modifiableArtifact !== originalArtifact) {
            changedArtifacts.add(modifiableArtifact)
          }
          artifactModel.modifiableToOriginal.remove(modifiableArtifact, originalArtifact)
          originalArtifact.copyFrom(modifiableArtifact)
          changed.add(Triple(originalArtifact, (it.oldEntity as ArtifactEntity).name, modifiableArtifact))
          originalArtifact.setActualStorage()
        }
      }
    }

    artifactModel.modifiableToOriginal.entries.forEach { (modifiable, original) ->
      if (modifiable !== original) {
        changedArtifacts.add(modifiable)
        val oldName = original.name
        original.copyFrom(modifiable)
        changed.add(Triple(original, oldName, modifiable))
      }
    }

    (ArtifactPointerManager.getInstance(project) as ArtifactPointerManagerImpl).disposePointers(changedArtifacts)
    artifactModel.modifiableToOriginal.clear()

    WorkspaceModel.getInstance(project).updateProjectModel {
      it.addDiff(artifactModel.diff)
    }

    modificationTracker.incModificationCount()

    // Collect changes
    changes.forEach {
      when (it) {
        is EntityChange.Added<*> -> {
          val artifactBridge = artifactModel.diff.artifactsMap.getDataByEntity(it.entity)!!
          added.add(artifactBridge)
          artifactBridge.setActualStorage()
        }
        is EntityChange.Removed<*> -> Unit
        is EntityChange.Replaced<*> -> Unit
      }
    }

    // Set actual storages
    artifactWithDiffs.forEach { it.setActualStorage() }
    artifactWithDiffs.clear()

    val entityStorage = WorkspaceModel.getInstance(project).entityStorage
    added.forEach {
      it.elementsWithDiff.forEach { it.setStorage(entityStorage, project, HashSet(), PackagingElementInitializer) }
      it.elementsWithDiff.clear()
    }
    changed.forEach {
      it.third.elementsWithDiff.forEach { it.setStorage(entityStorage, project, HashSet(), PackagingElementInitializer) }
      it.third.elementsWithDiff.clear()
      it.first.elementsWithDiff.forEach { it.setStorage(entityStorage, project, HashSet(), PackagingElementInitializer) }
      it.first.elementsWithDiff.clear()
    }
    artifactModel.elementsWithDiff.forEach { it.setStorage(entityStorage, project, HashSet(), PackagingElementInitializer) }
    artifactModel.elementsWithDiff.clear()

    val publisher: ArtifactListener = project.messageBus.syncPublisher(TOPIC)
    ProjectRootManagerEx.getInstanceEx(project).mergeRootsChangesDuring {
      //it's important to send 'removed' events before 'added'. Otherwise when artifacts are reloaded from xml artifact pointers will be damaged
      removed.forEach { publisher.artifactRemoved(it) }
      added.forEach { publisher.artifactAdded(it) }
      changed.forEach { (artifact, oldName) -> publisher.artifactChanged(artifact, oldName) }
    }

    // TODO: 17.02.2021 Update watch roots

    if (changes.isNotEmpty()) {
      BuildManager.getInstance().clearState(project)
    }
  }

  private fun updateCustomElements(diff: WorkspaceEntityStorageBuilder) {
    val customEntities = diff.entities(CustomPackagingElementEntity::class.java).toList()
    for (customEntity in customEntities) {
      val packagingElement = diff.elements.getDataByEntity(customEntity) ?: continue
      val state = packagingElement.state ?: continue
      val newState = JDOMUtil.write(XmlSerializer.serialize(state))
      if (newState != customEntity.propertiesXmlTag) {
        diff.modifyEntity(ModifiableCustomPackagingElementEntity::class.java, customEntity) {
          this.propertiesXmlTag = newState
        }
      }
    }
  }

  // Initialize all artifact bridges
  @RequiresReadLock
  private fun initBridges() {
    val workspaceModel = WorkspaceModel.getInstance(project)
    val current = workspaceModel.entityStorage.current
    if (current.entitiesAmount(ArtifactEntity::class.java) != current.artifactsMap.size()) {

      synchronized(lock) {
        val currentInSync = workspaceModel.entityStorage.current
        val artifactsMap = currentInSync.artifactsMap

        // Double check
        if (currentInSync.entitiesAmount(ArtifactEntity::class.java) != artifactsMap.size()) {
          val newBridges = currentInSync
            .entities(ArtifactEntity::class.java)
            .mapNotNull {
              if (artifactsMap.getDataByEntity(it) == null) {
                createArtifactBridge(it, workspaceModel.entityStorage, project)
              }
              else null
            }
            .toList()

          workspaceModel.updateProjectModelSilent {
            addBridgesToDiff(newBridges, it)
          }
        }
      }
    }
  }

  companion object {
    private val lock = Any()
    private const val ARTIFACT_BRIDGE_MAPPING_ID = "intellij.artifacts.bridge"

    val WorkspaceEntityStorage.artifactsMap: ExternalEntityMapping<ArtifactBridge>
      get() = getExternalMapping(ARTIFACT_BRIDGE_MAPPING_ID)

    internal val WorkspaceEntityStorageBuilder.mutableArtifactsMap: MutableExternalEntityMapping<ArtifactBridge>
      get() = getMutableExternalMapping(ARTIFACT_BRIDGE_MAPPING_ID)
  }

  override fun dispose() {
    // Anything here?
  }

  @RequiresWriteLock
  fun dropMappings(selector: (ArtifactEntity) -> Boolean) {
    WorkspaceModel.getInstance(project).updateProjectModelSilent {
      val map = it.mutableArtifactsMap
      it.entities(ArtifactEntity::class.java).filter(selector).forEach { artifact ->
        map.removeMapping(artifact)
      }
    }
  }
}