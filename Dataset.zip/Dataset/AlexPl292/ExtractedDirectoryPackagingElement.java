<<>>java/compiler/impl/src/com/intellij/packaging/impl/elements/ExtractedDirectoryPackagingElement.java<<>>
<<>> 27 April 2021 <<>>

// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.packaging.impl.elements;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
	@@ -9,6 +10,16 @@
import com.intellij.packaging.ui.ArtifactEditorContext;
import com.intellij.packaging.ui.PackagingElementPresentation;
import com.intellij.util.xmlb.annotations.Attribute;
import com.intellij.workspaceModel.ide.VirtualFileUrlManagerUtil;
import com.intellij.workspaceModel.storage.EntitySource;
import com.intellij.workspaceModel.storage.WorkspaceEntity;
import com.intellij.workspaceModel.storage.WorkspaceEntityStorageBuilder;
import com.intellij.workspaceModel.storage.bridgeEntities.BridgeModelModifiableEntitiesKt;
import com.intellij.workspaceModel.storage.bridgeEntities.ExtractedDirectoryPackagingElementEntity;
import com.intellij.workspaceModel.storage.bridgeEntities.ModifiableExtractedDirectoryPackagingElementEntity;
import com.intellij.workspaceModel.storage.url.VirtualFileUrl;
import com.intellij.workspaceModel.storage.url.VirtualFileUrlManager;
import kotlin.Unit;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
	@@ -75,6 +86,32 @@ public String getPathInJar() {
  }

  public void setPathInJar(String pathInJar) {
    String myPathInJarBefore = myPathInJar;
    this.update(
      () -> myPathInJar = pathInJar,
      (builder, entity) -> {
        if (myPathInJarBefore.equals(pathInJar)) return;

        builder.modifyEntity(ModifiableExtractedDirectoryPackagingElementEntity.class, entity, ent -> {
          ent.setPathInArchive(pathInJar);
          return Unit.INSTANCE;
        });
    }, true);
  }

  @Override
  public WorkspaceEntity getOrAddEntity(@NotNull WorkspaceEntityStorageBuilder diff,
                                        @NotNull EntitySource source,
                                        @NotNull Project project) {
    WorkspaceEntity existingEntity = getExistingEntity(diff);
    if (existingEntity != null) return existingEntity;

    VirtualFileUrlManager fileUrlManager = VirtualFileUrlManagerUtil.getInstance(VirtualFileUrlManager.Companion, project);
    VirtualFileUrl fileUrl = fileUrlManager.fromPath(this.myFilePath);

    ExtractedDirectoryPackagingElementEntity addedEntity =
      BridgeModelModifiableEntitiesKt.addExtractedDirectoryPackagingElementEntity(diff, fileUrl, this.myPathInJar, source);
    diff.getMutableExternalMapping("intellij.artifacts.packaging.elements").addMapping(addedEntity, this);
    return addedEntity;
  }
}