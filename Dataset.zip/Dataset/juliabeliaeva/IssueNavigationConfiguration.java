<<>>platform/vcs-api/src/com/intellij/openapi/vcs/IssueNavigationConfiguration.java<<>>
<<>> 9 Dec 2020 <<>>

final List<LinkMatch> result = new ArrayList<>();
    try {
      for (IssueNavigationLink link : myLinks) {
        findIssueLinkMatches(text, link, result);
      }
      TextRange match;
      int lastOffset = 0;
	@@ -115,6 +105,22 @@ public int compareTo(Object o) {
    return result;
  }

  public static void findIssueLinkMatches(@NotNull CharSequence text,
                                          @NotNull IssueNavigationLink link,
                                          @NotNull List<LinkMatch> result) {
    Pattern issuePattern = link.getIssuePattern();
    Matcher m = issuePattern.matcher(text);
    while (m.find()) {
      try {
        String replacement = issuePattern.matcher(m.group(0)).replaceFirst(link.getLinkRegexp());
        addMatch(result, new TextRange(m.start(), m.end()), replacement);
      }
      catch (Exception e) {
        LOG.debug("Malformed regex replacement. IssueLink: " + link + "; text: " + text, e);
      }
    }
  }

  private static void addMatch(final List<LinkMatch> result, final TextRange range, final String replacement) {
    for (Iterator<LinkMatch> iterator = result.iterator(); iterator.hasNext(); ) {
      LinkMatch oldMatch = iterator.next();