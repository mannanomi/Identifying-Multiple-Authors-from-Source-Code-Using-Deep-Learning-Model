<<>>platform/vcs-log/impl/test/com/intellij/vcs/log/history/FileHistoryTest.java<<>>

<<>> 26 Feb 2021 <<>>
mport it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap
import org.junit.Assert
import org.junit.Assume.assumeFalse
import org.junit.Ignore
import org.junit.Test

class FileHistoryTest {
	@@ -426,6 +427,50 @@ class FileHistoryTest {
      7()
    }
  }

  @Ignore
  @Test
  fun historyWithDeletedAndAddedUnderDifferentName() {
    val after = LocalFilePath("after.txt", false)
    val before = LocalFilePath("before.txt", false)
    val fileNamesData = FileNamesDataBuilder(after)
      .addChange(after, 0, listOf(MODIFIED), listOf(1))
      .addChange(after, 1, listOf(MODIFIED, MODIFIED), listOf(1, 3))
      .addChange(after, 2, listOf(MODIFIED), listOf(6))
      .addChange(after, 3, listOf(MODIFIED), listOf(4))
      .addChange(after, 4, listOf(MODIFIED, ADDED), listOf(6, 5))
      .addChange(before, 5, listOf(REMOVED), listOf(7))
      .addDetectedRename(8, 6, before, after)
      .addChange(before, 7, listOf(MODIFIED), listOf(8))
      .addChange(before, 8, listOf(MODIFIED), listOf(9))
      .addChange(before, 9, listOf(ADDED), listOf(10))
      .build()

    graph {
      0(1)
      1(2, 3)
      2(6)
      3(4)
      4(6, 5)
      5(7)
      6(8)
      7(8)
      8(9)
      9(10)
      10()
    }.assert(0, after, fileNamesData) {
      0(1)
      1(2, 3)
      2(6)
      3(4)
      4(6)
      5(7)
      6(8)
      7(8)
      8(9)
      9()
    }
  }
}

private class FileNamesDataBuilder(private val path: FilePath) {