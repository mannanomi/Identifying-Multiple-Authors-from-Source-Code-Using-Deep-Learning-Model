<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/impl/VcsLogImpl.java<<>>
<<>> 4 Feeb 2021 <<>>

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.util.IntRef;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.ui.VcsBalloonProblemNotifier;
import com.intellij.openapi.vfs.VirtualFile;
	@@ -138,8 +137,20 @@ public void requestSelectedDetails(@NotNull Consumer<? super List<VcsFullCommitD
  }

  private int getCommitRow(@NotNull VisiblePack visiblePack, @NotNull String partialHash) {
    if (partialHash.length() == VcsLogUtil.FULL_HASH_LENGTH) {
      int row = COMMIT_NOT_FOUND;
      Hash candidateHash = HashImpl.build(partialHash);
      for (VirtualFile candidateRoot : myLogData.getRoots()) {
        if (myLogData.getStorage().containsCommit(new CommitId(candidateHash, candidateRoot))) {
          int candidateRow = getCommitRow(visiblePack, candidateHash, candidateRoot);
          if (candidateRow >= 0) return candidateRow;
          if (row == COMMIT_NOT_FOUND) row = candidateRow;
        }
      }
      return row;
    }

    IntRef row = new IntRef(COMMIT_NOT_FOUND);
    myLogData.getStorage().iterateCommits(candidate -> {
      if (CommitIdByStringCondition.matches(candidate, partialHash)) {
        int candidateRow = getCommitRow(visiblePack, candidate.getHash(), candidate.getRoot());
	@@ -148,7 +159,6 @@ private int getCommitRow(@NotNull VisiblePack visiblePack, @NotNull String parti
      }
      return true;
    });
    return row.get();
  }
  
  
 <<>> 4 Feb 2021 <<>>
 
 import com.google.common.util.concurrent.SettableFuture;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.util.IntRef;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.ui.VcsBalloonProblemNotifier;
	@@ -30,6 +31,8 @@
import com.intellij.vcs.log.*;
import com.intellij.vcs.log.data.CommitIdByStringCondition;
import com.intellij.vcs.log.data.VcsLogData;
import com.intellij.vcs.log.graph.VisibleGraph;
import com.intellij.vcs.log.graph.impl.facade.VisibleGraphImpl;
import com.intellij.vcs.log.ui.AbstractVcsLogUi;
import com.intellij.vcs.log.ui.table.VcsLogGraphTable;
import com.intellij.vcs.log.util.VcsLogUtil;
	@@ -135,24 +138,33 @@ public void requestSelectedDetails(@NotNull Consumer<? super List<VcsFullCommitD
  }

  private int getCommitRow(@NotNull VisiblePack visiblePack, @NotNull String partialHash) {
    IntRef row = new IntRef(COMMIT_NOT_FOUND);

    myLogData.getStorage().iterateCommits(candidate -> {
      if (CommitIdByStringCondition.matches(candidate, partialHash)) {
        int candidateRow = getCommitRow(visiblePack, candidate.getHash(), candidate.getRoot());
        if (row.get() == COMMIT_NOT_FOUND) row.set(candidateRow);
        return candidateRow < 0;
      }
      return true;
    });

    return row.get();
  }

  private int getCommitRow(@NotNull VisiblePack visiblePack,
                           @NotNull Hash hash,
                           @NotNull VirtualFile root) {
    int commitIndex = myLogData.getCommitIndex(hash, root);
    VisibleGraph<Integer> visibleGraph = visiblePack.getVisibleGraph();
    if (visibleGraph instanceof VisibleGraphImpl) {
      int nodeId = ((VisibleGraphImpl<Integer>)visibleGraph).getPermanentGraph().getPermanentCommitsInfo().getNodeId(commitIndex);
      if (nodeId == COMMIT_NOT_FOUND) return COMMIT_NOT_FOUND;
      if (nodeId < 0) return COMMIT_DOES_NOT_MATCH;
      Integer rowIndex = ((VisibleGraphImpl<Integer>)visibleGraph).getLinearGraph().getNodeIndex(nodeId);
      return rowIndex == null ? COMMIT_DOES_NOT_MATCH : rowIndex;
    }
    Integer rowIndex = visibleGraph.getVisibleRowIndex(commitIndex);
    return rowIndex == null ? COMMIT_DOES_NOT_MATCH : rowIndex;
  }
  
  
  
  <<>> 4 Feb 2021 <<>>
  
  
import com.google.common.util.concurrent.SettableFuture;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.ui.VcsBalloonProblemNotifier;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.Consumer;
import com.intellij.util.EmptyConsumer;
import com.intellij.vcs.log.*;
import com.intellij.vcs.log.data.CommitIdByStringCondition;
import com.intellij.vcs.log.data.VcsLogData;
import com.intellij.vcs.log.ui.AbstractVcsLogUi;
import com.intellij.vcs.log.ui.table.VcsLogGraphTable;
import com.intellij.vcs.log.util.VcsLogUtil;
import com.intellij.vcs.log.visible.VisiblePack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.intellij.vcs.log.ui.table.GraphTableModel.COMMIT_DOES_NOT_MATCH;
import static com.intellij.vcs.log.ui.table.GraphTableModel.COMMIT_NOT_FOUND;

public class VcsLogImpl implements VcsLog {
  @NotNull private final VcsLogData myLogData;
  @NotNull private final AbstractVcsLogUi myUi;
	@@ -107,7 +113,10 @@ public void requestSelectedDetails(@NotNull Consumer<? super List<VcsFullCommitD
  @NotNull
  public ListenableFuture<Boolean> jumpToCommit(@NotNull Hash commitHash, @NotNull VirtualFile root) {
    SettableFuture<Boolean> future = SettableFuture.create();
    myUi.jumpTo(commitHash, (model, hash) -> {
      if (!myLogData.getStorage().containsCommit(new CommitId(hash, root))) return COMMIT_NOT_FOUND;
      return getRowOfCommitWithoutCheck(model.getVisiblePack(), hash, root);
    }, future, false);
    return future;
  }

	@@ -122,10 +131,33 @@ public void requestSelectedDetails(@NotNull Consumer<? super List<VcsFullCommitD
      future.set(false);
      return future;
    }
    myUi.jumpTo(trimmed, (model, partialHash) -> getRowOfCommitByPartOfHash(model.getVisiblePack(), partialHash), future, false);
    return future;
  }

  private int getRowOfCommitByPartOfHash(@NotNull VisiblePack visiblePack, @NotNull String partialHash) {
    Predicate<CommitId> hashByString = new CommitIdByStringCondition(partialHash);
    Ref<Boolean> commitExists = new Ref<>(false);
    CommitId commitId = myLogData.getStorage().findCommitId(commitId1 -> {
      if (hashByString.test(commitId1)) {
        commitExists.set(true);
        return getRowOfCommitWithoutCheck(visiblePack, commitId1.getHash(), commitId1.getRoot()) >= 0;
      }
      return false;
    });
    return commitId != null
           ? getRowOfCommitWithoutCheck(visiblePack, commitId.getHash(), commitId.getRoot())
           : (commitExists.get() ? COMMIT_DOES_NOT_MATCH : COMMIT_NOT_FOUND);
  }

  private int getRowOfCommitWithoutCheck(@NotNull VisiblePack visiblePack,
                                         @NotNull Hash hash,
                                         @NotNull VirtualFile root) {
    int commitIndex = myLogData.getCommitIndex(hash, root);
    Integer rowIndex = visiblePack.getVisibleGraph().getVisibleRowIndex(commitIndex);
    return rowIndex == null ? COMMIT_DOES_NOT_MATCH : rowIndex;
  }

  @NotNull
  @Override
  public Map<VirtualFile, VcsLogProvider> getLogProviders() {