<<>>plugins/git4idea/src/git4idea/index/ui/SimpleTabTitleUpdater.java<<>>
<<>> 26 April 2021<<>>

// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package git4idea.index.ui

import com.intellij.openapi.Disposable
import com.intellij.openapi.vcs.VcsBundle
import com.intellij.openapi.vcs.changes.ui.ChangesGroupingSupport
import com.intellij.openapi.vcs.changes.ui.ChangesTree
import com.intellij.openapi.vcs.changes.ui.ChangesViewContentManager
import com.intellij.openapi.vcs.changes.ui.CurrentBranchComponent
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.ui.content.Content
import com.intellij.util.ui.update.UiNotifyConnector
import com.intellij.vcs.branch.BranchData
import com.intellij.vcs.branch.BranchPresentation
import org.jetbrains.annotations.Nls
import org.jetbrains.annotations.NotNull
import java.beans.PropertyChangeListener
import javax.swing.JTree.TREE_MODEL_PROPERTY

abstract class SimpleTabTitleUpdater(private val tree: ChangesTree, private val tabName: String): Disposable {
  private var branches = emptySet<BranchData>()
    set(value) {
      if (field == value) return
      field = value
      updatePresentation()
    }
  private val treeChangeListener = PropertyChangeListener { e ->
    if (e.propertyName == TREE_MODEL_PROPERTY) {
      refresh()
    }
  }

  init {
    UiNotifyConnector.doWhenFirstShown(tree, Runnable { refresh() })
    tree.addPropertyChangeListener(treeChangeListener)
  }

  abstract fun getRoots(): Collection<VirtualFile>

  fun refresh() {
    branches = getBranches()
  }

  private fun updatePresentation() {
    val tab = getTab() ?: return

    tab.displayName = getDisplayName()
    tab.description = BranchPresentation.getTooltip(branches)
  }

  private fun getDisplayName(): @NotNull @Nls String {
    val branchesText = BranchPresentation.getText(branches)
    if (branchesText.isBlank()) return VcsBundle.message("tab.title.commit")

    return VcsBundle.message("tab.title.commit.to.branch", branchesText)
  }

  private fun getBranches(): Set<BranchData> {
    if (!shouldShowBranches()) {
      return emptySet()
    }
    return getRoots().mapNotNull { CurrentBranchComponent.getCurrentBranch(tree.project, it) }.toSet()
  }

  private fun shouldShowBranches(): Boolean {
    val groupingSupport = tree.groupingSupport
    return !groupingSupport.isAvailable(ChangesGroupingSupport.REPOSITORY_GROUPING) ||
           !groupingSupport[ChangesGroupingSupport.REPOSITORY_GROUPING]
  }

  private fun getTab(): Content? {
    return ChangesViewContentManager.getInstance(tree.project).findContents { it.tabName == tabName }.firstOrNull()
  }

  override fun dispose() {
    tree.removePropertyChangeListener(treeChangeListener)
    branches = emptySet()
  }
}