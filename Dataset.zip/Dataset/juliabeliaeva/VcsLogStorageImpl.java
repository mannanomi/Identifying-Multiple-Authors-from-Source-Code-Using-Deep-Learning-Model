<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/data/VcsLogStorageImpl.java<<>>
<<>> 18 Mar 2018 <<>>

MyCommitIdKeyDescriptor commitIdKeyDescriptor = new MyCommitIdKeyDescriptor(roots);
    StorageId hashesStorageId = new StorageId(project.getName(), HASHES_STORAGE, logId, VERSION);	    StorageId hashesStorageId = new StorageId(project.getName(), HASHES_STORAGE, logId, VERSION);
    myCommitIdEnumerator = IOUtil.openCleanOrResetBroken(() -> new MyPersistentBTreeEnumerator(hashesStorageId, commitIdKeyDescriptor),	    StorageLockContext storageLockContext = new StorageLockContext(true);

    myCommitIdEnumerator = IOUtil.openCleanOrResetBroken(() -> new MyPersistentBTreeEnumerator(hashesStorageId, commitIdKeyDescriptor,
                                                                                               storageLockContext),
                                                         hashesStorageId.getStorageFile(STORAGE).toFile());	                                                         hashesStorageId.getStorageFile(STORAGE).toFile());


    VcsRefKeyDescriptor refsKeyDescriptor = new VcsRefKeyDescriptor(logProviders, commitIdKeyDescriptor);	    VcsRefKeyDescriptor refsKeyDescriptor = new VcsRefKeyDescriptor(logProviders, commitIdKeyDescriptor);
    StorageId refsStorageId = new StorageId(project.getName(), REFS_STORAGE, logId, VERSION + REFS_VERSION);	    StorageId refsStorageId = new StorageId(project.getName(), REFS_STORAGE, logId, VERSION + REFS_VERSION);
    myRefsEnumerator = IOUtil.openCleanOrResetBroken(() -> new PersistentEnumerator<>(refsStorageId.getStorageFile(STORAGE),	    myRefsEnumerator = IOUtil.openCleanOrResetBroken(() -> new PersistentEnumerator<>(refsStorageId.getStorageFile(STORAGE),
                                                                                      refsKeyDescriptor, Page.PAGE_SIZE,	                                                                                      refsKeyDescriptor, Page.PAGE_SIZE,
                                                                                      null, refsStorageId.getVersion()),	                                                                                      storageLockContext, refsStorageId.getVersion()),
                                                     refsStorageId.getStorageFile(STORAGE).toFile());	                                                     refsStorageId.getStorageFile(STORAGE).toFile());
    Disposer.register(parent, this);	    Disposer.register(parent, this);
  }	  }
@@ -308,8 +311,9 @@ public VcsRef read(@NotNull DataInput in) throws IOException {
  }	  }


  private static final class MyPersistentBTreeEnumerator extends PersistentBTreeEnumerator<CommitId> {	  private static final class MyPersistentBTreeEnumerator extends PersistentBTreeEnumerator<CommitId> {
    MyPersistentBTreeEnumerator(@NotNull StorageId storageId, @NotNull KeyDescriptor<CommitId> commitIdKeyDescriptor) throws IOException {	    MyPersistentBTreeEnumerator(@NotNull StorageId storageId, @NotNull KeyDescriptor<CommitId> commitIdKeyDescriptor,
      super(storageId.getStorageFile(STORAGE), commitIdKeyDescriptor, Page.PAGE_SIZE, new StorageLockContext(true),	                                @Nullable StorageLockContext storageLockContext) throws IOException {
      super(storageId.getStorageFile(STORAGE), commitIdKeyDescriptor, Page.PAGE_SIZE, storageLockContext,
            storageId.getVersion());	            storageId.getVersion());
    }	    }


  24  platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogFullDetailsIndex.java 
@@ -13,9 +13,7 @@
import com.intellij.util.indexing.impl.forward.ForwardIndex;	import com.intellij.util.indexing.impl.forward.ForwardIndex;
import com.intellij.util.indexing.impl.forward.ForwardIndexAccessor;	import com.intellij.util.indexing.impl.forward.ForwardIndexAccessor;
import com.intellij.util.indexing.impl.forward.KeyCollectionForwardIndexAccessor;	import com.intellij.util.indexing.impl.forward.KeyCollectionForwardIndexAccessor;
import com.intellij.util.io.DataExternalizer;	import com.intellij.util.io.*;
import com.intellij.util.io.EnumeratorIntegerDescriptor;	
import com.intellij.util.io.KeyDescriptor;	
import com.intellij.vcs.log.impl.FatalErrorHandler;	import com.intellij.vcs.log.impl.FatalErrorHandler;
import com.intellij.vcs.log.util.StorageId;	import com.intellij.vcs.log.util.StorageId;
import it.unimi.dsi.fastutil.ints.IntIterator;	import it.unimi.dsi.fastutil.ints.IntIterator;
@@ -43,6 +41,7 @@ public VcsLogFullDetailsIndex(@NotNull StorageId storageId,
                                @NotNull String name,	                                @NotNull String name,
                                @NotNull DataIndexer<Integer, T, D> indexer,	                                @NotNull DataIndexer<Integer, T, D> indexer,
                                @NotNull DataExternalizer<T> externalizer,	                                @NotNull DataExternalizer<T> externalizer,
                                @Nullable StorageLockContext storageLockContext,
                                @NotNull FatalErrorHandler fatalErrorHandler,	                                @NotNull FatalErrorHandler fatalErrorHandler,
                                @NotNull Disposable disposableParent)	                                @NotNull Disposable disposableParent)
    throws IOException {	    throws IOException {
@@ -51,23 +50,28 @@ public VcsLogFullDetailsIndex(@NotNull StorageId storageId,
    myIndexer = indexer;	    myIndexer = indexer;
    myFatalErrorHandler = fatalErrorHandler;	    myFatalErrorHandler = fatalErrorHandler;


    myMapReduceIndex = createMapReduceIndex(externalizer);	    myMapReduceIndex = createMapReduceIndex(externalizer, storageLockContext);


    Disposer.register(disposableParent, this);	    Disposer.register(disposableParent, this);
  }	  }


  @NotNull	  private @NotNull MyMapReduceIndex createMapReduceIndex(@NotNull DataExternalizer<T> dataExternalizer,
  private MyMapReduceIndex createMapReduceIndex(@NotNull DataExternalizer<T> dataExternalizer) throws IOException {	                                                         @Nullable StorageLockContext storageLockContext) throws IOException {
    MyIndexExtension<T, D> extension = new MyIndexExtension<>(myName, myIndexer, dataExternalizer, myStorageId.getVersion());	    MyIndexExtension<T, D> extension = new MyIndexExtension<>(myName, myIndexer, dataExternalizer, myStorageId.getVersion());
    Pair<ForwardIndex, ForwardIndexAccessor<Integer, T>> pair = createdForwardIndex();	    Pair<ForwardIndex, ForwardIndexAccessor<Integer, T>> pair = createdForwardIndex(storageLockContext);
    ForwardIndex forwardIndex = pair != null ? pair.getFirst() : null;	    ForwardIndex forwardIndex = pair != null ? pair.getFirst() : null;
    ForwardIndexAccessor<Integer, T> forwardIndexAccessor = pair != null ? pair.getSecond() : null;	    ForwardIndexAccessor<Integer, T> forwardIndexAccessor = pair != null ? pair.getSecond() : null;
    return new MyMapReduceIndex(extension, new MyMapIndexStorage<>(myName, myStorageId, dataExternalizer), forwardIndex,	    PagedFileStorage.THREAD_LOCAL_STORAGE_LOCK_CONTEXT.set(storageLockContext);
                                forwardIndexAccessor);	    try {
      return new MyMapReduceIndex(extension, new MyMapIndexStorage<>(myName, myStorageId, dataExternalizer), forwardIndex,
                                  forwardIndexAccessor);
    } finally {
      PagedFileStorage.THREAD_LOCAL_STORAGE_LOCK_CONTEXT.remove();
    }
  }	  }


  @Nullable	  @Nullable
  protected Pair<ForwardIndex, ForwardIndexAccessor<Integer, T>> createdForwardIndex() throws IOException {	  protected Pair<ForwardIndex, ForwardIndexAccessor<Integer, T>> createdForwardIndex(@Nullable StorageLockContext storageLockContext) throws IOException {
    return null;	    return null;
  }	  }


  4  platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogMessagesTrigramIndex.java 
@@ -5,6 +5,7 @@
import com.intellij.openapi.util.text.TrigramBuilder;	import com.intellij.openapi.util.text.TrigramBuilder;
import com.intellij.util.indexing.DataIndexer;	import com.intellij.util.indexing.DataIndexer;
import com.intellij.util.indexing.StorageException;	import com.intellij.util.indexing.StorageException;
import com.intellij.util.io.StorageLockContext;
import com.intellij.util.io.VoidDataExternalizer;	import com.intellij.util.io.VoidDataExternalizer;
import com.intellij.vcs.log.VcsCommitMetadata;	import com.intellij.vcs.log.VcsCommitMetadata;
import com.intellij.vcs.log.impl.FatalErrorHandler;	import com.intellij.vcs.log.impl.FatalErrorHandler;
@@ -23,10 +24,11 @@
  @NonNls private static final String TRIGRAMS = "trigrams";	  @NonNls private static final String TRIGRAMS = "trigrams";


  public VcsLogMessagesTrigramIndex(@NotNull StorageId storageId,	  public VcsLogMessagesTrigramIndex(@NotNull StorageId storageId,
                                    @Nullable StorageLockContext storageLockContext,
                                    @NotNull FatalErrorHandler fatalErrorHandler,	                                    @NotNull FatalErrorHandler fatalErrorHandler,
                                    @NotNull Disposable disposableParent) throws IOException {	                                    @NotNull Disposable disposableParent) throws IOException {
    super(storageId, TRIGRAMS, new TrigramMessageIndexer(), VoidDataExternalizer.INSTANCE,	    super(storageId, TRIGRAMS, new TrigramMessageIndexer(), VoidDataExternalizer.INSTANCE,
          fatalErrorHandler, disposableParent);	          storageLockContext, fatalErrorHandler, disposableParent);
  }	  }


  @Nullable	  @Nullable
  16  platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogPathsIndex.java 
@@ -47,29 +47,33 @@
  public VcsLogPathsIndex(@NotNull StorageId storageId,	  public VcsLogPathsIndex(@NotNull StorageId storageId,
                          @NotNull VcsLogStorage storage,	                          @NotNull VcsLogStorage storage,
                          @NotNull Set<VirtualFile> roots,	                          @NotNull Set<VirtualFile> roots,
                          @Nullable StorageLockContext storageLockContext,
                          @NotNull FatalErrorHandler fatalErrorHandler,	                          @NotNull FatalErrorHandler fatalErrorHandler,
                          @NotNull Disposable disposableParent) throws IOException {	                          @NotNull Disposable disposableParent) throws IOException {
    super(storageId, PATHS, new PathsIndexer(storage, createPathsEnumerator(roots, storageId), createRenamesMap(storageId)),	    super(storageId, PATHS, new PathsIndexer(storage, createPathsEnumerator(roots, storageId, storageLockContext),
          new ChangeKindListKeyDescriptor(), fatalErrorHandler, disposableParent);	                                             createRenamesMap(storageId, storageLockContext)),
          new ChangeKindListKeyDescriptor(), storageLockContext, fatalErrorHandler, disposableParent);


    myPathsIndexer = (PathsIndexer)myIndexer;	    myPathsIndexer = (PathsIndexer)myIndexer;
    myPathsIndexer.setFatalErrorConsumer(e -> fatalErrorHandler.consume(this, e));	    myPathsIndexer.setFatalErrorConsumer(e -> fatalErrorHandler.consume(this, e));
  }	  }


  @NotNull	  @NotNull
  private static PersistentEnumerator<LightFilePath> createPathsEnumerator(@NotNull Collection<VirtualFile> roots,	  private static PersistentEnumerator<LightFilePath> createPathsEnumerator(@NotNull Collection<VirtualFile> roots,
                                                                           @NotNull StorageId storageId) throws IOException {	                                                                           @NotNull StorageId storageId,
                                                                           @Nullable StorageLockContext storageLockContext) throws IOException {
    Path storageFile = storageId.getStorageFile(INDEX_PATHS_IDS);	    Path storageFile = storageId.getStorageFile(INDEX_PATHS_IDS);
    return new PersistentEnumerator<>(storageFile, new LightFilePathKeyDescriptor(roots),	    return new PersistentEnumerator<>(storageFile, new LightFilePathKeyDescriptor(roots),
                                      Page.PAGE_SIZE, null, storageId.getVersion());	                                      Page.PAGE_SIZE, storageLockContext, storageId.getVersion());
  }	  }


  @NotNull	  @NotNull
  private static PersistentHashMap<Couple<Integer>, Collection<Couple<Integer>>> createRenamesMap(@NotNull StorageId storageId)	  private static PersistentHashMap<Couple<Integer>, Collection<Couple<Integer>>> createRenamesMap(@NotNull StorageId storageId,
                                                                                                  @Nullable StorageLockContext storageLockContext)
    throws IOException {	    throws IOException {
    Path storageFile = storageId.getStorageFile(RENAMES_MAP);	    Path storageFile = storageId.getStorageFile(RENAMES_MAP);
    return new PersistentHashMap<>(storageFile, new CoupleKeyDescriptor(), new CollectionDataExternalizer(), Page.PAGE_SIZE,	    return new PersistentHashMap<>(storageFile, new CoupleKeyDescriptor(), new CollectionDataExternalizer(), Page.PAGE_SIZE,
                                   storageId.getVersion());	                                   storageId.getVersion(), storageLockContext);
  }	  }


  @Nullable	  @Nullable
  18  platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogPersistentIndex.java 
@@ -320,35 +320,37 @@ public void dispose() {


      try {	      try {
        StorageId storageId = new StorageId(projectName, INDEX, logId, getVersion());	        StorageId storageId = new StorageId(projectName, INDEX, logId, getVersion());
        StorageLockContext storageLockContext = new StorageLockContext(true);


        Path commitsStorage = storageId.getStorageFile(COMMITS);	        Path commitsStorage = storageId.getStorageFile(COMMITS);
        myIsFresh = !Files.exists(commitsStorage);	        myIsFresh = !Files.exists(commitsStorage);
        commits = new PersistentSetImpl<>(commitsStorage, EnumeratorIntegerDescriptor.INSTANCE, Page.PAGE_SIZE, null,	        commits = new PersistentSetImpl<>(commitsStorage, EnumeratorIntegerDescriptor.INSTANCE, Page.PAGE_SIZE, storageLockContext,
                                          storageId.getVersion());	                                          storageId.getVersion());
        Disposer.register(this, () -> catchAndWarn(commits::close));	        Disposer.register(this, () -> catchAndWarn(commits::close));


        StorageId messagesStorageId = new StorageId(projectName, INDEX, logId, VcsLogStorageImpl.VERSION + MESSAGES_VERSION);	        StorageId messagesStorageId = new StorageId(projectName, INDEX, logId, VcsLogStorageImpl.VERSION + MESSAGES_VERSION);
        messages = new PersistentHashMap<>(messagesStorageId.getStorageFile(MESSAGES), EnumeratorIntegerDescriptor.INSTANCE,	        messages = new PersistentHashMap<>(messagesStorageId.getStorageFile(MESSAGES), EnumeratorIntegerDescriptor.INSTANCE,
                                           EnumeratorStringDescriptor.INSTANCE, Page.PAGE_SIZE, messagesStorageId.getVersion());	                                           EnumeratorStringDescriptor.INSTANCE, Page.PAGE_SIZE, messagesStorageId.getVersion(),
                                           storageLockContext);
        Disposer.register(this, () -> catchAndWarn(messages::close));	        Disposer.register(this, () -> catchAndWarn(messages::close));


        trigrams = new VcsLogMessagesTrigramIndex(storageId, fatalErrorHandler, this);	        trigrams = new VcsLogMessagesTrigramIndex(storageId, storageLockContext, fatalErrorHandler, this);
        users = new VcsLogUserIndex(storageId, userRegistry, fatalErrorHandler, this);	        users = new VcsLogUserIndex(storageId, storageLockContext, userRegistry, fatalErrorHandler, this);
        paths = new VcsLogPathsIndex(storageId, storage, roots, fatalErrorHandler, this);	        paths = new VcsLogPathsIndex(storageId, storage, roots, storageLockContext, fatalErrorHandler, this);


        Path parentsStorage = storageId.getStorageFile(PARENTS);	        Path parentsStorage = storageId.getStorageFile(PARENTS);
        parents = new PersistentHashMap<>(parentsStorage, EnumeratorIntegerDescriptor.INSTANCE,	        parents = new PersistentHashMap<>(parentsStorage, EnumeratorIntegerDescriptor.INSTANCE,
                                          new IntListDataExternalizer(), Page.PAGE_SIZE, storageId.getVersion());	                                          new IntListDataExternalizer(), Page.PAGE_SIZE, storageId.getVersion(), storageLockContext);
        Disposer.register(this, () -> catchAndWarn(parents::close));	        Disposer.register(this, () -> catchAndWarn(parents::close));


        Path committersStorage = storageId.getStorageFile(COMMITTERS);	        Path committersStorage = storageId.getStorageFile(COMMITTERS);
        committers = new PersistentHashMap<>(committersStorage, EnumeratorIntegerDescriptor.INSTANCE, EnumeratorIntegerDescriptor.INSTANCE,	        committers = new PersistentHashMap<>(committersStorage, EnumeratorIntegerDescriptor.INSTANCE, EnumeratorIntegerDescriptor.INSTANCE,
                                             Page.PAGE_SIZE, storageId.getVersion());	                                             Page.PAGE_SIZE, storageId.getVersion(), storageLockContext);
        Disposer.register(this, () -> catchAndWarn(committers::close));	        Disposer.register(this, () -> catchAndWarn(committers::close));


        Path timestampsStorage = storageId.getStorageFile(TIMESTAMPS);	        Path timestampsStorage = storageId.getStorageFile(TIMESTAMPS);
        timestamps = new PersistentHashMap<>(timestampsStorage, EnumeratorIntegerDescriptor.INSTANCE, new LongPairDataExternalizer(),	        timestamps = new PersistentHashMap<>(timestampsStorage, EnumeratorIntegerDescriptor.INSTANCE, new LongPairDataExternalizer(),
                                             Page.PAGE_SIZE, storageId.getVersion());	                                             Page.PAGE_SIZE, storageId.getVersion(), storageLockContext);
        Disposer.register(this, () -> catchAndWarn(timestamps::close));	        Disposer.register(this, () -> catchAndWarn(timestamps::close));
      }	      }
      catch (Throwable t) {	      catch (Throwable t) {
  17  platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogUserIndex.java 
@@ -11,10 +11,7 @@
import com.intellij.util.indexing.impl.forward.ForwardIndexAccessor;	import com.intellij.util.indexing.impl.forward.ForwardIndexAccessor;
import com.intellij.util.indexing.impl.forward.KeyCollectionForwardIndexAccessor;	import com.intellij.util.indexing.impl.forward.KeyCollectionForwardIndexAccessor;
import com.intellij.util.indexing.impl.forward.PersistentMapBasedForwardIndex;	import com.intellij.util.indexing.impl.forward.PersistentMapBasedForwardIndex;
import com.intellij.util.io.IntCollectionDataExternalizer;	import com.intellij.util.io.*;
import com.intellij.util.io.Page;	
import com.intellij.util.io.PersistentEnumerator;	
import com.intellij.util.io.VoidDataExternalizer;	
import com.intellij.vcs.log.VcsShortCommitDetails;	import com.intellij.vcs.log.VcsShortCommitDetails;
import com.intellij.vcs.log.VcsUser;	import com.intellij.vcs.log.VcsUser;
import com.intellij.vcs.log.VcsUserRegistry;	import com.intellij.vcs.log.VcsUserRegistry;
@@ -45,26 +42,28 @@
  @NotNull private final UserIndexer myUserIndexer;	  @NotNull private final UserIndexer myUserIndexer;


  public VcsLogUserIndex(@NotNull StorageId storageId,	  public VcsLogUserIndex(@NotNull StorageId storageId,
                         @Nullable StorageLockContext storageLockContext,
                         @NotNull VcsUserRegistry userRegistry,	                         @NotNull VcsUserRegistry userRegistry,
                         @NotNull FatalErrorHandler consumer,	                         @NotNull FatalErrorHandler consumer,
                         @NotNull Disposable disposableParent) throws IOException {	                         @NotNull Disposable disposableParent) throws IOException {
    super(storageId, USERS, new UserIndexer(createUsersEnumerator(storageId, userRegistry)), VoidDataExternalizer.INSTANCE,	    super(storageId, USERS, new UserIndexer(createUsersEnumerator(storageId, storageLockContext, userRegistry)), VoidDataExternalizer.INSTANCE,
          consumer, disposableParent);	          storageLockContext, consumer, disposableParent);
    myUserIndexer = (UserIndexer)myIndexer;	    myUserIndexer = (UserIndexer)myIndexer;
    ((UserIndexer)myIndexer).setFatalErrorConsumer(e -> consumer.consume(this, e));	    ((UserIndexer)myIndexer).setFatalErrorConsumer(e -> consumer.consume(this, e));
  }	  }


  @Override	  @Override
  protected @NotNull Pair<ForwardIndex, ForwardIndexAccessor<Integer, Void>> createdForwardIndex() throws IOException {	  protected @NotNull Pair<ForwardIndex, ForwardIndexAccessor<Integer, Void>> createdForwardIndex(@Nullable StorageLockContext storageLockContext) throws IOException {
    return new Pair<>(new PersistentMapBasedForwardIndex(myStorageId.getStorageFile(myName + ".idx"), false),	    return new Pair<>(new PersistentMapBasedForwardIndex(myStorageId.getStorageFile(myName + ".idx"), true, false, storageLockContext),
                      new KeyCollectionForwardIndexAccessor<>(new IntCollectionDataExternalizer()));	                      new KeyCollectionForwardIndexAccessor<>(new IntCollectionDataExternalizer()));
  }	  }


  @NotNull	  @NotNull
  private static PersistentEnumerator<VcsUser> createUsersEnumerator(@NotNull StorageId storageId,	  private static PersistentEnumerator<VcsUser> createUsersEnumerator(@NotNull StorageId storageId,
                                                                     @Nullable StorageLockContext storageLockContext,
                                                                     @NotNull VcsUserRegistry userRegistry) throws IOException {	                                                                     @NotNull VcsUserRegistry userRegistry) throws IOException {
    Path storageFile = storageId.getStorageFile(USERS_IDS);	    Path storageFile = storageId.getStorageFile(USERS_IDS);
    return new PersistentEnumerator<>(storageFile, new VcsUserKeyDescriptor(userRegistry), Page.PAGE_SIZE, null,	    return new PersistentEnumerator<>(storageFile, new VcsUserKeyDescriptor(userRegistry), Page.PAGE_SIZE, storageLockContext,
                                      storageId.getVersion());	                                      storageId.getVersion());
  }	  }

