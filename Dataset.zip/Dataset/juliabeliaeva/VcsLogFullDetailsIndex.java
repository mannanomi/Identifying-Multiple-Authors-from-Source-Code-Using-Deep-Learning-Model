<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/data/index/VcsLogFullDetailsIndex.java<<>>
<<>> 27 Mar 2021 <<>>

package com.intellij.vcs.log.data.index;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.util.Disposer;
	@@ -29,6 +30,7 @@
import java.util.function.ObjIntConsumer;

public class VcsLogFullDetailsIndex<T, D> implements Disposable {
  private static final Logger LOG = Logger.getInstance(VcsLogFullDetailsIndex.class);
  @NonNls protected static final String INDEX = "index";
  @NotNull private final MyMapReduceIndex myMapReduceIndex;
  @NotNull protected final StorageId myStorageId;
	@@ -160,15 +162,24 @@ public void requestRebuild(@NotNull Throwable ex) {
  }

  private static class MyMapIndexStorage<T> extends MapIndexStorage<Integer, T> {
    private @NotNull final String myName;

    MyMapIndexStorage(@NotNull String name, @NotNull StorageId storageId, @NotNull DataExternalizer<T> externalizer)
      throws IOException {
      super(storageId.getStorageFile(name, true), EnumeratorIntegerDescriptor.INSTANCE, externalizer, 5000, false);
      myName = name;
    }

    @Override
    protected void checkCanceled() {
      ProgressManager.checkCanceled();
    }

    @Override
    public void clear() throws StorageException {
      LOG.warn("Clearing '" + myName + "' map index storage", new RuntimeException());
      super.clear();
    }
  }

  private static class MyIndexExtension<T, D> extends IndexExtension<Integer, T, D> {