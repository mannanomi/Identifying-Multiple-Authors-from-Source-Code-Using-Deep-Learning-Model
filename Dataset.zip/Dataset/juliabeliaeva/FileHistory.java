<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/history/FileHistory.java<<>>
<<>> 14 Jun 2018<<>>

package com.intellij.vcs.log.graph.utils;

import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.Ref;
import com.intellij.util.containers.IntStack;
import com.intellij.util.containers.Stack;
import com.intellij.vcs.log.graph.api.LiteLinearGraph;
	@@ -61,14 +62,14 @@ public static void walk(@NotNull LiteLinearGraph graph, int start, @NotNull Node
        visitor.enterNode(currentNode, getPreviousNode(stack), down);
      }

      for (int nextNode: graph.getNodes(currentNode, down ? LiteLinearGraph.NodeFilter.DOWN : LiteLinearGraph.NodeFilter.UP)) {
        if (!visited.get(nextNode)) {
          stack.push(new Pair<>(nextNode, down));
          continue outer;
        }
      }

      for (int nextNode: graph.getNodes(currentNode, down ? LiteLinearGraph.NodeFilter.UP : LiteLinearGraph.NodeFilter.DOWN)) {
        if (!visited.get(nextNode)) {
          stack.push(new Pair<>(nextNode, !down));
          continue outer;
	@@ -103,4 +104,29 @@ public static void walk(int startRowIndex, @NotNull NextNode nextNodeFun) {
    }
    stack.clear();
  }

  public static boolean isAncestor(@NotNull LiteLinearGraph graph, int lowerNode, int upperNode) {
    BitSetFlags visited = new BitSetFlags(graph.nodesCount(), false);

    Ref<Boolean> result = Ref.create(false);
    walk(lowerNode, currentNode -> {
      visited.set(currentNode, true);

      if (currentNode == upperNode) {
        result.set(true);
        return NextNode.EXIT;
      }
      if (currentNode > upperNode) {
        for (int nextNode: graph.getNodes(currentNode, LiteLinearGraph.NodeFilter.UP)) {
          if (!visited.get(nextNode)) {
            return nextNode;
          }
        }
      }

      return NextNode.NODE_NOT_FOUND;
    });

    return result.get();
  }
}
                                                
                                                
 <<>> 14 Jun 2018 <<>>







import com.intellij.vcs.log.graph.api.LiteLinearGraph
import com.intellij.vcs.log.graph.api.permanent.PermanentCommitsInfo
import com.intellij.vcs.log.graph.api.permanent.PermanentGraphInfo
import com.intellij.vcs.log.graph.collapsing.CollapsedGraph
import com.intellij.vcs.log.graph.impl.facade.*
import com.intellij.vcs.log.graph.utils.BfsUtil
import com.intellij.vcs.log.graph.utils.DfsUtil
import com.intellij.vcs.log.graph.utils.LinearGraphUtils
	@@ -30,14 +29,19 @@ internal class FileHistoryBuilder(private val startCommit: Int?,
  override fun accept(controller: LinearGraphController, permanentGraphInfo: PermanentGraphInfo<Int>) {
    pathsMap.putAll(refine(controller, startCommit, permanentGraphInfo))

    val trivialCandidates = mutableSetOf<Int>()
    pathsMap.forEach { c, p ->
      if (fileNamesData.isTrivialMerge(c, p)) {
        trivialCandidates.add(c)
      }
    }

    modifyGraph(controller) { collapsedGraph ->
      val trivialMerges = hideTrivialMerges(collapsedGraph) { nodeId: Int ->
        trivialCandidates.contains(permanentGraphInfo.permanentCommitsInfo.getCommitId(nodeId))
      }
      trivialMerges.forEach { pathsMap.remove(permanentGraphInfo.permanentCommitsInfo.getCommitId(it)) }
    }
  }

  private fun refine(controller: LinearGraphController,
	@@ -53,7 +57,7 @@ internal class FileHistoryBuilder(private val startCommit: Int?,
        val refiner = FileHistoryRefiner(visibleLinearGraph, permanentGraphInfo, fileNamesData)
        val (paths, excluded) = refiner.refine(row, startPath)
        if (!excluded.isEmpty()) {
          val hidden = hideCommits(controller, permanentGraphInfo, excluded)
          if (!hidden) LOG.error("Could not hide excluded commits from history for " + startPath.path)
        }
        return paths
	@@ -67,6 +71,42 @@ internal class FileHistoryBuilder(private val startCommit: Int?,
  }
}

fun hideTrivialMerges(collapsedGraph: CollapsedGraph,
                      isCandidateNodeId: (Int) -> Boolean): Set<Int> {
  val result = mutableSetOf<Int>()
  val graph = LinearGraphUtils.asLiteLinearGraph(collapsedGraph.compiledGraph)

  for (v in graph.nodesCount() - 1 downTo 0) {
    val nodeId = collapsedGraph.compiledGraph.getNodeId(v)
    if (isCandidateNodeId(nodeId)) {
      val downNodes = graph.getNodes(v, LiteLinearGraph.NodeFilter.DOWN)
      if (downNodes.size == 1) {
        result.add(nodeId)
        hideTrivialMerge(collapsedGraph, graph, v, downNodes.single())
      }
      else if (downNodes.size == 2) {
        val lowerParent = downNodes.max()!!
        val upperParent = downNodes.min()!!
        if (DfsUtil.isAncestor(graph, lowerParent, upperParent)) {
          result.add(nodeId)
          hideTrivialMerge(collapsedGraph, graph, v, upperParent)
        }
      }
    }
  }

  return result
}

private fun hideTrivialMerge(collapsedGraph: CollapsedGraph, graph: LiteLinearGraph, node: Int, singleParent: Int) {
  collapsedGraph.modify {
    hideRow(node)
    for (upNode in graph.getNodes(node, LiteLinearGraph.NodeFilter.UP)) {
      connectRows(upNode, singleParent)
    }
  }
}

internal fun findAncestorRowAffectingFile(commitId: Int,
                                          filePath: FilePath,
                                          visibleLinearGraph: LinearGraph,                                       
                                          
<<>> 14 Jun 2018<<>>

import java.util.function.BiConsumer

internal class FileHistoryBuilder(private val startCommit: Int?,
                                  private val startPath: FilePath,
                                  private val fileNamesData: FileNamesData) : BiConsumer<LinearGraphController, PermanentGraphInfo<Int>> {
  val pathsMap = mutableMapOf<Int, FilePath>()

  override fun accept(controller: LinearGraphController, permanentGraphInfo: PermanentGraphInfo<Int>) {
    val visibleLinearGraph = controller.compiledGraph

    val row = startCommit?.let {
      findAncestorRowAffectingFile(startCommit, startPath, visibleLinearGraph, permanentGraphInfo, fileNamesData)
    } ?: 0
    if (row >= 0) {
      val refiner = FileHistoryRefiner(visibleLinearGraph, permanentGraphInfo, fileNamesData)
      if (refiner.refine(row, startPath)) {
        val hidden = hideInplace(controller, permanentGraphInfo, refiner.excluded)
        if (!hidden) LOG.error("Could not hide excluded commits from history for " + startPath.path)
        pathsMap.putAll(refiner.pathsForCommits)
        return
      }
    }
    pathsMap.putAll(fileNamesData.buildPathsMap())
  }

  companion object {
    private val LOG = Logger.getInstance(FileHistoryBuilder::class.java)
  }
}
 
 
 <<>> 14 Jun 2018<<>>
 internal fun findAncestorRowAffectingFile(commitId: Int,
                                          filePath: FilePath,
                                          permanentGraph: PermanentGraphImpl<Int>,
                                          visibleGraph: VisibleGraph<Int>,
                                          fileNamesData: FileNamesData): Int {
  val result = Ref<Int>()

  val commitsInfo = permanentGraph.permanentCommitsInfo
  val reachableNodes = ReachableNodes(LinearGraphUtils.asLiteLinearGraph(permanentGraph.linearGraph))
  reachableNodes.walk(setOf(commitsInfo.getNodeId(commitId)), true) { currentNode ->
    val id = commitsInfo.getCommitId(currentNode)
    if (fileNamesData.affects(id, filePath)) {
      result.set(currentNode)
      false // stop walk, we have found it
    }
    else {
      true // continue walk
    }
  }

  if (!result.isNull) {
    return visibleGraph.getVisibleRowIndex(commitsInfo.getCommitId(result.get()))!!
  }

  return -1
}
                                          
                                          
                                          
                                          
                                                