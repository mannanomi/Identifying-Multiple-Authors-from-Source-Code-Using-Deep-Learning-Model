<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/history/FileHistoryUiProperties.java<<>>

<<>> 23 April 2021<<>>

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.*;
import com.intellij.util.EventDispatcher;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.vcs.log.impl.VcsLogApplicationSettings;
import com.intellij.vcs.log.impl.VcsLogUiProperties;
	@@ -22,7 +23,7 @@
public final class FileHistoryUiProperties implements VcsLogUiProperties, PersistentStateComponent<FileHistoryUiProperties.State> {
  public static final VcsLogUiProperty<Boolean> SHOW_ALL_BRANCHES = new VcsLogUiProperty<>("Table.ShowOtherBranches");

  @NotNull private final EventDispatcher<PropertiesChangeListener> myEventDispatcher = EventDispatcher.create(PropertiesChangeListener.class);
  @NotNull private final VcsLogApplicationSettings myAppSettings =
    ApplicationManager.getApplication().getService(VcsLogApplicationSettings.class);
  @NotNull private final PropertiesChangeListener myApplicationSettingsListener = this::onApplicationSettingChange;
	@@ -88,7 +89,7 @@

  private <T> void onApplicationSettingChange(@NotNull VcsLogUiProperty<T> property) {
    if (PREFER_COMMIT_DATE.equals(property)) {
      myEventDispatcher.getMulticaster().onPropertyChanged(property);
    }
  }

	@@ -124,7 +125,7 @@ else if (PREFER_COMMIT_DATE.equals(property)) {
    else {
      throw new UnsupportedOperationException("Unknown property " + property);
    }
    myEventDispatcher.getMulticaster().onPropertyChanged(property);
  }

  @Override
	@@ -152,16 +153,16 @@ public void loadState(@NotNull State state) {

  @Override
  public void addChangeListener(@NotNull PropertiesChangeListener listener) {
    if (!myEventDispatcher.hasListeners()) {
      myAppSettings.addChangeListener(myApplicationSettingsListener);
    }
    myEventDispatcher.addListener(listener);
  }

  @Override
  public void removeChangeListener(@NotNull PropertiesChangeListener listener) {
    myEventDispatcher.removeListener(listener);
    if (!myEventDispatcher.hasListeners()) {
      myAppSettings.removeChangeListener(myApplicationSettingsListener);
    }
  }