<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/history/FileHistoryUi.java<<>>
<<>> 14 jun 2018 <<>>

import com.google.common.util.concurrent.SettableFuture;
import com.intellij.openapi.extensions.Extensions;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.changes.Change;
import com.intellij.openapi.vcs.changes.ContentRevision;
	@@ -91,8 +92,8 @@ public FileHistoryUi(@NotNull VcsLogData logData,
    myPath = path;
    myFileHistoryPanel = new FileHistoryPanel(this, logData, myVisiblePack, path);

    for (VcsLogHighlighterFactory factory: ContainerUtil.filter(Extensions.getExtensions(LOG_HIGHLIGHTER_FACTORY_EP, myProject),
                                                                f -> HIGHLIGHTERS.contains(f.getId()))) {
      getTable().addHighlighter(factory.createHighlighter(logData, this));
    }

	@@ -128,7 +129,7 @@ public VirtualFile createVcsVirtualFile(@Nullable VcsFileRevision revision) {
  public VcsFileRevision createRevision(@Nullable VcsFullCommitDetails details) {
    if (details != null && !(details instanceof LoadingDetails)) {
      List<Change> changes = collectRelevantChanges(details);
      for (Change change: changes) {
        ContentRevision revision = change.getAfterRevision();
        if (revision != null) {
          return new VcsLogFileRevision(details, revision, revision.getFile());
	@@ -147,7 +148,7 @@ public FilePath getPath(@NotNull VcsFullCommitDetails details) {
    if (myPath.isDirectory()) return myPath;

    List<Change> changes = collectRelevantChanges(details);
    for (Change change: changes) {
      ContentRevision revision = change.getAfterRevision();
      if (revision != null) {
        return revision.getFile();
	@@ -160,12 +161,22 @@ public FilePath getPath(@NotNull VcsFullCommitDetails details) {
  @NotNull
  public List<Change> collectRelevantChanges(@NotNull VcsFullCommitDetails details) {
    Set<FilePath> fileNames = getFileNames(details);
    return collectRelevantChanges(details,
                                  change -> myPath.isDirectory() ? affectsDirectories(change, fileNames) : affectsFiles(change, fileNames));
  }

  @NotNull
  private static List<Change> collectRelevantChanges(@NotNull VcsFullCommitDetails details,
                                                     @NotNull Condition<Change> isRelevant) {
    List<Change> changes = ContainerUtil.filter(details.getChanges(), isRelevant);
    if (!changes.isEmpty()) return changes;
    if (details.getParents().size() > 1) {
      for (int parent = 0; parent < details.getParents().size(); parent++) {
        List<Change> changesToParent = ContainerUtil.filter(details.getChanges(parent), isRelevant);
        if (!changesToParent.isEmpty()) return changesToParent;
      }
    }
    return Collections.emptyList();
  }

  @NotNull
	@@ -197,7 +208,7 @@ private static boolean affectsDirectories(@NotNull Change change, @NotNull Set<F
  public List<Change> collectChanges(@NotNull List<VcsFullCommitDetails> detailsList, boolean onlyRelevant) {
    List<Change> changes = ContainerUtil.newArrayList();
    List<VcsFullCommitDetails> detailsListReversed = ContainerUtil.reverse(detailsList);
    for (VcsFullCommitDetails details: detailsListReversed) {
      changes.addAll(onlyRelevant ? collectRelevantChanges(details) : details.getChanges());
    }