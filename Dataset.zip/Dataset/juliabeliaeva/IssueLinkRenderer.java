<<>>platform/vcs-impl/src/com/intellij/openapi/vcs/changes/issueLinks/IssueLinkRenderer.java<<>>
<<>> 9 Dec 2020 <<>>

package com.intellij.openapi.vcs.changes.issueLinks;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.openapi.vcs.IssueNavigationConfiguration;
import com.intellij.ui.SimpleColoredComponent;
import com.intellij.ui.SimpleTextAttributes;
	@@ -52,37 +52,28 @@ public IssueLinkRenderer(final Project project, final SimpleColoredComponent col
  public List<String> appendTextWithLinks(@Nls String text,
                                          @NotNull SimpleTextAttributes baseStyle,
                                          @NotNull Consumer<? super @Nls String> consumer) {
    List<String> pieces = new ArrayList<>();

    SimpleTextAttributes linkAttributes = getLinkAttributes(baseStyle);
    IssueNavigationConfiguration.processTextWithLinks(text, myIssueNavigationConfiguration.findIssueLinks(text),
                                                      s -> {
                                                        pieces.add(s);
                                                        consumer.consume(s);
                                                      },
                                                      (link, target) -> {
                                                        pieces.add(link);
                                                        append(link, linkAttributes, target);
                                                      });

    return pieces;
  }

  private void append(@Nls String piece, final SimpleTextAttributes baseStyle) {
    myColoredComponent.append(piece, baseStyle);
  }

  private void append(@Nls String piece, final SimpleTextAttributes baseStyle, @NlsSafe String targetUrl) {
    myColoredComponent.append(piece, baseStyle, new SimpleColoredComponent.BrowserLauncherTag(targetUrl));
  }

  private static SimpleTextAttributes getLinkAttributes(@NotNull SimpleTextAttributes baseStyle) {
      
 <<>> 9 Dec 2020 <<>>
     
      String comment = XmlStringUtil.escapeString(VcsUtil.trimCommitMessageToSaneSize(str), false);
    IssueNavigationConfiguration.processTextWithLinks(comment, IssueNavigationConfiguration.getInstance(project).findIssueLinks(comment),
                                                      s -> commentBuilder.append(convertor.convert(s)),
                                                      (text, target) -> {
                                                        commentBuilder
                                                          .append("<a href=\"")
                                                          .append(target).append("\">")
                                                          .append(text).append("</a>");
                                                      });
    return commentBuilder.toString().replace("\n", UIUtil.BR);