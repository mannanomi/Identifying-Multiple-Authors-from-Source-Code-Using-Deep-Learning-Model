<<>>platform/vcs-log/impl/src/com/intellij/vcs/log/visible/VcsLogFiltererImpl.java<<>>
<<>> 19 Jun 2018 <<>>
 VcsLogHashFilter hashFilter = filters.get(VcsLogFilterCollection.HASH_FILTER);
    if (hashFilter != null && !hashFilter.getHashes().isEmpty()) { // hashes should be shown, no matter if they match other filters or not
      VisiblePack visiblePack = applyHashFilter(dataPack, hashFilter.getHashes(), sortType);
      if (visiblePack != null) {
        return Pair.create(visiblePack, commitCount);
      }
    }

    filters = new VcsLogFilterCollectionBuilder(filters).without(VcsLogFilterCollection.HASH_FILTER).build();

    Collection<VirtualFile> visibleRoots = VcsLogUtil.getAllVisibleRoots(dataPack.getLogProviders().keySet(), filters);
    Set<Integer> matchingHeads = getMatchingHeads(dataPack.getRefsModel(), visibleRoots, filters);
    FilterByDetailsResult filterResult = filterByDetails(dataPack, filters, commitCount, visibleRoots, matchingHeads);
	@@ -168,14 +173,16 @@ public boolean canFilterEmptyPack(@NotNull VcsLogFilterCollection filters) {
    return matchingSet != null && matchingSet.isEmpty();
  }

  @Nullable
  private VisiblePack applyHashFilter(@NotNull DataPack dataPack,
                                      @NotNull Collection<String> hashes,
                                      @NotNull PermanentGraph.SortType sortType) {
    Set<Integer> indices = ContainerUtil.map2SetNotNull(hashes, partOfHash -> {
      CommitId commitId = myStorage.findCommitId(new CommitIdByStringCondition(partOfHash));
      return commitId != null ? myStorage.getCommitIndex(commitId.getHash(), commitId.getRoot()) : null;
    });
    if (indices.isEmpty()) return null;

    VisibleGraph<Integer> visibleGraph = dataPack.getPermanentGraph().createVisibleGraph(sortType, null, indices);
    return new VisiblePack(dataPack, visibleGraph, false,
                           new VcsLogFilterCollectionBuilder(new VcsLogHashFilterImpl(hashes)).build());
	@@ -234,7 +241,7 @@ private VisiblePack applyHashFilter(@NotNull DataPack dataPack,
  @NotNull
  private Set<Integer> getMatchingHeads(@NotNull VcsLogRefs refs, @NotNull Collection<VirtualFile> roots) {
    Set<Integer> result = new HashSet<>();
    for (VcsRef branch: refs.getBranches()) {
      if (roots.contains(branch.getRoot())) {
        result.add(myStorage.getCommitIndex(branch.getCommitHash(), branch.getRoot()));
      }
	@@ -247,7 +254,7 @@ private VisiblePack applyHashFilter(@NotNull DataPack dataPack,
                                              @NotNull List<VcsLogDetailsFilter> detailsFilters,
                                              @Nullable Set<Integer> matchingHeads) {
    Collection<CommitId> result = ContainerUtil.newArrayList();
    for (GraphCommit<Integer> commit: permanentGraph.getAllCommits()) {
      VcsCommitMetadata data = getDetailsFromCache(commit.getId());
      if (data == null) {
        // no more continuous details in the cache
	@@ -295,7 +302,7 @@ private VcsCommitMetadata getDetailsFromCache(final int commitIndex) {
    Set<VirtualFile> visibleRoots = VcsLogUtil.getAllVisibleRoots(providers.keySet(), filterCollection);

    Collection<CommitId> commits = ContainerUtil.newArrayList();
    for (Map.Entry<VirtualFile, VcsLogProvider> entry: providers.entrySet()) {
      final VirtualFile root = entry.getKey();

      VcsLogUserFilter userFilter = filterCollection.get(VcsLogFilterCollection.USER_FILTER);