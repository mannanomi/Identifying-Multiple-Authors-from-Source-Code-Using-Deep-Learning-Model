<<>>plugins/InspectionGadgets/src/com/siyeh/ig/style/BoundedWildcardInspection.java<<>>
<<>> 4 May 2018 <<>>

return new JavaElementVisitor() {
      @Override
      public void visitTypeElement(PsiTypeElement typeElement) {
        VarianceCandidate candidate = VarianceCandidate.findVarianceCandidate(typeElement);
        if (candidate == null) return;
        PsiClassReferenceType extendsT = suggestMethodParameterType(candidate, true);
        PsiClassReferenceType superT = suggestMethodParameterType(candidate, false);
        Variance variance = checkParameterVarianceInMethodBody(candidate.methodParameter, candidate.method, candidate.typeParameter,
                                                               extendsT, superT);
        if (variance == Variance.CONTRAVARIANT && makesSenseToSuper(candidate)) {
          holder.registerProblem(typeElement, InspectionGadgetsBundle.message("bounded.wildcard.contravariant.descriptor"),
                                 new ReplaceWithQuestionTFix(isOverriddenOrOverrides(candidate.method), false));
        }
        if (variance == Variance.COVARIANT && makesSenseToExtend(candidate)) {
          holder.registerProblem(typeElement, InspectionGadgetsBundle.message("bounded.wildcard.covariant.descriptor"),
                                 new ReplaceWithQuestionTFix(isOverriddenOrOverrides(candidate.method), true));
        }


<<>> 4 May 2018 <<>>

   int index = ContainerUtil.indexOf(exprs, (PsiExpression e) -> PsiTreeUtil.isAncestor(e, refElement, false));
    if (index == -1) return false;
    PsiElement parent2 = parent.getParent();
    JavaResolveResult result;
    if (parent2 instanceof PsiAnonymousClass) {
      PsiElement newExpression = parent2.getParent();
      if (newExpression instanceof PsiCall) {
        result = ((PsiCall)newExpression).resolveMethodGenerics();
      }
      else {
        return false;
      }
    }
    else if (parent2 instanceof PsiCallExpression) {
      result = ((PsiCallExpression)parent2).resolveMethodGenerics();
    }
    else {
      return false;
    }
    PsiElement resolved = result.getElement();
    if (!(resolved instanceof PsiMethod)) return false;
    PsiMethod method = (PsiMethod)resolved;
    if (method.getManager().areElementsEquivalent(method, myself)
        || MethodSignatureUtil.isSuperMethod(method, myself)) return true; // recursive call or super.foo() call      



      <<>> 4 May 2018 <<>>

     if (dialog.getExitCode() == DialogWrapper.OK_EXIT_CODE) {
        PsiField field = findFieldAssignedFromMethodParameter(candidate.methodParameter, method);
        if (field != null) {
          replaceType(project, field.getTypeElement(), suggestMethodParameterType(candidate, isExtends));
        }
      }
    }

    private static void replaceType(@NotNull Project project, @NotNull PsiTypeElement typeElement, @NotNull PsiType withType) {
      PsiElementFactory pf = PsiElementFactory.SERVICE.getInstance(project);
      PsiTypeElement newTypeElement = pf.createTypeElement(withType);
      WriteCommandAction.runWriteCommandAction(project, (Runnable)() -> typeElement.replace(newTypeElement));
    }

    @Override
  @@ -279,26 +297,62 @@ Variance combine(@NotNull Variance other) {
    }
  }

  private static PsiField findFieldAssignedFromMethodParameter(@NotNull PsiParameter methodParameter, @NotNull PsiMethod method) {
    PsiCodeBlock methodBody = method.getBody();
    if (methodBody == null) return null;
    PsiField[] v = {null};

    ReferencesSearch.search(methodParameter, new LocalSearchScope(methodBody)).forEach(ref -> {
      ProgressManager.checkCanceled();
      v[0] = isAssignedToField(ref);
      return v[0] == null;
    });

    return v[0];
  }

  @NotNull
  private static Variance checkParameterVarianceInMethodBody(@NotNull PsiParameter methodParameter,
                                                             @NotNull PsiMethod method,
                                                             @NotNull PsiTypeParameter typeParameter,
                                                             @NotNull PsiClassReferenceType extendsT,
                                                             @NotNull PsiClassReferenceType superT) {
    PsiCodeBlock methodBody = method.getBody();
    if (methodBody == null) return Variance.INVARIANT;
    return getVariance(methodParameter, new LocalSearchScope(methodBody), null, method, typeParameter, extendsT, superT);
  }

  @NotNull
  private static Variance getVariance(@NotNull PsiElement element,
                                      @NotNull LocalSearchScope searchScope,
                                      @Nullable PsiElement ignoreUsagesIn,
                                      @NotNull PsiMethod containingMethod,
                                      @NotNull PsiTypeParameter typeParameter,
                                      @NotNull PsiClassReferenceType extendsT,
                                      @NotNull PsiClassReferenceType superT) {
    Variance[] v = {Variance.NOVARIANT};
    ReferencesSearch.search(element, searchScope).forEach(ref -> {
      ProgressManager.checkCanceled();
      if (PsiTreeUtil.isAncestor(ignoreUsagesIn, ref.getElement(), false)) return true;
      PsiMethod calledMethod = getMethodCallOnReference(ref);
      if (calledMethod == null) {
        if (isInComparison(ref)) return true; // ignore "x == y"
        PsiField field = isAssignedToField(ref);
        if (field != null) {
          // check if e.g. "Processor<String> field" is used in "field.process(xxx)" only
          PsiElement ignoreUsagesInAssignment = PsiUtil.skipParenthesizedExprUp(ref.getElement().getParent());
          PsiClass fieldClass = field.getContainingClass();
          Variance fv = fieldClass == null ? Variance.INVARIANT :
                        getVariance(field, new LocalSearchScope(fieldClass), ignoreUsagesInAssignment, containingMethod, typeParameter, extendsT, superT);
          v[0] = v[0].combine(fv);
        }
        else if (isIteratedValueInForeachExpression(ref)) {
          // heuristics: "for (e in List<T>)" can be replaced with "for (e in List<? extends T>)"
          v[0] = v[0].combine(Variance.COVARIANT);
        }
        else {
          boolean canBeSuperT = isPassedToMethodWhichAlreadyAcceptsQuestionT(ref, superT, containingMethod);
          boolean canBeExtendsT = isPassedToMethodWhichAlreadyAcceptsQuestionT(ref, extendsT, containingMethod);


<<>> 4 May 2018<<>>
   private static PsiField isAssignedToField(PsiReference ref) {
    PsiElement refElement = ref.getElement();
    PsiElement parent = PsiUtil.skipParenthesizedExprUp(refElement.getParent());
    if (!(parent instanceof PsiAssignmentExpression) || ((PsiAssignmentExpression)parent).getOperationTokenType() != JavaTokenType.EQ) return null;
    PsiExpression r = ((PsiAssignmentExpression)parent).getRExpression();
    if (!PsiTreeUtil.isAncestor(r, refElement, false)) return null;
    PsiExpression l = ((PsiAssignmentExpression)parent).getLExpression();
    if (!(l instanceof PsiReferenceExpression)) return null;
    PsiReferenceExpression lExpression = (PsiReferenceExpression)l;
    PsiExpression lQualifier = lExpression.getQualifierExpression();
    if (lQualifier != null && !(lQualifier instanceof PsiThisExpression)) return null;
    PsiElement field = lExpression.resolve();
    if (!(field instanceof PsiField)) return null;
    return (PsiField)field;
  }
       