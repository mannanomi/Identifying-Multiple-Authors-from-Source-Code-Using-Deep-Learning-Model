<<>>platform/indexing-impl/src/com/intellij/psi/impl/search/PsiSearchHelperImpl.java<<>
<<>> 10 May 2018 <<>>

 final Processor<VirtualFile> processor = vfile -> {
          ProgressManager.checkCanceled();
          if (failedFiles.isEmpty()) {
            try {
              // wrap in unconditional impatient reader to bail early at write action start,
              // regardless of whether was called from highlighting (already impatient-wrapped) or Find Usages action
              app.executeByImpatientReader(() -> {
                if (!localProcessor.process(vfile)) {
                  stopped.set(true);
                }
              });
            }
            catch (ApplicationUtil.CannotRunReadActionException action) {
              failedFiles.add(vfile);
            }
          }
          else {
            // 1st: optimisation to avoid unnecessary processing if it's doomed to fail because some other task has failed already,
            // and 2nd: bail out of fork/join task as soon as possible
            failedFiles.add(vfile);
          }
          return !stopped.get();
        };

        