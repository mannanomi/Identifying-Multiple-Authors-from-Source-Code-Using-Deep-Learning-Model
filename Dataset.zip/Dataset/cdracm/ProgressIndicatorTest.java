<<>>platform/platform-tests/testSrc/com/intellij/openapi/progress/impl/ProgressIndicatorTest.java<<>>
<<>> 21 April 2021 <<>>

public void testInvalidStateActionsMustLeadToExceptions() {
    DefaultLogger.disableStderrDumping(getTestRootDisposable());
    ProgressIndicator indicator = new ProgressIndicatorBase(false);
    indicator.start();
    assertThrows(Exception.class, () -> indicator.start());
    indicator.cancel();
    indicator.stop();
    assertThrows(Exception.class, () -> indicator.start());

    assertThrows(Exception.class, () -> new ProgressIndicatorBase().stop());
  }