<<>>platform/platform-tests/testSrc/com/intellij/openapi/editor/impl/RangeMarkerTest.java<<>>
<<>> 10 May 2018 <<>>

  public void testRangeMarkerContinuesToReceiveEventsFromDocumentAfterItsBeingGcedAndRecreatedAgain_NoCommand() {
    // need to be physical file
    VirtualFile vf = VfsTestUtil.createFile(getSourceRoot(), "x.txt", "blah");
    PsiFile psiFile = ObjectUtils.notNull(getPsiManager().findFile(vf));
    RangeMarker marker = createMarker(psiFile, 0, 4);
    RangeMarker persistentMarker = document.createRangeMarker(0, 4, true);
    Reference<Document> ref = new WeakReference<>(document);
    int docHash0 = System.identityHashCode(document);
    this.psiFile = null;
    fileNode = null;
    document = null;

    while (ref.get() != null) {
      GCUtil.tryForceGC();
      UIUtil.dispatchAllInvocationEvents();
    }
    assertTrue(marker.isValid());
    assertTrue(persistentMarker.isValid());

    Document newDoc = ObjectUtils.notNull(PsiDocumentManager.getInstance(getProject()).getDocument(psiFile));
    int docHash1 = System.identityHashCode(newDoc);
    assertNotSame(docHash0, docHash1);

    WriteCommandAction.runWriteCommandAction(getProject(), ()->newDoc.insertString(2,"000"));
    assertTrue(marker.isValid());
    assertEquals("bl000ah", TextRange.create(marker).substring(newDoc.getText()));
    assertTrue(persistentMarker.isValid());
    assertEquals("bl000ah", TextRange.create(persistentMarker).substring(newDoc.getText()));

    Reference<RangeMarker> markerRef = new WeakReference<>(marker);
    Reference<RangeMarker> persistentMarkerRef = new WeakReference<>(persistentMarker);
    //noinspection UnusedAssignment
    marker = null;
    //noinspection UnusedAssignment
    persistentMarker = null;
    PsiDocumentManager.getInstance(getProject()).commitAllDocuments();
    while (markerRef.get() != null || persistentMarkerRef.get() != null) {
      GCUtil.tryForceGC();
      UIUtil.dispatchAllInvocationEvents();
    }

    DocumentImpl.processQueue();

    UIUtil.dispatchAllInvocationEvents();

    assertNull(vf.getUserData(DocumentImpl.RANGE_MARKERS_KEY));
    assertNull(vf.getUserData(DocumentImpl.PERSISTENT_RANGE_MARKERS_KEY));
  }