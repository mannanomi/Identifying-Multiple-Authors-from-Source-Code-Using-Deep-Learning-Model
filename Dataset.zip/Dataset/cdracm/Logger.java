<<>>platform/util/src/com/intellij/openapi/diagnostic/Logger.java<<>>
<<>> 19 April 2021 <<>>

  protected static Throwable ensureNotControlFlow(@Nullable Throwable t) {
    return t instanceof ControlFlowException ?
           new Throwable("Control-flow exceptions (like " + t.getClass().getSimpleName() + ") should never be logged: " +
                         "ignore for explicitly started processes or rethrow to handle on the outer process level", t)
                                             : t;
  }

  @TestOnly
  public static void setUnitTestMode() {
    isUnitTestMode = true;
  }

  /**
   * {@link #warn} in production, {@link #error} in tests
   */
  public void warnInProduction(@NotNull Throwable t) {
    if (isUnitTestMode) {
      error(t);
    }
    else {
      warn(t);
    }