<<>> platform/core-impl/src/com/intellij/openapi/progress/util/AbstractProgressIndicatorBase.java <<>>
<<>> 21 April 2021 <<>>

   getStateStack().push(getState());
    }
  }

  @NotNull
  private State getState() {
    return new State(getText(), getText2(), getFraction(), isIndeterminate());
  }

  private void restoreFrom(@NotNull State state) {
    setText(state.myText);
    setText2(state.myText2);
    setIndeterminate(state.myIndeterminate);
    if (!isIndeterminate()) {
      setFraction(state.myFraction);
