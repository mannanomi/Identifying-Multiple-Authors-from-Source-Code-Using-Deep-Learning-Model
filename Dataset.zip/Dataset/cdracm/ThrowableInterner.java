<<>>platform/util/src/com/intellij/openapi/util/objectTree/ThrowableInterner.java<<>>
<<>> 221 April 2021 <<>>

  // more accurate hash code (different for different line numbers inside same method) but more expensive than computeTraceHashCode
  public static int computeAccurateTraceHashCode(@NotNull Throwable throwable) {
    Object[] backtrace = getBacktrace(throwable);
    if (backtrace == null) {
      return Arrays.hashCode(throwable.getStackTrace());
    }
    return Arrays.deepHashCode(backtrace);
  }