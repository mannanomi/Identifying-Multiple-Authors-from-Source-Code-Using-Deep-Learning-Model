<<>>platform/util/src/com/intellij/util/containers/RefHashMap.java<<>>
<<>> 8 April 2021 <<>>

assert newN != 0;
      Object[] key = this.key;
      Object[] value = this.value;
      int mask = newN - 1; // Note that this is used by the hashing macro
      Key<K>[] newKey = new Key[newN + 1];
      Object[] newValue = new Object[newN + 1];
      int pos;
      int keysToProcess = size;
      for (int i = n; i >= 0 && keysToProcess > 0; i--) {
        Key<K> k = (Key<K>)key[i];
        if (k == null) {
          continue;
        }
        keysToProcess--;
        K referent = k.get();
        if (referent == null) {
          size--;
          continue;
        }
        if (!(newKey[pos = HashCommon.mix(k.hashCode()) & mask] == null)) {
          while (!(newKey[pos = (pos + 1) & mask] == null)) ;
        }
        newKey[pos] = k;
        newValue[pos] = value[i];
        // avoid inserting gced keys into new table
        ObjectUtils.reachabilityFence(referent);
      }
      newValue[newN] = value[n];
      n = newN;
      this.mask = mask;
      maxFill = HashCommon.maxFill(n, f);
      this.key = newKey;
      this.value = (V[])newValue;