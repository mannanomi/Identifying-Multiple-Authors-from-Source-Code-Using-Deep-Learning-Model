<<>>platform/platform-tests/testSrc/com/intellij/openapi/fileTypes/impl/FileTypesTest.java<<>>
<<>> 14 April 2021 <<>>


  public void testRegisterFileTypesWithIdenticalDisplayNameOrDescriptionMustThrow() {
    DefaultLogger.disableStderrDumping(getTestRootDisposable());

    Disposable disposable = Disposer.newDisposable();
    try {
      createFakeType("myCreativeName0", "display1", "descr1", "ext1", disposable);
      createFakeType("myCreativeName1", "display1", "descr2", "ext2", disposable);
      assertThrows(Throwable.class, () -> initStandardFileTypes());
      myFileTypeManager.unregisterFileType(myFileTypeManager.findFileTypeByName("myCreativeName0"));
      myFileTypeManager.unregisterFileType(myFileTypeManager.findFileTypeByName("myCreativeName1"));
      createFakeType("myCreativeName2", "display0", "descr", "ext1", disposable);
      createFakeType("myCreativeName3", "display1", "descr", "ext2", disposable);
      assertThrows(Throwable.class, () -> initStandardFileTypes());
      myFileTypeManager.unregisterFileType(myFileTypeManager.findFileTypeByName("myCreativeName2"));
      myFileTypeManager.unregisterFileType(myFileTypeManager.findFileTypeByName("myCreativeName3"));
    }
    finally {
      Disposer.dispose(disposable);
    }
    initStandardFileTypes(); // give FileTypeManagerImpl chance to finish init standard file types without exceptions
  }

  @NotNull
  private static FileType createFakeType(@NotNull String name,
                                         @NotNull String displayName,
                                         @NotNull String description,
                                         @NotNull String extension,
                                         @NotNull Disposable disposable) {
    FileType myType = new FakeFileType() {
      @Override
      public boolean isMyFileType(@NotNull VirtualFile file) {
        return false;
      }

      @Override
      public @NotNull @NonNls String getName() {
        return name;
      }

      @Nls
      @Override
      public @NotNull String getDisplayName() {
        return displayName;
      }

      @Override
      public @NotNull @NlsContexts.Label String getDescription() {
        return description;
      }
    };
    FileTypeFactory.FILE_TYPE_FACTORY_EP.getPoint().registerExtension(new FileTypeFactory() {
      @Override
      public void createFileTypes(@NotNull FileTypeConsumer consumer) {
        consumer.consume(myType, extension);
      }
    }, disposable);
    return myType;
  }