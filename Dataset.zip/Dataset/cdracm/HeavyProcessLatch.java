<<>>platform/util/src/com/intellij/util/io/storage/HeavyProcessLatch.java<<>>
<<>> 14 April 2021 <<>>

import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Allows to track some operations as "heavy" and query about their execution status.
 * Typically, some threads call {@link #performOperation} to execute heavy operation (heavy operations can be arbitrarily interleaved).
 * Some other threads then call {@link #isRunning()} and others to query for heavy operations running in background.
 */
public final class HeavyProcessLatch {
  private static final Logger LOG = Logger.getInstance(HeavyProcessLatch.class);
  public static final HeavyProcessLatch INSTANCE = new HeavyProcessLatch();

  private final List<Operation> myHeavyProcesses = ContainerUtil.createLockFreeCopyOnWriteList();
  private final EventDispatcher<HeavyProcessListener> myEventDispatcher = EventDispatcher.create(HeavyProcessListener.class);

  private final Queue<Runnable> toExecuteOutOfHeavyActivity = new ConcurrentLinkedQueue<>();

  private HeavyProcessLatch() {
  }

  /**
   * Approximate type of a heavy operation. Used in {@link com.intellij.codeInsight.daemon.impl.TrafficLightRenderer} UI as brief description.
   */
  public enum Type {
    Indexing("heavyProcess.type.indexing"),
    Syncing("heavyProcess.type.syncing"),
    Processing("heavyProcess.type.processing");

    private final String bundleKey;
    Type(@NotNull String bundleKey) {
      this.bundleKey = bundleKey;
    }

	@@ -49,56 +53,75 @@ public String toString() {
    }
  }

  /**
   * @deprecated use {@link #performOperation} instead
   */
  @Deprecated
  public @NotNull AccessToken processStarted(@NotNull @Nls String displayName) {
    Op op = new Op(Type.Processing, displayName);
    myHeavyProcesses.add(op);
    myEventDispatcher.getMulticaster().processStarted();
    return new AccessToken() {
      @Override
      public void finish() {
        myEventDispatcher.getMulticaster().processFinished();
        myHeavyProcesses.remove(op);
        executeHandlers();
      }
    };
  }

  /**
   * Executes {@code runnable} as a heavy operation. E.g. during this method execution, {@link #isRunning()} returns true.
   */
  public void performOperation(@NotNull Type type, @NotNull @Nls String displayName, @NotNull Runnable runnable) {
    Op op = new Op(type, displayName);
    myHeavyProcesses.add(op);
    myEventDispatcher.getMulticaster().processStarted();
    try {
      runnable.run();
    }
    finally {
      myEventDispatcher.getMulticaster().processFinished();
      myHeavyProcesses.remove(op);
      executeHandlers();
    }
  }

  private void executeHandlers() {
    if (!isRunning()) {
      Runnable runnable;
      while ((runnable = toExecuteOutOfHeavyActivity.poll()) != null) {
        try {
          runnable.run();
        }
        catch (Exception e) {
          LOG.error(e);
        }
      }
    }
  }

  /**
   * @return true if some heavy operation is running in some thread
   */
  public boolean isRunning() {
    return !myHeavyProcesses.isEmpty();
  }

  /**
   * @return true if any heavy operation of type {@code type} is currently running in some thread
   */
  public boolean isRunning(@NotNull Type type) {
    return ContainerUtil.exists(myHeavyProcesses, op->op.getType() == type);
  }

  /**
   * @return heavy operation currently running, if any, in undefined order
   */
  public Operation getAnyRunningOperation() {
    Iterator<Operation> iterator = myHeavyProcesses.iterator();
    return iterator.hasNext() ? iterator.next() : null;
  }

  public interface HeavyProcessListener extends EventListener {
	@@ -108,17 +131,45 @@ default void processStarted() {
    void processFinished();
  }

  public interface Operation {
    @NotNull Type getType();
    @Nls @NotNull String getDisplayName();
  }

  public void addListener(@NotNull Disposable parentDisposable, @NotNull HeavyProcessListener listener) {
    myEventDispatcher.addListener(listener, parentDisposable);
  }

  /**
   * schedules {@code runnable} to be executed when all heavy operations are finished (i.e. when {@link #isRunning()} returned false)
   */
  public void queueExecuteOutOfHeavyProcess(@NotNull Runnable runnable) {
    if (isRunning()) {
      toExecuteOutOfHeavyActivity.add(runnable);
    }
    else {
      runnable.run();
    }
  }

  private static class Op implements Operation {
    private final Type myType;
    private final String myDisplayName;

    Op(@NotNull Type type, @NotNull @Nls String displayName) {
      myType = type;
      myDisplayName = displayName;
    }

    @Override
    public @NotNull Type getType() {
      return myType;
    }

    @Nls
    @Override
    public @NotNull String getDisplayName() {
      return myDisplayName;
    }
  }