<<>>plugins/kotlin/fir-low-level-api/test/org/jetbrains/kotlin/idea/fir/low/level/api/file/structure/AbstractFileStructureTest.java<<>>
<<>> 1 March 2021 <<>>

import com.intellij.openapi.application.runUndoTransparentWriteAction
import com.intellij.openapi.util.io.FileUtil
import com.intellij.psi.PsiComment
import com.intellij.psi.util.collectDescendantsOfType
import com.intellij.psi.util.forEachDescendantOfType
import org.jetbrains.kotlin.idea.fir.low.level.api.FirModuleResolveStateImpl
import org.jetbrains.kotlin.idea.fir.low.level.api.api.getResolveState
import org.jetbrains.kotlin.idea.test.KotlinLightCodeInsightFixtureTestCase
import org.jetbrains.kotlin.psi.*
import org.jetbrains.kotlin.test.KotlinTestUtils
import java.io.File

	@@ -40,23 +32,31 @@ abstract class AbstractFileStructureTest : KotlinLightCodeInsightFixtureTestCase
            ktFile.forEachDescendantOfType<KtDeclaration> { ktDeclaration ->
                val structureElement = declarationToStructureElement[ktDeclaration] ?: return@forEachDescendantOfType
                val comment = structureElement.createComment()
                when (ktDeclaration) {
                    is KtClassOrObject -> {
                        val lBrace = ktDeclaration.body?.lBrace
                        if (lBrace != null) {
                            ktDeclaration.body!!.addAfter(comment, lBrace)
                        } else {
                            ktDeclaration.parent.addAfter(comment, ktDeclaration)
                        }
                    }
                    is KtFunction -> {
                        val lBrace = ktDeclaration.bodyBlockExpression?.lBrace
                        if (lBrace != null) {
                            ktDeclaration.bodyBlockExpression!!.addAfter(comment, lBrace)
                        } else {
                            ktDeclaration.parent.addAfter(comment, ktDeclaration)
                        }
                    }
                    is KtProperty -> {
                        val initializerOrTypeReference = ktDeclaration.initializer ?:  ktDeclaration.typeReference
                        if (initializerOrTypeReference != null) {
                            ktDeclaration.addAfter(comment, initializerOrTypeReference)
                        } else {
                            ktDeclaration.parent.addAfter(comment, ktDeclaration)
                        }
                    }
                    else -> error("Unsupported declaration $ktDeclaration")
                }
            }