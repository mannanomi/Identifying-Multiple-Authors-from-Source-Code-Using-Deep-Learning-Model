<<>>plugins/kotlin/j2k/new/src/org/jetbrains/kotlin/nj2k/tree/elements.java <<>>

<<>> 10 Sep 2019 <<>>

/*
 * Copyright 2010-2019 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.nj2k.tree

import org.jetbrains.kotlin.nj2k.symbols.JKClassSymbol

import org.jetbrains.kotlin.nj2k.tree.visitors.JKVisitor
import org.jetbrains.kotlin.nj2k.types.JKType

class JKTreeRoot(element: JKTreeElement) : JKTreeElement() {
    var element by child(element)
    override fun accept(visitor: JKVisitor) = visitor.visitTreeRoot(this)
}

class JKFile(
    packageDeclaration: JKPackageDeclaration,
    importList: JKImportList,
    declarationList: List<JKDeclaration>
) : JKTreeElement(), PsiOwner by PsiOwnerImpl() {
    override fun accept(visitor: JKVisitor) = visitor.visitFile(this)

    var packageDeclaration: JKPackageDeclaration by child(packageDeclaration)
    var importList: JKImportList by child(importList)
    var declarationList by children(declarationList)
}

class JKTypeElement(var type: JKType) : JKTreeElement() {
    override fun accept(visitor: JKVisitor) = visitor.visitTypeElement(this)
}

abstract class JKBlock : JKTreeElement() {
    abstract var statements: List<JKStatement>

    val leftBrace = JKTokenElementImpl("{")
    val rightBrace = JKTokenElementImpl("}")
}


object JKBodyStub : JKBlock() {
    override val leftNonCodeElements: MutableList<JKNonCodeElement> = mutableListOf()
    override val rightNonCodeElements: MutableList<JKNonCodeElement> = mutableListOf()

    override fun copy(): JKTreeElement = this

    override var statements: List<JKStatement>
        get() = emptyList()
        set(_) {}

    override fun acceptChildren(visitor: JKVisitor) {}

    override var parent: JKElement?
        get() = null
        set(_) {}

    override fun detach(from: JKElement) {}
    override fun attach(to: JKElement) {}
    override fun accept(visitor: JKVisitor) = Unit
}


class JKInheritanceInfo(
    extends: List<JKTypeElement>,
    implements: List<JKTypeElement>
) : JKTreeElement() {
    var extends: List<JKTypeElement> by children(extends)
    var implements: List<JKTypeElement> by children(implements)

    override fun accept(visitor: JKVisitor) = visitor.visitInheritanceInfo(this)
}

class JKPackageDeclaration(name: JKNameIdentifier) : JKTreeElement() {
    var name: JKNameIdentifier by child(name)
    override fun accept(visitor: JKVisitor) = visitor.visitPackageDeclaration(this)
}

abstract class JKLabel : JKTreeElement()

class JKLabelEmpty : JKLabel() {
    override fun accept(visitor: JKVisitor) = visitor.visitLabelEmpty(this)
}

class JKLabelText(label: JKNameIdentifier) : JKLabel() {
    val label: JKNameIdentifier by child(label)
    override fun accept(visitor: JKVisitor) = visitor.visitLabelText(this)
}

class JKImportStatement(name: JKNameIdentifier) : JKTreeElement() {
    val name: JKNameIdentifier by child(name)
    override fun accept(visitor: JKVisitor) = visitor.visitImportStatement(this)
}

class JKImportList(imports: List<JKImportStatement>) : JKTreeElement() {
    var imports by children(imports)
    override fun accept(visitor: JKVisitor) = visitor.visitImportList(this)
}

abstract class JKAnnotationParameter : JKTreeElement() {
    abstract var value: JKAnnotationMemberValue
}

class JKAnnotationParameterImpl(value: JKAnnotationMemberValue) : JKAnnotationParameter() {
    override var value: JKAnnotationMemberValue by child(value)

    override fun accept(visitor: JKVisitor) = visitor.visitAnnotationParameter(this)
}

class JKAnnotationNameParameter(
    value: JKAnnotationMemberValue,
    name: JKNameIdentifier
) : JKAnnotationParameter() {
    override var value: JKAnnotationMemberValue by child(value)
    val name: JKNameIdentifier by child(name)
    override fun accept(visitor: JKVisitor) = visitor.visitAnnotationNameParameter(this)
}

abstract class JKArgument : JKTreeElement() {
    abstract var value: JKExpression
}

class JKNamedArgument(
    value: JKExpression,
    name: JKNameIdentifier
) : JKArgument() {
    override var value by child(value)
    val name by child(name)
    override fun accept(visitor: JKVisitor) = visitor.visitNamedArgument(this)
}

class JKArgumentImpl(value: JKExpression) : JKArgument() {
    override var value by child(value)
    override fun accept(visitor: JKVisitor) = visitor.visitArgument(this)
}

class JKArgumentList(arguments: List<JKArgument> = emptyList()) : JKTreeElement() {
    constructor(vararg arguments: JKArgument) : this(arguments.toList())
    constructor(vararg values: JKExpression) : this(values.map { JKArgumentImpl(it) })

    var arguments by children(arguments)
    override fun accept(visitor: JKVisitor) = visitor.visitArgumentList(this)
}


class JKTypeParameterList(typeParameters: List<JKTypeParameter> = emptyList()) : JKTreeElement() {
    var typeParameters by children(typeParameters)
    override fun accept(visitor: JKVisitor) = visitor.visitTypeParameterList(this)
}


class JKAnnotationList(annotations: List<JKAnnotation> = emptyList()) : JKTreeElement() {
    var annotations: List<JKAnnotation> by children(annotations)
    override fun accept(visitor: JKVisitor) = visitor.visitAnnotationList(this)
}

class JKAnnotation(
    var classSymbol: JKClassSymbol,
    arguments: List<JKAnnotationParameter> = emptyList()
) : JKAnnotationMemberValue() {
    var arguments: List<JKAnnotationParameter> by children(arguments)
    override fun accept(visitor: JKVisitor) = visitor.visitAnnotation(this)
}

class JKTypeArgumentList(typeArguments: List<JKTypeElement> = emptyList()) : JKTreeElement(), PsiOwner by PsiOwnerImpl() {
    var typeArguments: List<JKTypeElement> by children(typeArguments)
    override fun accept(visitor: JKVisitor) = visitor.visitTypeArgumentList(this)
}

class JKNameIdentifier(val value: String) : JKTreeElement() {
    override fun accept(visitor: JKVisitor) = visitor.visitNameIdentifier(this)
}


interface JKAnnotationListOwner : JKNonCodeElementsListOwner {
    var annotationList: JKAnnotationList
}


class JKBlockImpl(statements: List<JKStatement> = emptyList()) : JKBlock() {
    constructor(vararg statements: JKStatement) : this(statements.toList())

    override var statements by children(statements)
    override fun accept(visitor: JKVisitor) = visitor.visitBlock(this)
}

class JKKtWhenCase(labels: List<JKKtWhenLabel>, statement: JKStatement) : JKTreeElement() {
    var labels: List<JKKtWhenLabel> by children(labels)
    var statement: JKStatement by child(statement)
    override fun accept(visitor: JKVisitor) = visitor.visitKtWhenCase(this)
}

abstract class JKKtWhenLabel : JKTreeElement()

class JKKtElseWhenLabel : JKKtWhenLabel() {
    override fun accept(visitor: JKVisitor) = visitor.visitKtElseWhenLabel(this)
}

class JKKtValueWhenLabel(expression: JKExpression) : JKKtWhenLabel() {
    var expression: JKExpression by child(expression)
    override fun accept(visitor: JKVisitor) = visitor.visitKtValueWhenLabel(this)
}


class JKClassBody(declarations: List<JKDeclaration> = emptyList()) : JKTreeElement() {
    var declarations: List<JKDeclaration> by children(declarations)
    override fun accept(visitor: JKVisitor) = visitor.visitClassBody(this)

    val leftBrace = JKTokenElementImpl("{")
    val rightBrace = JKTokenElementImpl("}")
}


class JKJavaTryCatchSection(
    parameter: JKParameter,
    block: JKBlock
) : JKStatement() {
    var parameter: JKParameter by child(parameter)
    var block: JKBlock by child(block)
    override fun accept(visitor: JKVisitor) = visitor.visitJavaTryCatchSection(this)
}

abstract class JKJavaSwitchCase : JKTreeElement() {
    abstract fun isDefault(): Boolean
    abstract var statements: List<JKStatement>
}

class JKJavaDefaultSwitchCase(statements: List<JKStatement>) : JKJavaSwitchCase(), PsiOwner by PsiOwnerImpl() {
    override var statements: List<JKStatement> by children(statements)
    override fun isDefault(): Boolean = true
    override fun accept(visitor: JKVisitor) = visitor.visitJavaDefaultSwitchCase(this)
}

class JKJavaLabelSwitchCase(
    label: JKExpression,
    statements: List<JKStatement>
) : JKJavaSwitchCase(), PsiOwner by PsiOwnerImpl() {
    override var statements: List<JKStatement> by children(statements)
    var label: JKExpression by child(label)
    override fun isDefault(): Boolean = false
    override fun accept(visitor: JKVisitor) = visitor.visitJavaLabelSwitchCase(this)
}

class JKKtTryCatchSection(
    parameter: JKParameter,
    block: JKBlock
) : JKTreeElement() {
    var parameter: JKParameter by child(parameter)
    var block: JKBlock by child(block)
    override fun accept(visitor: JKVisitor) = visitor.visitKtTryCatchSection(this)
}




<<>> 10 Sep 2019<<>>

/*
 * Copyright 2010-2019 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.nj2k.tree

import org.jetbrains.kotlin.nj2k.symbols.*


import org.jetbrains.kotlin.nj2k.tree.visitors.JKVisitor
import org.jetbrains.kotlin.nj2k.types.JKContextType
import org.jetbrains.kotlin.nj2k.types.JKNoTypeImpl
import org.jetbrains.kotlin.nj2k.types.JKType

abstract class JKExpression : JKAnnotationMemberValue(), PsiOwner by PsiOwnerImpl()

abstract class JKOperatorExpression : JKExpression() {
    abstract var operator: JKOperator
}

class JKBinaryExpression(
    left: JKExpression,
    right: JKExpression,
    override var operator: JKOperator
) : JKOperatorExpression() {
    var right by child(right)
    var left by child(left)

    override fun accept(visitor: JKVisitor) = visitor.visitBinaryExpression(this)
}

abstract class JKUnaryExpression : JKOperatorExpression() {
    abstract var expression: JKExpression
}

class JKPrefixExpression(expression: JKExpression, override var operator: JKOperator) : JKUnaryExpression() {
    override var expression by child(expression)
    override fun accept(visitor: JKVisitor) = visitor.visitPrefixExpression(this)
}

class JKPostfixExpression(expression: JKExpression, override var operator: JKOperator) : JKUnaryExpression() {
    override var expression by child(expression)
    override fun accept(visitor: JKVisitor) = visitor.visitPostfixExpression(this)
}

class JKQualifiedExpression(
    receiver: JKExpression,
    selector: JKExpression
) : JKExpression() {
    var receiver: JKExpression by child(receiver)
    var selector: JKExpression by child(selector)

    override fun accept(visitor: JKVisitor) = visitor.visitQualifiedExpression(this)
}

class JKArrayAccessExpression(
    expression: JKExpression,
    indexExpression: JKExpression
) : JKExpression() {
    var expression: JKExpression by child(expression)
    var indexExpression: JKExpression by child(indexExpression)

    override fun accept(visitor: JKVisitor) = visitor.visitArrayAccessExpression(this)
}


class JKParenthesizedExpression(expression: JKExpression) : JKExpression() {
    var expression: JKExpression by child(expression)

    override fun accept(visitor: JKVisitor) = visitor.visitParenthesizedExpression(this)
}

class JKTypeCastExpression(expression: JKExpression, type: JKTypeElement) : JKExpression() {
    var expression by child(expression)
    var type by child(type)

    override fun accept(visitor: JKVisitor) = visitor.visitTypeCastExpression(this)
}

class JKLiteralExpression(
    var literal: String,
    val type: LiteralType
) : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitLiteralExpression(this)

    enum class LiteralType {
        STRING, CHAR, BOOLEAN, NULL, INT, LONG, FLOAT, DOUBLE
    }
}

class JKStubExpression : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitStubExpression(this)
}

class JKThisExpression(qualifierLabel: JKLabel) : JKExpression() {
    var qualifierLabel: JKLabel by child(qualifierLabel)

    override fun accept(visitor: JKVisitor) = visitor.visitThisExpression(this)
}

class JKSuperExpression(qualifierLabel: JKLabel = JKLabelEmpty()) : JKExpression() {
    var qualifierLabel: JKLabel by child(qualifierLabel)
    override fun accept(visitor: JKVisitor) = visitor.visitSuperExpression(this)
}

class JKIfElseExpression(condition: JKExpression, thenBranch: JKExpression, elseBranch: JKExpression) : JKExpression() {
    var condition by child(condition)
    var thenBranch by child(thenBranch)
    var elseBranch by child(elseBranch)

    override fun accept(visitor: JKVisitor) = visitor.visitIfElseExpression(this)
}

class JKLambdaExpression(
    statement: JKStatement,
    parameters: List<JKParameter>,
    functionalType: JKTypeElement = JKTypeElement(JKNoTypeImpl),
    returnType: JKTypeElement = JKTypeElement(JKContextType)
) : JKExpression() {
    var statement by child(statement)
    var parameters by children(parameters)
    var functionalType by child(functionalType)
    val returnType by child(returnType)

    override fun accept(visitor: JKVisitor) = visitor.visitLambdaExpression(this)
}


abstract class JKCallExpression : JKExpression(), JKTypeArgumentListOwner {
    abstract val identifier: JKMethodSymbol
    abstract var arguments: JKArgumentList
}

class JKDelegationConstructorCall(
    override val identifier: JKMethodSymbol,
    expression: JKExpression,
    arguments: JKArgumentList
) : JKCallExpression() {
    override var typeArgumentList: JKTypeArgumentList by child(JKTypeArgumentList())
    val expression: JKExpression by child(expression)
    override var arguments: JKArgumentList by child(arguments)

    override fun accept(visitor: JKVisitor) = visitor.visitDelegationConstructorCall(this)
}

class JKCallExpressionImpl(
    override val identifier: JKMethodSymbol,
    arguments: JKArgumentList,
    typeArgumentList: JKTypeArgumentList = JKTypeArgumentList()
) : JKCallExpression() {
    override var typeArgumentList by child(typeArgumentList)
    override var arguments by child(arguments)
    override fun accept(visitor: JKVisitor) = visitor.visitCallExpressionImpl(this)
}

class JKNewExpression(
    val classSymbol: JKClassSymbol,
    arguments: JKArgumentList,
    typeArgumentList: JKTypeArgumentList,
    classBody: JKClassBody = JKClassBody(),
    val isAnonymousClass: Boolean = false
) : JKExpression() {
    var typeArgumentList by child(typeArgumentList)
    var arguments by child(arguments)
    var classBody by child(classBody)
    override fun accept(visitor: JKVisitor) = visitor.visitNewExpression(this)
}


class JKFieldAccessExpression(var identifier: JKFieldSymbol) : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitFieldAccessExpression(this)
}

class JKPackageAccessExpression(var identifier: JKPackageSymbol) : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitPackageAccessExpression(this)
}


class JKClassAccessExpression(var identifier: JKClassSymbol) : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitClassAccessExpression(this)
}

class JKMethodReferenceExpression(
    qualifier: JKExpression,
    val identifier: JKSymbol,
    functionalType: JKTypeElement,
    val isConstructorCall: Boolean
) : JKExpression() {
    val qualifier by child(qualifier)
    val functionalType by child(functionalType)

    override fun accept(visitor: JKVisitor) = visitor.visitMethodReferenceExpression(this)
}


class JKLabeledExpression(statement: JKStatement, labels: List<JKNameIdentifier>) : JKExpression() {
    var statement: JKStatement by child(statement)
    val labels: List<JKNameIdentifier> by children(labels)
    override fun accept(visitor: JKVisitor) = visitor.visitLabeledExpression(this)
}

class JKClassLiteralExpression(
    classType: JKTypeElement,
    var literalType: ClassLiteralType
) : JKExpression() {
    val classType: JKTypeElement by child(classType)

    override fun accept(visitor: JKVisitor) = visitor.visitClassLiteralExpression(this)

    enum class ClassLiteralType {
        KOTLIN_CLASS,
        JAVA_CLASS,
        JAVA_PRIMITIVE_CLASS,
        JAVA_VOID_TYPE
    }
}


abstract class JKKtAssignmentChainLink : JKExpression() {
    abstract val receiver: JKExpression
    abstract val assignmentStatement: JKKtAssignmentStatement
    abstract val field: JKExpression
}

class JKAssignmentChainAlsoLink(
    receiver: JKExpression,
    assignmentStatement: JKKtAssignmentStatement,
    field: JKExpression
) : JKKtAssignmentChainLink() {
    override val receiver by child(receiver)
    override val assignmentStatement by child(assignmentStatement)
    override val field by child(field)

    override fun accept(visitor: JKVisitor) = visitor.visitAssignmentChainAlsoLink(this)
}

class JKAssignmentChainLetLink(
    receiver: JKExpression,
    assignmentStatement: JKKtAssignmentStatement,
    field: JKExpression
) : JKKtAssignmentChainLink() {
    override val receiver by child(receiver)
    override val assignmentStatement by child(assignmentStatement)
    override val field by child(field)

    override fun accept(visitor: JKVisitor) = visitor.visitAssignmentChainLetLink(this)
}


class JKIsExpression(expression: JKExpression, type: JKTypeElement) : JKExpression() {
    var type by child(type)
    var expression by child(expression)

    override fun accept(visitor: JKVisitor) = visitor.visitIsExpression(this)
}

class JKKtThrowExpression(exception: JKExpression) : JKExpression() {
    var exception: JKExpression by child(exception)
    override fun accept(visitor: JKVisitor) = visitor.visitKtThrowExpression(this)
}

class JKKtItExpression(val type: JKType) : JKExpression() {
    override fun accept(visitor: JKVisitor) = visitor.visitKtItExpression(this)
}

class JKKtAnnotationArrayInitializerExpression(initializers: List<JKAnnotationMemberValue>) : JKExpression() {
    constructor(vararg initializers: JKAnnotationMemberValue) : this(initializers.toList())

    val initializers: List<JKAnnotationMemberValue> by children(initializers)
    override fun accept(visitor: JKVisitor) = visitor.visitKtAnnotationArrayInitializerExpression(this)
}

class JKKtTryExpression(
    tryBlock: JKBlock,
    finallyBlock: JKBlock,
    catchSections: List<JKKtTryCatchSection>
) : JKExpression() {
    var tryBlock: JKBlock by child(tryBlock)
    var finallyBlock: JKBlock by child(finallyBlock)
    var catchSections: List<JKKtTryCatchSection> by children(catchSections)
    override fun accept(visitor: JKVisitor) = visitor.visitKtTryExpression(this)
}

class JKKtTryCatchSection(
    parameter: JKParameter,
    block: JKBlock
) : JKTreeElement() {
    var parameter: JKParameter by child(parameter)
    var block: JKBlock by child(block)
    override fun accept(visitor: JKVisitor) = visitor.visitKtTryCatchSection(this)
}

class JKJavaNewEmptyArray(initializer: List<JKExpression>, type: JKTypeElement) : JKExpression() {
    val type by child(type)
    var initializer by children(initializer)
    override fun accept(visitor: JKVisitor) = visitor.visitJavaNewEmptyArray(this)
}

class JKJavaNewArray(initializer: List<JKExpression>, type: JKTypeElement) : JKExpression() {
    val type by child(type)
    var initializer by children(initializer)
    override fun accept(visitor: JKVisitor) = visitor.visitJavaNewArray(this)
}


class JKJavaAssignmentExpression(
    field: JKExpression,
    expression: JKExpression,
    var operator: JKOperator
) : JKExpression() {
    var field by child(field)
    var expression by child(expression)
    override fun accept(visitor: JKVisitor) = visitor.visitJavaAssignmentExpression(this)
}