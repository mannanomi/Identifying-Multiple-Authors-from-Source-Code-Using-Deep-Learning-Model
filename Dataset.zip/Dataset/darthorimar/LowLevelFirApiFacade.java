<<>>plugins/kotlin/fir-low-level-api/src/org/jetbrains/kotlin/idea/fir/low/level/api/api/LowLevelFirApiFacade.java<<>>
<<>> 1 March 2021 <<>>

import org.jetbrains.kotlin.diagnostics.Diagnostic
import org.jetbrains.kotlin.fir.FirElement
import org.jetbrains.kotlin.fir.declarations.*
import org.jetbrains.kotlin.fir.render
import org.jetbrains.kotlin.fir.unwrapFakeOverrides
import org.jetbrains.kotlin.idea.caches.project.IdeaModuleInfo
import org.jetbrains.kotlin.idea.caches.project.getModuleInfo
import org.jetbrains.kotlin.idea.fir.low.level.api.FirIdeResolveStateService
import org.jetbrains.kotlin.idea.fir.low.level.api.annotations.InternalForInline
import org.jetbrains.kotlin.idea.fir.low.level.api.sessions.FirIdeSourcesSession
import org.jetbrains.kotlin.idea.fir.low.level.api.util.ktDeclaration
import org.jetbrains.kotlin.idea.util.getElementTextInContext
import org.jetbrains.kotlin.psi.KtDeclaration
import org.jetbrains.kotlin.psi.KtElement
import org.jetbrains.kotlin.psi.KtFile
	@@ -88,6 +91,31 @@ inline fun <reified F : FirDeclaration, R> KtLambdaExpression.withFirDeclaration
    return action(firDeclaration)
}


 * Executes [action] with given [FirDeclaration]
 * [FirDeclaration] passed to [action] will be resolved at least to [phase] when executing [action] on it
 
fun <D : FirDeclaration, R> D.withFirDeclaration(
    resolveState: FirModuleResolveState,
    phase: FirResolvePhase = FirResolvePhase.RAW_FIR,
    action: (D) -> R,
): R {
    resolvedFirToPhase(phase, resolveState)
    val originalDeclaration = (this as? FirCallableDeclaration<*>)?.unwrapFakeOverrides() ?: this
    val session = originalDeclaration.session
    return when {
        originalDeclaration.origin == FirDeclarationOrigin.Source
                && session is FirIdeSourcesSession
        -> {
            val cache = session.cache
            val file = resolveState.getFirFile(this, cache)
                ?: error("Fir file was not found for\n${render()}\n${ktDeclaration.getElementTextInContext()}")
            cache.firFileLockProvider.withReadLock(file) { action(this) }
        }
        else -> action(this)
    }
}


 * Returns a list of Diagnostics compiler finds for given [KtElement]
 */
 
     
     
 <<>> 1 March 2021 <<>>
 
     fun KtElement.getResolveState(): FirModuleResolveState =
    getModuleInfo().getResolveState()

fun IdeaModuleInfo.getResolveState(): FirModuleResolveState =
    FirIdeResolveStateService.getInstance(project!!).getResolveState(this)

fun KtFile.getFirFile(resolveState: FirModuleResolveState) =
    resolveState.getFirFile(this)

/**
 * Creates [FirDeclaration] by [KtDeclaration] and runs an [action] with it
 * [this@withFirDeclaration]
 * [FirDeclaration] passed to [action] should not be leaked outside [action] lambda
 * [FirDeclaration] passed to [action] will be resolved at least to [phase]
 * Otherwise, some threading problems may arise,
 *
 * [this@withFirDeclaration] should be non-local declaration (should have fully qualified name)
 */
@OptIn(InternalForInline::class)
inline fun <R> KtDeclaration.withFirDeclaration(
    resolveState: FirModuleResolveState,
    phase: FirResolvePhase = FirResolvePhase.RAW_FIR,
    action: (FirDeclaration) -> R
): R {
    val firDeclaration = resolveState.findSourceFirDeclaration(this)
    firDeclaration.resolvedFirToPhase(phase, resolveState)
    return action(firDeclaration)
}

@OptIn(InternalForInline::class)
inline fun <reified F : FirDeclaration, R> KtDeclaration.withFirDeclarationOfType(
    resolveState: FirModuleResolveState,
    action: (F) -> R
): R {
    val firDeclaration = resolveState.findSourceFirDeclaration(this)
    if (firDeclaration !is F) throw InvalidFirElementTypeException(this, F::class, firDeclaration::class)
    return action(firDeclaration)
}

@OptIn(InternalForInline::class)
inline fun <reified F : FirDeclaration, R> KtLambdaExpression.withFirDeclarationOfType(
    resolveState: FirModuleResolveState,
    action: (F) -> R
): R {
    val firDeclaration = resolveState.findSourceFirDeclaration(this)
    if (firDeclaration !is F) throw InvalidFirElementTypeException(this, F::class, firDeclaration::class)
    return action(firDeclaration)
}

fun getDiagnosticsFor(element: KtElement, resolveState: FirModuleResolveState): Collection<Diagnostic> =
    resolveState.getDiagnostics(element)

fun KtFile.collectDiagnosticsForFile(resolveState: FirModuleResolveState): Collection<Diagnostic> =
    resolveState.collectDiagnosticsForFile(this)

fun <D : FirDeclaration> D.resolvedFirToPhase(
    phase: FirResolvePhase,
    resolveState: FirModuleResolveState
): D =
    resolveState.resolvedFirToPhase(this, phase)


fun KtElement.getOrBuildFir(
    resolveState: FirModuleResolveState,
) = resolveState.getOrBuildFirFor(this)

inline fun <reified E : FirElement> KtElement.getOrBuildFirSafe(
    resolveState: FirModuleResolveState,
) = getOrBuildFir(resolveState) as? E

inline fun <reified E : FirElement> KtElement.getOrBuildFirOfType(
    resolveState: FirModuleResolveState,
): E {
    val fir = this.getOrBuildFir(resolveState)
    if (fir is E) return fir
    throw InvalidFirElementTypeException(this, E::class, fir::class)
}
     