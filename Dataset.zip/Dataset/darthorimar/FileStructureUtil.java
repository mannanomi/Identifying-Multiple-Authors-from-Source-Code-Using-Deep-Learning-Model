<<>>plugins/kotlin/fir-low-level-api/src/org/jetbrains/kotlin/idea/fir/low/level/api/file/structure/FileStructureUtil.java<<>>
<<>> 1 March 2021 <<>>

package org.jetbrains.kotlin.idea.fir.low.level.api.file.structure

import org.jetbrains.kotlin.fir.containingClass
import org.jetbrains.kotlin.fir.declarations.FirCallableDeclaration
import org.jetbrains.kotlin.fir.declarations.FirDeclaration
import org.jetbrains.kotlin.fir.declarations.FirFile
import org.jetbrains.kotlin.fir.declarations.FirRegularClass
import org.jetbrains.kotlin.fir.resolve.toSymbol
import org.jetbrains.kotlin.idea.fir.low.level.api.file.builder.ModuleFileCache
import org.jetbrains.kotlin.idea.fir.low.level.api.util.replaceFirst
import org.jetbrains.kotlin.psi.*
import org.jetbrains.kotlin.psi.psiUtil.containingClassOrObject

	@@ -15,4 +23,32 @@ internal object FileStructureUtil {
        ktDeclaration.containingClassOrObject is KtEnumEntry -> false
        else -> !KtPsiUtil.isLocal(ktDeclaration)
    }

    fun replaceDeclaration(firFile: FirFile, from: FirCallableDeclaration<*>, to: FirCallableDeclaration<*>) {
        val declarations = if (from.symbol.callableId.className == null) {
            firFile.declarations as MutableList<FirDeclaration>
        } else {
            val classLikeLookupTag = from.containingClass()
                ?: error("Class name should not be null for non-top-level & non-local declarations")
            val containingClass = classLikeLookupTag.toSymbol(firFile.session)?.fir as FirRegularClass
            containingClass.declarations as MutableList<FirDeclaration>
        }
        declarations.replaceFirst(from, to)
    }

    inline fun <R> withDeclarationReplaced(
        firFile: FirFile,
        cache: ModuleFileCache,
        from: FirCallableDeclaration<*>,
        to: FirCallableDeclaration<*>,
        action: () -> R,
    ): R {
        cache.firFileLockProvider.withWriteLock(firFile) { replaceDeclaration(firFile, from, to) }
        return try {
            action()
        } catch (e: Throwable) {
            cache.firFileLockProvider.withWriteLock(firFile) { replaceDeclaration(firFile, to, from) }
            throw e
        }
    }
}