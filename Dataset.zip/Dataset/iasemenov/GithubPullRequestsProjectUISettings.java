<<>>plugins/github/src/org/jetbrains/plugins/github/pullrequest/config/GithubPullRequestsProjectUISettings.java<<>>
<<>> 15 jan 2021 <<>>
import com.intellij.openapi.components.*
import com.intellij.openapi.project.Project
import org.jetbrains.plugins.github.authentication.accounts.GHAccountSerializer
import org.jetbrains.plugins.github.authentication.accounts.GithubAccount
import org.jetbrains.plugins.github.util.GHGitRepositoryMapping
import org.jetbrains.plugins.github.util.GHProjectRepositoriesManager

@Service
@State(name = "GithubPullRequestsUISettings", storages = [Storage(StoragePathMacros.WORKSPACE_FILE)], reportStatistic = false)
class GithubPullRequestsProjectUISettings(private val project: Project)
  : PersistentStateComponentWithModificationTracker<GithubPullRequestsProjectUISettings.SettingsState> {

  private var state: SettingsState = SettingsState()

  class SettingsState : BaseState() {
    var selectedUrlAndAccountId by property<UrlAndAccount?>(null) { it == null }
    var recentSearchFilters by list<String>()
  }

  @Deprecated("Deprecated when moving to single-tab pull requests")
  fun getHiddenUrls(): Set<String> = emptySet()

  var selectedRepoAndAccount: Pair<GHGitRepositoryMapping, GithubAccount>?
    get() {
      val (url, accountId) = state.selectedUrlAndAccountId ?: return null
      val repo = project.service<GHProjectRepositoriesManager>().knownRepositories.find {
        it.gitRemote.url == url
      } ?: return null
      val account = GHAccountSerializer.deserialize(accountId) ?: return null
      return repo to account
    }
    set(value) {
      state.selectedUrlAndAccountId = value?.let { (repo, account) ->
        UrlAndAccount(repo.gitRemote.url, GHAccountSerializer.serialize(account))
      }
    }

  fun getRecentSearchFilters(): List<String> = state.recentSearchFilters.toList()

  fun addRecentSearchFilter(searchFilter: String) {
	@@ -41,5 +64,19 @@ class GithubPullRequestsProjectUISettings : PersistentStateComponentWithModifica
    fun getInstance(project: Project) = project.service<GithubPullRequestsProjectUISettings>()

    private const val RECENT_SEARCH_FILTERS_LIMIT = 10

    class UrlAndAccount private constructor() {

      var url: String = ""
      var accountId: String = ""

      constructor(url: String, accountId: String) : this() {
        this.url = url
        this.accountId = accountId
      }

      operator fun component1() = url
      operator fun component2() = accountId
    }
  }
}