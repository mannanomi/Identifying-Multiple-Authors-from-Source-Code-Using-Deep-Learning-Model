<<>>java/java-tests/testSrc/com/intellij/roots/RootsChangedTest.java<<>>

<<>> 18 Oct 2018 <<>>


import com.intellij.openapi.application.ex.PathManagerEx;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdkTable;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
	@@ -41,7 +42,7 @@ protected void setUp() throws Exception {

    getOrCreateProjectBaseDir();
    MessageBusConnection connection = myProject.getMessageBus().connect(getTestRootDisposable());
    myModuleRootListener = new MyModuleRootListener(myProject);
    connection.subscribe(ProjectTopics.PROJECT_ROOTS, myModuleRootListener);
  }

	@@ -83,7 +84,7 @@ public void testEventsAfterFileModifications() {

    // when the existing root is renamed, it remains a root
    rename(vDir2, "dir2");
    assertNoEvents();
    assertSameElements(ModuleRootManager.getInstance(moduleA).getContentRoots(), vDir2);

    // and event if it is moved, it's still a root
	@@ -131,7 +132,7 @@ public void testEditLibraryForModuleLoadFromXml() throws IOException {
        throw new RuntimeException(e);
      }
      ProjectJdkTable.getInstance().addJdk(jdk, getTestRootDisposable());
      assertNoEvents();

      ModuleRootModificationUtil.setModuleSdk(a, jdk);
      assertEventsCount(1);
	@@ -159,7 +160,7 @@ public void testModuleJdkEditing() throws Exception {
        throw new RuntimeException(e);
      }
      ProjectJdkTable.getInstance().addJdk(jdk, getTestRootDisposable());
      assertNoEvents();

      final ModifiableRootModel rootModelA = ModuleRootManager.getInstance(moduleA).getModifiableModel();
      final ModifiableRootModel rootModelB = ModuleRootManager.getInstance(moduleB).getModifiableModel();
	@@ -188,18 +189,18 @@ public void testInheritedJdkEditing() throws Exception {
      try {
        jdk = (Sdk)IdeaTestUtil.getMockJdk17("AAA").clone();
        ProjectJdkTable.getInstance().addJdk(jdk, getTestRootDisposable());
        assertNoEvents();

        jdkBBB = (Sdk)IdeaTestUtil.getMockJdk17("BBB").clone();
      }
      catch (CloneNotSupportedException e) {
        throw new RuntimeException(e);
      }
      ProjectJdkTable.getInstance().addJdk(jdk, getTestRootDisposable());
      assertNoEvents();

      ProjectRootManager.getInstance(myProject).setProjectSdk(jdkBBB);
      assertNoEvents(true);

      final ModifiableRootModel rootModelA = ModuleRootManager.getInstance(moduleA).getModifiableModel();
      final ModifiableRootModel rootModelB = ModuleRootManager.getInstance(moduleB).getModifiableModel();
	@@ -229,7 +230,7 @@ private void verifyLibraryTableEditing(final LibraryTable libraryTable) {
      final Library.ModifiableModel libraryModifiableModel = libraryA.getModifiableModel();
      libraryModifiableModel.addRoot("file:///a", OrderRootType.CLASSES);
      libraryModifiableModel.commit();
      assertNoEvents();

      final ModifiableRootModel rootModelA = ModuleRootManager.getInstance(moduleA).getModifiableModel();
      final ModifiableRootModel rootModelB = ModuleRootManager.getInstance(moduleB).getModifiableModel();
	@@ -283,7 +284,7 @@ private void verifyLibraryTableEditingInUncommittedModel(final LibraryTable libr
      final Library.ModifiableModel libraryModifiableModel = libraryA.getModifiableModel();
      libraryModifiableModel.addRoot("file:///a", OrderRootType.CLASSES);
      libraryModifiableModel.commit();
      assertNoEvents();

      final ModifiableRootModel rootModelA = ModuleRootManager.getInstance(moduleA).getModifiableModel();
      final ModifiableRootModel rootModelB = ModuleRootManager.getInstance(moduleB).getModifiableModel();
	@@ -292,17 +293,17 @@ private void verifyLibraryTableEditingInUncommittedModel(final LibraryTable libr
      final Library.ModifiableModel libraryModifiableModel2 = libraryA.getModifiableModel();
      libraryModifiableModel2.addRoot("file:///b", OrderRootType.CLASSES);
      libraryModifiableModel2.commit();
      assertNoEvents();

      libraryTable.removeLibrary(libraryA);
      assertNoEvents(true);

      rootModelA.addInvalidLibrary("Q", libraryTable.getTableLevel());
      rootModelB.addInvalidLibrary("Q", libraryTable.getTableLevel());
      assertNoEvents();

      final Library libraryQ = libraryTable.createLibrary("Q");
      assertNoEvents(true);

      ModifiableRootModel[] rootModels = {rootModelA, rootModelB};
      ModifiableModelCommitter.multiCommit(rootModels, ModuleManager.getInstance(rootModels[0].getProject()).getModifiableModel());
	@@ -313,17 +314,42 @@ private void verifyLibraryTableEditingInUncommittedModel(final LibraryTable libr
    });
  }

  private void assertNoEvents() {
    assertNoEvents(false);
  }

  private void assertNoEvents(boolean modificationCountMustBeIncremented) {
    assertEventsCountAndIncrementModificationCount(0, modificationCountMustBeIncremented);
  }

  private void assertEventsCount(int count) {
    assertEventsCountAndIncrementModificationCount(count, count != 0);
  }

  private void assertEventsCountAndIncrementModificationCount(int eventsCount, boolean modificationCountMustBeIncremented) {
    final int beforeCount = myModuleRootListener.beforeCount;
    final int afterCount = myModuleRootListener.afterCount;
    assertEquals("beforeCount = " + beforeCount + ", afterCount = " + afterCount, beforeCount, afterCount);
    assertEquals(eventsCount, beforeCount);
    long currentModificationCount = ProjectRootManager.getInstance(myProject).getModificationCount();
    if (modificationCountMustBeIncremented) {
      assertTrue(currentModificationCount > myModuleRootListener.modificationCount);
    }
    else {
      assertEquals(myModuleRootListener.modificationCount, currentModificationCount);
    }
    myModuleRootListener.reset();
  }

  private static class MyModuleRootListener implements ModuleRootListener {
    private final Project myProject;
    private int beforeCount;
    private int afterCount;
    private long modificationCount;

    public MyModuleRootListener(Project project) {
      myProject = project;
    }

    @Override
    public void beforeRootsChange(@NotNull ModuleRootEvent event) {
	@@ -338,6 +364,7 @@ public void rootsChanged(@NotNull ModuleRootEvent event) {
    private void reset() {
      beforeCount = 0;
      afterCount = 0;
      modificationCount = ProjectRootManager.getInstance(myProject).getModificationCount();
    }
  }