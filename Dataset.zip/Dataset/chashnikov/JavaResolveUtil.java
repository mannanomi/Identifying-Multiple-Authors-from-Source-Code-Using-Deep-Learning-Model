<<>>java/java-psi-impl/src/com/intellij/psi/impl/source/resolve/JavaResolveUtil.java<<>>
<<>> 9 Oct 2018 <<>>

 contextClass = PsiTreeUtil.getContextOfType(place, PsiClass.class, false);
        if (isInClassAnnotationParameterList(place, contextClass)) return false;
      }
      return canAccessProtectedMember(member, memberClass, accessObjectClass, contextClass,
                                      modifierList.hasModifierProperty(PsiModifier.STATIC));
    }

    if (effectiveAccessLevel == PsiUtil.ACCESS_LEVEL_PRIVATE) {
	@@ -183,6 +172,22 @@ else if (ignoreReferencedElementAccessibility(placeFile)) {
    return true;
  }

  public static boolean canAccessProtectedMember(@NotNull PsiMember member,
                                                  @NotNull PsiClass memberClass,
                                                  @Nullable PsiClass accessObjectClass, @Nullable PsiClass contextClass, boolean isStatic) {
    while (contextClass != null) {
      if (InheritanceUtil.isInheritorOrSelf(contextClass, memberClass, true)) {
        if (member instanceof PsiClass || isStatic || accessObjectClass == null
            || InheritanceUtil.isInheritorOrSelf(accessObjectClass, contextClass, true)) {
          return true;
        }
      }

      contextClass = getContextClass(contextClass);
    }
    return false;
  }

  private static boolean isInClassAnnotationParameterList(@NotNull PsiElement place, @Nullable PsiClass contextClass) {
    if (contextClass != null) {
      PsiAnnotation annotation = PsiTreeUtil.getContextOfType(place, PsiAnnotation.class, true);