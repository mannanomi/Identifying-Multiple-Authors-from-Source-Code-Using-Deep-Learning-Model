<<>>java/java-impl/src/com/intellij/slicer/SliceNullnessAnalyzerBase.java<<>>
<<>> 11 Oct 2018 <<>>

import java.util.*;

import static com.intellij.util.containers.ContainerUtil.addIfNotNull;

public abstract class SliceNullnessAnalyzerBase {
  @NotNull
  private final SliceLeafEquality myLeafEquality;
	@@ -50,39 +52,38 @@ public SliceNullnessAnalyzerBase(@NotNull SliceLeafEquality leafEquality,
  private void groupByNullness(NullAnalysisResult result, SliceRootNode oldRoot, final Map<SliceNode, NullAnalysisResult> map) {
    SliceRootNode root = createNewTree(result, oldRoot, map);

    SliceUsage rootUsage = oldRoot.getCachedChildren().get(0).getValue();
    SliceManager.getInstance(root.getProject()).createToolWindow(true, root, true, SliceManager.getElementDescription(null, rootUsage.getElement(), " Grouped by Nullness") );
  }

  @NotNull
  public SliceRootNode createNewTree(NullAnalysisResult result, SliceRootNode oldRoot, final Map<SliceNode, NullAnalysisResult> map) {
    SliceRootNode root = oldRoot.copy();
    assert oldRoot.getCachedChildren().size() == 1;
    SliceNode oldRootStart = oldRoot.getCachedChildren().get(0);
    root.setChanged();
    root.targetEqualUsages.clear();

    List<SliceLeafValueClassNode> children = new ArrayList<>();
    addIfNotNull(children, createValueRootNode(result, oldRoot, map, root, oldRootStart, "Null Values", NullAnalysisResult.NULLS));
    addIfNotNull(children, createValueRootNode(result, oldRoot, map, root, oldRootStart, "NotNull Values", NullAnalysisResult.NOT_NULLS));
    addIfNotNull(children, createValueRootNode(result, oldRoot, map, root, oldRootStart, "Other Values", NullAnalysisResult.UNKNOWNS));
    root.setChildren(children);
    return root;
  }

  private SliceLeafValueClassNode createValueRootNode(NullAnalysisResult result,
                                                      SliceRootNode oldRoot,
                                                      final Map<SliceNode, NullAnalysisResult> map,
                                                      SliceRootNode root,
                                                      SliceNode oldRootStart,
                                                      String nodeName,
                                                      final int group) {
    Collection<PsiElement> groupedByValue = result.groupedByValue[group];
    if (groupedByValue.isEmpty()) {
      return null;
    }
    SliceLeafValueClassNode valueRoot = new SliceLeafValueClassNode(root.getProject(), root, nodeName);

    Set<PsiElement> uniqueValues = new THashSet<>(groupedByValue, myLeafEquality);
    for (final PsiElement expression : uniqueValues) {
	@@ -110,6 +111,7 @@ private void createValueRootNode(NullAnalysisResult result,
                                   Collections.singletonList(newRoot))
      );
    }
    return valueRoot;
  }

  public void startAnalyzeNullness(@NotNull AbstractTreeStructure treeStructure, @NotNull Runnable finish) {
