<<>>platform/workspaceModel/ide/tests/testSrc/com/intellij/workspaceModel/ide/StoreSnapshotsAnalyzer.java<<>>
<<>> 29 March 2021 <<>>

package com.intellij.workspaceModel.ide

import com.intellij.workspaceModel.storage.EntitySource
import com.intellij.workspaceModel.storage.bridgeEntities.ModuleEntity
import com.intellij.workspaceModel.storage.impl.EntityStorageSerializerImpl
import com.intellij.workspaceModel.storage.impl.SimpleEntityTypesResolver
import com.intellij.workspaceModel.storage.toBuilder
	@@ -16,18 +15,31 @@ import kotlin.system.exitProcess
 */
fun main(args: Array<String>) {
  if (args.size !in 1..2) {
    println("Usage: com.intellij.workspaceModel.ide.StoreSnapshotsAnalyzerKt <path to directory with storage files> [<entity source filter>]\n" +
            "or com.intellij.workspaceModel.ide.StoreSnapshotsAnalyzerKt <path to cache.data file>")
    exitProcess(1)
  }
  val file = File(args[0])
  if (!file.exists()) {
    throw IllegalArgumentException("$file doesn't exist")
  }

  if (file.isFile) {
    val serializer = EntityStorageSerializerImpl(SimpleEntityTypesResolver, VirtualFileUrlManagerImpl())
    val storage = file.inputStream().use {
      serializer.deserializeCache(it)
    }

    // Set a breakpoint and check
    println("Cache loaded: ${storage!!.entities(ModuleEntity::class.java).toList().size} modules")
    return
  }

  val leftFile = file.resolve("Left_Store")
  val rightFile = file.resolve("Right_Store")
  val rightDiffLogFile = file.resolve("Right_Diff_Log")
  val converterFile = file.resolve("ClassToIntConverter")
  val resFile = file.resolve("Res_Store")

  val serializer = EntityStorageSerializerImpl(SimpleEntityTypesResolver, VirtualFileUrlManagerImpl())