<<>>java/idea-ui/src/com/intellij/openapi/roots/ui/configuration/libraries/LibraryEditingUtil.java<<>>

<<>> 22 April 2021 <<>>
import com.intellij.openapi.roots.ui.configuration.projectRoot.ModuleStructureConfigurable;
import com.intellij.openapi.ui.popup.PopupStep;
import com.intellij.openapi.ui.popup.util.BaseListPopupStep;
import com.intellij.openapi.util.NlsContexts;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.util.ParameterizedRunnable;
	@@ -139,13 +140,14 @@ public static LibraryTablePresentation getLibraryTablePresentation(@NotNull Proj
    return table.getPresentation();
  }

  public static List<TypeForNewLibrary> getSuitableTypes(ClasspathPanel classpathPanel) {
    List<TypeForNewLibrary> suitableTypes = new ArrayList<>();
    suitableTypes.add(new TypeForNewLibrary(null, JavaUiBundle.message("create.default.library.type.action.name")));
    final Module module = classpathPanel.getRootModel().getModule();
    for (LibraryType libraryType : LibraryType.EP_NAME.getExtensions()) {
      String createActionName = libraryType.getCreateActionName();
      if (createActionName != null && libraryType.isSuitableModule(module, classpathPanel.getModuleConfigurationState().getFacetsProvider())) {
        suitableTypes.add(new TypeForNewLibrary(libraryType, createActionName));
      }
    }
    return suitableTypes;
	@@ -155,27 +157,23 @@ public static boolean hasSuitableTypes(ClasspathPanel panel) {
    return getSuitableTypes(panel).size() > 1;
  }

  public static BaseListPopupStep<TypeForNewLibrary> createChooseTypeStep(final ClasspathPanel classpathPanel,
                                                                    final ParameterizedRunnable<? super LibraryType> action) {
    return new BaseListPopupStep<>(JavaUiBundle.message("popup.title.select.library.type"), getSuitableTypes(classpathPanel)) {
      @NotNull
      @Override
      public String getTextFor(TypeForNewLibrary value) {
        return value.getCreateActionName();
      }

      @Override
      public Icon getIconFor(TypeForNewLibrary aValue) {
        return aValue.getIcon();
      }

      @Override
      public PopupStep onChosen(final TypeForNewLibrary selectedValue, boolean finalChoice) {
        return doFinalStep(() -> action.run(selectedValue.getType()));
      }
    };
  }
	@@ -200,4 +198,27 @@ public PopupStep onChosen(final LibraryType selectedValue, boolean finalChoice)
    }
    return modules;
  }

  public static class TypeForNewLibrary {
    private final LibraryType<?> myType;
    private final @NlsContexts.Label String myCreateActionName;

    private TypeForNewLibrary(@Nullable LibraryType<?> type, @NlsContexts.Label String createActionName) {
      myType = type;
      myCreateActionName = createActionName;
    }

    public String getCreateActionName() {
      return myCreateActionName;
    }

    public Icon getIcon() {
      Icon icon = myType.getIcon(null);
      return icon != null ? icon : PlatformIcons.LIBRARY_ICON;
    }

    public LibraryType<?> getType() {
      return myType;
    }
  }
}