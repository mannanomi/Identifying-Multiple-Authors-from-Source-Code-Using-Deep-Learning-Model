<<>>java/structuralsearch-java/src/com/intellij/structuralsearch/java/ui/JavaStructuralSearchTemplateBuilder.java<<>>
<<>> 20 April 2021<<>>

import com.intellij.codeInsight.template.TemplateBuilderFactory;
import com.intellij.codeInsight.template.impl.ConstantNode;
import com.intellij.openapi.fileTypes.LanguageFileType;
import com.intellij.openapi.util.IntRef;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.structuralsearch.MatchOptions;
import com.intellij.structuralsearch.impl.matcher.MatcherImplUtil;
import com.intellij.structuralsearch.impl.matcher.PatternTreeContext;
import com.intellij.structuralsearch.plugin.ui.StructuralSearchTemplateBuilder;
import com.intellij.util.ArrayUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class JavaStructuralSearchTemplateBuilder extends StructuralSearchTemplateBuilder {
  @Override
  public TemplateBuilder buildTemplate(@NotNull PsiFile psiFile) {
    TemplateBuilder builder = TemplateBuilderFactory.getInstance().createTemplateBuilder(psiFile);
    PlaceholderCount classCount = new PlaceholderCount("Class");
    PlaceholderCount varCount = new PlaceholderCount("Var");
    PlaceholderCount funCount = new PlaceholderCount("Fun");

    IntRef shift = new IntRef();
    JavaRecursiveElementVisitor visitor = new JavaRecursiveElementVisitor() {

      @Override
      public void visitIdentifier(PsiIdentifier identifier) {
        PsiElement parent = identifier.getParent();
        if (parent instanceof PsiClass) {
          replaceElement(identifier, classCount, true, builder, shift.get());
        }
        else if (parent instanceof PsiReferenceExpression) {
          if (parent.getParent() instanceof PsiMethodCallExpression)
            replaceElement(identifier, funCount, true, builder, shift.get());
          else
            replaceElement(identifier, varCount, false, builder, shift.get());
        }
        else if (parent instanceof PsiJavaCodeReferenceElement) {
          replaceElement(identifier, classCount, false, builder, shift.get());
        }
      }

      @Override
      public void visitReferenceList(PsiReferenceList list) {
        PsiJavaCodeReferenceElement[] elements = list.getReferenceElements();
        for (PsiJavaCodeReferenceElement element : elements) {
          replaceElement(element.getReferenceNameElement(), classCount, false, builder, shift.get());
        }
      }
    };

    MatchOptions matchOptions = new MatchOptions();
    String text = psiFile.getText();
    int textOffset = 0;
    while (textOffset < text.length() && StringUtil.isWhiteSpace(text.charAt(textOffset))) {
      textOffset++;
    }
    shift.set(shift.get() - textOffset);
    matchOptions.setSearchPattern(text);
    PsiElement[] elements =
      MatcherImplUtil.createTreeFromText(text, PatternTreeContext.Block, (LanguageFileType)psiFile.getFileType(), psiFile.getProject());
    if (elements.length > 0) {
      PsiElement element = elements[0];
      shift.set(shift.get() + element.getTextRange().getStartOffset());
      element.accept(visitor);
    }
    return builder;
  }

  void replaceElement(@Nullable PsiElement element, PlaceholderCount count, boolean preferOriginal, TemplateBuilder builder, int shift) {
    if (element == null) {
      return;
    }
    String placeholder = count.getPlaceholder();
    String originalText = element.getText();
    LookupElement[] elements = {LookupElementBuilder.create(placeholder), LookupElementBuilder.create(originalText)};
    builder.replaceRange(element.getTextRange().shiftLeft(shift),
                         new ConstantNode(preferOriginal ? originalText : placeholder)
                           .withLookupItems(preferOriginal ? ArrayUtil.reverseArray(elements) : elements));
      
      
      
<<>> 20 April 2021 <<>>
    package com.intellij.structuralsearch.plugin.ui;

import com.intellij.codeInsight.template.TemplateBuilder;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * This is a temporary solution to extract Java-specific implementation from platform code. In order to implement creation of SSR templates
 * from code properly, we probably need to implement language-specific extensions.
 */
public abstract class StructuralSearchTemplateBuilder {
  public static StructuralSearchTemplateBuilder getInstance() {
    return ApplicationManager.getApplication().getService(StructuralSearchTemplateBuilder.class);
  }

  public @Nullable TemplateBuilder buildTemplate(@NotNull PsiFile psiFile) {
    return null;
  }
}
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
  }

  private static final class PlaceholderCount {