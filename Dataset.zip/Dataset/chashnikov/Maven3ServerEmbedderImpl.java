<<>>plugins/maven/maven3-server-impl/src/org/jetbrains/idea/maven/server/Maven3ServerEmbedderImpl.java<<>>

<<>> 13 Aug 2018 <<>>

import org.apache.maven.plugin.PluginDescriptorCache;
import org.apache.maven.plugin.internal.PluginDependenciesResolver;
import org.apache.maven.profiles.activation.*;
import org.apache.maven.project.ProjectDependenciesResolver;
import org.apache.maven.project.*;
import org.apache.maven.project.inheritance.DefaultModelInheritanceAssembler;
import org.apache.maven.project.interpolation.AbstractStringBasedModelInterpolator;
import org.apache.maven.project.interpolation.ModelInterpolationException;
	@@ -92,8 +92,8 @@
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.maven.model.*;
import org.jetbrains.idea.maven.server.embedder.MavenExecutionResult;
import org.jetbrains.idea.maven.server.embedder.*;

import java.io.File;
import java.lang.reflect.Constructor;
	@@ -911,8 +911,7 @@ public MavenExecutionRequest createRequest(@Nullable File file,

      result.setStartTime(myBuildStartTime);

      final Method setMultiModuleProjectDirectoryMethod = getSetMultiModuleProjectDirectoryMethod(result);
      if (setMultiModuleProjectDirectoryMethod != null) {
        try {
          File mavenMultiModuleProjectDirectory;
	@@ -937,6 +936,20 @@ public MavenExecutionRequest createRequest(@Nullable File file,
    }
  }

  private static Method getSetMultiModuleProjectDirectoryMethod(MavenExecutionRequest result) {
    try {
      Method method = result.getClass().getDeclaredMethod("setMultiModuleProjectDirectory", File.class);
      method.setAccessible(true);
      return method;
    }
    catch (NoSuchMethodException e) {
      return null;
    }
    catch (SecurityException e) {
      return null;
    }
  }

  @NotNull
  public File getLocalRepositoryFile() {
    return new File(myLocalRepository.getBasedir());
	@@ -1152,7 +1165,7 @@ public MavenModel readModel(File file) throws RemoteException {
      try {
        Object polyglotManager = myContainer.lookup("org.sonatype.maven.polyglot.PolyglotModelManager");
        if (polyglotManager != null) {
          Method getReaderFor = polyglotManager.getClass().getMethod("getReaderFor", Map.class);
          if (getReaderFor != null) {
            reader = (ModelReader)getReaderFor.invoke(polyglotManager, inputOptions);
          }