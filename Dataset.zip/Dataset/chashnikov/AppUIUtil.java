<<>>platform/platform-impl/src/com/intellij/ui/AppUIUtil.java<<>>
<<>> 1 Oct 2018 <<>>

List<Image> images = ContainerUtil.newArrayListWithCapacity(3);

    if (SystemInfo.isUnix) {
      Image svgIcon = loadApplicationIcon(window, 128, appInfo.getBigIconUrl());
      if (svgIcon != null) {
        images.add(svgIcon);
      }
    }

	@@ -116,6 +107,29 @@ else if (DEBUG_MODE && !ourMacDocIconSet) {
    }
  }

  @Nullable
  private static Image loadApplicationIcon(@NotNull Window window, int size, @Nullable String fallbackImageResourcePath) {
    String svgIconUrl = ApplicationInfoImpl.getShadowInstance().getApplicationSvgIconUrl();
    if (svgIconUrl != null) {
      URL url = AppUIUtil.class.getResource(svgIconUrl);
      try {
        return
          SVGLoader.load(url, AppUIUtil.class.getResourceAsStream(svgIconUrl), JBUI.pixScale(window) * size, JBUI.pixScale(window) * size);
      }
      catch (IOException e) {
        LOG.info("Cannot load svg application icon from " + svgIconUrl, e);
      }
    }
    else if (fallbackImageResourcePath != null) {
      Image image = ImageLoader.loadFromResource(fallbackImageResourcePath);
      if (image instanceof JBHiDPIScaledImage) {
        return ((JBHiDPIScaledImage)image).getDelegate();
      }
      return image;
    }
    return null;
  }

  public static void invokeLaterIfProjectAlive(@NotNull Project project, @NotNull Runnable runnable) {
    Application application = ApplicationManager.getApplication();
    if (application.isDispatchThread()) {