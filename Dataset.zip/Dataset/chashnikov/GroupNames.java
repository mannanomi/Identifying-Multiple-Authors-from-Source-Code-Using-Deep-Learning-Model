<<>>platform/analysis-api/src/com/intellij/codeInsight/daemon/GroupNames.java<<>>

<<>> 12 feb 2021 <<>>




 */
package com.intellij.codeInsight.daemon;

import org.jetbrains.annotations.ApiStatus;

/**
 * @deprecated specify groupBundle="messages.InspectionsBundle" and corresponding groupKey attribute in localInspection tag instead of
 * using constant from this class
 */
@Deprecated
public interface GroupNames {
  /** @deprecated use groupKey="group.names.probable.bugs" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String BUGS_GROUP_NAME = "Probable bugs";
  /** @deprecated use groupKey="group.names.compiler.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String COMPILER_ISSUES = "Compiler issues";
  /** @deprecated use groupKey="group.names.potentially.confusing.code.constructs" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String CONFUSING_GROUP_NAME = "Potentially confusing code constructs";
  /** @deprecated use groupKey="group.names.encapsulation.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String ENCAPSULATION_GROUP_NAME = "Encapsulation";
  /** @deprecated use groupKey="group.names.imports" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String IMPORTS_GROUP_NAME = "Imports";
  /** @deprecated use groupKey="group.names.initialization.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String INITIALIZATION_GROUP_NAME = "Initialization";
  /** @deprecated use groupKey="group.names.internationalization.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String INTERNATIONALIZATION_GROUP_NAME = "Internationalization";
    /** @deprecated use groupKey="group.names.logging.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String LOGGING_GROUP_NAME = "Logging";
    /** @deprecated use groupKey="group.names.code.maturity.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String MATURITY_GROUP_NAME = "Code maturity";
    /** @deprecated use groupKey="group.names.naming.conventions" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String NAMING_CONVENTIONS_GROUP_NAME = "Naming conventions";
    /** @deprecated use groupKey="group.names.performance.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String PERFORMANCE_GROUP_NAME = "Performance";
  /** @deprecated use groupKey="group.names.code.style.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String STYLE_GROUP_NAME = "Code style issues";
  /** @deprecated use groupKey="group.names.visibility.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String VISIBILITY_GROUP_NAME = "Visibility";
  /** @deprecated use groupKey="group.names.j2me.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String J2ME_GROUP_NAME = "Embedded";
  /** @deprecated use groupKey="group.names.inheritance.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String INHERITANCE_GROUP_NAME = "Inheritance issues";
  /** @deprecated use groupKey="group.names.declaration.redundancy" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String DECLARATION_REDUNDANCY = "Declaration redundancy";
  /** @deprecated use groupKey="group.names.dependency.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String DEPENDENCY_GROUP_NAME = "Dependency issues";
  /** @deprecated use groupKey="group.names.modularization.issues" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String MODULARIZATION_GROUP_NAME = "Modularization issues";
  /** @deprecated use groupKey="group.names.properties.files" instead */
  @Deprecated @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  String PROPERTIES_GROUP_NAME = "Properties files";
}