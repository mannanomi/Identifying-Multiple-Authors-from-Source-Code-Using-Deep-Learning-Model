<<>>java/compiler/impl/src/com/intellij/packaging/impl/artifacts/ArtifactManagerImpl.java<<>>
<<>> 20 March 2021 <<>>


private ArtifactType myArtifactType;
  private Map<ArtifactPropertiesProvider, ArtifactProperties<?>> myProperties;
  private final ProjectModelExternalSource myExternalSource;
  private final boolean myKeepExternalSystemAttribute;

  public ArtifactImpl(@NotNull @NlsSafe String name,
                      @NotNull ArtifactType artifactType, boolean buildOnMake,
                      @NotNull CompositePackagingElement<?> rootElement, String outputPath,
                      @Nullable ProjectModelExternalSource externalSource) {
    this(name, artifactType, buildOnMake, rootElement, outputPath, externalSource, null, externalSource != null);
  }

  public ArtifactImpl(@NotNull @NlsSafe String name,
                      @NotNull ArtifactType artifactType, boolean buildOnMake,
                      @NotNull CompositePackagingElement<?> rootElement, String outputPath,
                      @Nullable ProjectModelExternalSource externalSource, EventDispatcher<? extends ArtifactListener> dispatcher,
                      boolean keepExternalSystemAttribute) {
    myName = name;
    myArtifactType = artifactType;
    myBuildOnMake = buildOnMake;
    myRootElement = rootElement;
    myOutputPath = outputPath;
    myDispatcher = dispatcher;
    myExternalSource = externalSource;
    myKeepExternalSystemAttribute = keepExternalSystemAttribute;
    myProperties = new HashMap<>();
    resetProperties();
  }

  public boolean shouldKeepExternalSystemAttribute() {
    return myKeepExternalSystemAttribute;
  }

  private void resetProperties() {
    myProperties.clear();
    for (ArtifactPropertiesProvider provider : ArtifactPropertiesProvider.getProviders()) {
	@@ -115,7 +122,7 @@ public ProjectModelExternalSource getExternalSource() {

  public ArtifactImpl createCopy(EventDispatcher<? extends ArtifactListener> dispatcher) {
    final ArtifactImpl artifact = new ArtifactImpl(myName, myArtifactType, myBuildOnMake, myRootElement, myOutputPath, myExternalSource,
                                                   dispatcher, myKeepExternalSystemAttribute);
    for (Map.Entry<ArtifactPropertiesProvider, ArtifactProperties<?>> entry : myProperties.entrySet()) {
      final ArtifactProperties newProperties = artifact.myProperties.get(entry.getKey());
      //noinspection unchecked
 <<>> 20 March 2021 <<>>       
        
        import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.packaging.artifacts.*;
import com.intellij.packaging.elements.*;
import com.intellij.util.ObjectUtils;
import com.intellij.util.containers.ContainerUtil;
import gnu.trove.THashSet;
import org.jdom.Element;
	@@ -117,9 +118,15 @@ ArtifactState saveArtifact(Artifact artifact) {
      artifactState.setRootElement(serializePackagingElement(artifact.getRootElement()));
      artifactState.setArtifactType(artifact.getArtifactType().getId());
      ProjectModelExternalSource externalSource = artifact.getExternalSource();
      if (externalSource != null) {
        //we can add this attribute only if the artifact configuration will be stored separately or if the attribute was present in artifact configuration file,
        // otherwise we will get modified files in .idea/artifacts.
        if (ProjectUtilCore.isExternalStorageEnabled(myProject)) {
          artifactState.setExternalSystemId(externalSource.getId());
        }
        else if (artifact instanceof ArtifactImpl && ((ArtifactImpl)artifact).shouldKeepExternalSystemAttribute()) {
          artifactState.setExternalSystemIdInInternalStorage(externalSource.getId());
        }
      }

      for (ArtifactPropertiesProvider provider : artifact.getPropertiesProviders()) {
	@@ -218,7 +225,7 @@ public void loadState(@NotNull ArtifactManagerState managerState) {

  ArtifactImpl loadArtifact(ArtifactState state) {
    ArtifactType type = ArtifactType.findById(state.getArtifactType());
    ProjectModelExternalSource externalSource = findExternalSource(ObjectUtils.chooseNotNull(state.getExternalSystemId(), state.getExternalSystemIdInInternalStorage()));
    if (type == null) {
      return createInvalidArtifact(state, externalSource, JavaCompilerBundle.message("unknown.artifact.type.0", state.getArtifactType()));
    }