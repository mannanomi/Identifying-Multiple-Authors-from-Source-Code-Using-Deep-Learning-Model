<<>>platform/lang-impl/src/com/intellij/psi/impl/source/tree/injected/ConcatenationInjectorManager.java<<>>

<<>> 11 Oct 2018<<>>

package com.intellij.psi.impl.source.tree.injected;

import com.intellij.lang.injection.ConcatenationAwareInjector;
	@@ -24,25 +10,29 @@
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.SimpleModificationTracker;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.impl.PsiManagerEx;
import com.intellij.psi.impl.PsiParameterizedCachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.psi.util.ParameterizedCachedValue;
import com.intellij.psi.util.PsiModificationTracker;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author cdr
 */
public class ConcatenationInjectorManager extends SimpleModificationTracker {
  public static final ExtensionPointName<ConcatenationAwareInjector> CONCATENATION_INJECTOR_EP_NAME = ExtensionPointName.create("com.intellij.concatenationAwareInjector");

  public ConcatenationInjectorManager(Project project, PsiManagerEx psiManagerEx) {
    final ExtensionPoint<ConcatenationAwareInjector> concatPoint = Extensions.getArea(project).getExtensionPoint(CONCATENATION_INJECTOR_EP_NAME);
    concatPoint.addExtensionPointListener(new ExtensionPointListener<ConcatenationAwareInjector>() {
      @Override
	@@ -59,8 +49,8 @@ public void extensionRemoved(@NotNull ConcatenationAwareInjector injector, @Null
    psiManagerEx.registerRunnableToRunOnAnyChange(this::incModificationCount);
  }

  public static ConcatenationInjectorManager getInstance(final Project project) {
    return ServiceManager.getService(project, ConcatenationInjectorManager.class);
  }

  private static InjectionResult doCompute(@NotNull PsiFile containingFile,
	@@ -70,7 +60,7 @@ private static InjectionResult doCompute(@NotNull PsiFile containingFile,
    PsiDocumentManager docManager = PsiDocumentManager.getInstance(project);
    InjectionRegistrarImpl registrar = new InjectionRegistrarImpl(project, containingFile, anchor, docManager);
    InjectionResult result = null;
    ConcatenationInjectorManager concatenationInjectorManager = getInstance(project);
    for (ConcatenationAwareInjector concatenationInjector : concatenationInjectorManager.myConcatenationInjectors) {
      concatenationInjector.getLanguagesToInject(registrar, operands);
      result = registrar.getInjectedResult();
	@@ -84,9 +74,9 @@ private static InjectionResult doCompute(@NotNull PsiFile containingFile,
  private static final Key<Integer> NO_CONCAT_INJECTION_TIMESTAMP = Key.create("NO_CONCAT_INJECTION_TIMESTAMP");

  public abstract static class BaseConcatenation2InjectorAdapter implements MultiHostInjector {
    private final ConcatenationInjectorManager myManager;

    public BaseConcatenation2InjectorAdapter(ConcatenationInjectorManager manager) {
      myManager = manager;
    }

	@@ -149,51 +139,6 @@ public void getLanguagesToInject(@NotNull MultiHostRegistrar registrar, @NotNull
    protected abstract Pair<PsiElement, PsiElement[]> computeAnchorAndOperands(@NotNull PsiElement context);
  }

  private final List<ConcatenationAwareInjector> myConcatenationInjectors = ContainerUtil.createLockFreeCopyOnWriteList();
  public void registerConcatenationInjector(@NotNull ConcatenationAwareInjector injector) {
    myConcatenationInjectors.add(injector);