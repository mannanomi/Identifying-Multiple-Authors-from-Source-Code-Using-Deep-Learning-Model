<<>>java/execution/impl/src/com/intellij/execution/util/JavaParametersUtil.java<<>>
<<>> 25 April 2018 <<>>


@SuppressWarnings("deprecation")
  @NotNull
  public static DefaultJDOMExternalizer.JDOMFilter getFilter(@NotNull CommonJavaRunConfigurationParameters parameters) {
    return new DefaultJDOMExternalizer.JDOMFilter() {
      @Override
      public boolean isAccept(@NotNull Field field) {
        String name = field.getName();
        if ((name.equals("ALTERNATIVE_JRE_PATH_ENABLED") && !parameters.isAlternativeJrePathEnabled()) ||
            (name.equals("ALTERNATIVE_JRE_PATH") && StringUtil.isEmpty(parameters.getAlternativeJrePath()))) {
          return false;
        }
        return true;
      }
    };
  }