<<>>platform/util-rt/src/com/intellij/util/PathUtilRt.java<<>>
<<>> 19 Jan 2019 <<>>


int end = getEnd(path);
    return path.substring(getLastIndexOfPathSeparator(path, end) + 1, end);
  }

  @NotNull
  public static String getFileExt(@Nullable String path) {
    if (StringUtilRt.isEmpty(path)) {
      return "";
    }

    int end = getEnd(path);
    int start = getLastIndexOfPathSeparator(path, end) + 1;
    int index = StringUtilRt.lastIndexOf(path, '.', Math.max(start, 0), end);
    return index < 0 ? "" : path.substring(index + 1, end);
  }

  private static int getEnd(@NotNull String path) {