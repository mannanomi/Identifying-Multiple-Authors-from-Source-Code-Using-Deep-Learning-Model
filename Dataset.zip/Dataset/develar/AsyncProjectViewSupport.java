<<>>platform/lang-impl/src/com/intellij/ide/projectView/impl/AsyncProjectViewSupport.java<<>>
<<>> 18 April 2018 <<>>


//noinspection CodeBlock2Expr
      expand(tree, promise -> {
        myAsyncTreeModel
          .accept(visitor)
          .onProcessed(path -> {
            if (selectPath(tree, path) || element == null || file == null || Registry.is("async.project.view.support.extra.select.disabled")) {
              promise.setResult(null);
            }
            else {
              // try to search the specified file instead of element,
              // because Kotlin files cannot represent containing functions
              myAsyncTreeModel
                .accept(AbstractProjectViewPane.createVisitor(file))
                .onProcessed(path2 -> {
                  selectPath(tree, path2);
                  promise.setResult(null);
                });
            }