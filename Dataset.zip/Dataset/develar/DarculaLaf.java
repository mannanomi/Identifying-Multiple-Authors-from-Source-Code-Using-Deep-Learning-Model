<<>>platform/platform-impl/src/com/intellij/ide/ui/laf/darcula/DarculaLaf.java<<>>
<<>> 12 April 2021 <<>>

public DarculaLaf(@NotNull LookAndFeel base) {
    this.base = base;
    isBaseInitialized = true;
  }

  public DarculaLaf() {
  }


 <<>> 12 April 2021 <<>>

  if (!isBaseInitialized) {
      try {
        if (base == null) {
          base = createBaseLaF();
        }


 <<>> 12 April 2021 <<>>


  @ApiStatus.Internal
  public static @NotNull LookAndFeel createBaseLaF() throws Throwable {
    if (SystemInfoRt.isMac) {
      Class<?> aClass = DarculaLaf.class.getClassLoader().loadClass(UIManager.getSystemLookAndFeelClassName());
      return (BasicLookAndFeel)MethodHandles.lookup().findConstructor(aClass, MethodType.methodType(void.class)).invoke();
    }
    else {
      return new IdeaLaf();
    }
  }

  @ApiStatus.Internal