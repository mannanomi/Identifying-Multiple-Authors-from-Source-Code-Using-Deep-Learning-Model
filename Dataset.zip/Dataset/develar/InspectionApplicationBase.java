<<>>platform/inspect/src/com/intellij/codeInspection/InspectionApplicationBase.java<<>>
<<>> 16 April 2021 <<>>



Path descriptionsFile = resultsDataPath.resolve(InspectionsResultUtil.DESCRIPTIONS + InspectionsResultUtil.XML_EXTENSION);
    try {
      InspectionsResultUtil.describeInspections(descriptionsFile,
                                                myRunWithEditorSettings ? null : inspectionProfile.getName(),
                                                inspectionProfile);
    }
    catch (XMLStreamException e) {
      throw new IOException(e);
    }