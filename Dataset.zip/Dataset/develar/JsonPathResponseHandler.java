<<>>plugins/tasks/tasks-core/src/com/intellij/tasks/generic/JsonPathResponseHandler.java<<>>
<<>> 16b April 2021 <<>>

 @Override
      public JsonProvider jsonProvider() {
        return jsonProvider;
      }

      @Override
      public MappingProvider mappingProvider() {
        return mappingProvider;
      }

      @Override
      public Set<Option> options() {
        return EnumSet.noneOf(Option.class);
      }
    });
  }

  private static final Map<Class<?>, String> JSON_TYPES = Map.of(
    Map.class, "JSON object",
    List.class, "JSON array",
    String.class, "JSON string",
    Integer.class, "JSON number",
    Double.class, "JSON number",
    Boolean.class, "JSON boolean"