<<>>platform/platform-impl/src/com/intellij/idea/StartupUtil.java<<>>
<<>> 12 April 2021 <<>>

 Activity activity = null;
        // we don't need Idea LaF to show splash, but we do need some base LaF to compute system font data (see below for what)
        if (!Main.isHeadless()) {
          // IdeaLaF uses AllIcons - icon manager must be activated
          activity = StartUpMeasurer.startActivity("icon manager activation");
          try {
            IconManager.activate(new CoreIconManager());
          }
          catch (RuntimeException e) {
            throw e;
          }
          catch (Throwable e) {
            throw new RuntimeException(e);
          }
        }

        activity = activity == null ? StartUpMeasurer.startActivity("base LaF creation") : activity.endAndStart("base LaF creation");
        LookAndFeel baseLaF;

<<>> 12 April 2021 <<>>

        JBUIScale.getSystemFontData(() -> {
          Activity subActivity = StartUpMeasurer.startActivity("base LaF defaults getting");
          UIDefaults result = baseLaF.getDefaults();
          subActivity.end();
          return result;
        });

        activity = activity.endAndStart("scale initialization");

<<>> 12 April 2021 <<>>

          activity = activity.endAndStart("LaF initialization");
        // it is required even if headless because some tests creates configurable, so, our LaF is expected
        try {
          UIManager.setLookAndFeel(new IntelliJLaf(baseLaF));
        }
        catch (UnsupportedLookAndFeelException e) {
          throw new RuntimeException(e);
        }


<<>> 12 April 2021<<>>

@SuppressWarnings("UnusedDeclaration")
  public static int processWindowsLauncherCommandLine(String currentDirectory, String[] args) {
    return LISTENER.apply(currentDirectory, args);
  }

  public static boolean isUsingSeparateWriteThread() {
    return Boolean.getBoolean(USE_SEPARATE_WRITE_THREAD_PROPERTY);
  }

  // called by the app after startup
  public static synchronized void addExternalInstanceListener(@Nullable Function<? super List<String>, ? extends Future<CliResult>> processor) {
    if (socketLock == null) throw new AssertionError("Not initialized yet");
    socketLock.setCommandProcessor(processor);
  }

  // used externally by TeamCity plugin (as TeamCity cannot use modern API to support old IDE versions)
  @SuppressWarnings("MissingDeprecatedAnnotation")
  @Deprecated
  @ApiStatus.ScheduledForRemoval(inVersion = "2021.3")
  public static synchronized @Nullable BuiltInServer getServer() {
    return socketLock == null ? null : socketLock.getServer();
  }

  public static synchronized @NotNull CompletableFuture<BuiltInServer> getServerFuture() {
    CompletableFuture<BuiltInServer> serverFuture = socketLock == null ? null : socketLock.getServerFuture();
    return serverFuture == null ? CompletableFuture.completedFuture(null) : serverFuture;
  }

  public static @NotNull Future<@Nullable Boolean> getShellEnvLoadingFuture() {
    return shellEnvLoadFuture;
  }

  private static @NotNull CompletableFuture<@Nullable("if accepted") Object> scheduleEuaDocumentLoading() {
    return CompletableFuture.supplyAsync(() -> {
      String vendorAsProperty = System.getProperty("idea.vendor.name", "");
      if (vendorAsProperty.isEmpty()
          ? !ApplicationInfoImpl.getShadowInstance().isVendorJetBrains()
          : !"JetBrains".equals(vendorAsProperty)) {
        return null;
      }

      Activity activity = StartUpMeasurer.startActivity("eua getting");
      EndUserAgreement.Document document = EndUserAgreement.getLatestDocument();
      activity = activity.endAndStart("eua is accepted checking");
      if (document.isAccepted()) {
        document = null;
      }
      activity.end();
      return document;
    }, ForkJoinPool.commonPool());
  }

  public interface AppStarter {
    /* called from IDE init thread */
    void start(@NotNull List<String> args, @NotNull CompletionStage<?> prepareUiFuture);

    /* called from IDE init thread */
    default void beforeImportConfigs() {}

    /* called from EDT */
    default void beforeStartupWizard() {}

    /* called from EDT */
    default void startupWizardFinished(@NotNull CustomizeIDEWizardStepsProvider provider) {}

    /* called from IDE init thread */
    default void importFinished(@NotNull Path newConfigDir) {}

    /* called from EDT */
    default int customizeIdeWizardDialog(@NotNull List<? extends AbstractCustomizeWizardStep> steps) {
      return -1;
    }
  }

  private static void runPreAppClass(@NotNull Logger log) {
    String classBeforeAppProperty = System.getProperty(IDEA_CLASS_BEFORE_APPLICATION_PROPERTY);
    if (classBeforeAppProperty != null) {
      Activity activity = StartUpMeasurer.startActivity("pre app class running");
      try {
        Class<?> clazz = Class.forName(classBeforeAppProperty);
        Method invokeMethod = clazz.getDeclaredMethod("invoke");
        invokeMethod.setAccessible(true);
        invokeMethod.invoke(null);
      }
      catch (Exception e) {
        log.error("Failed pre-app class init for class " + classBeforeAppProperty, e);
      }
      activity.end();
    }
  }




<<>> 6 April 2021 <<>>


         }

  private static void loadSystemFontsAndDnDCursors() {
    Activity activity = StartUpMeasurer.startActivity("system font data initialization", ActivityCategory.APP_INIT);
    // This forces loading of all system fonts, the following statement itself might not do it (see JBR-1825)
    new Font("N0nEx1st5ntF0nt", Font.PLAIN, 1).getFamily();
    // This caches available font family names (for the default locale) to make corresponding call
    // during editors reopening (in ComplementaryFontsRegistry's initialization code) instantaneous
    GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();



<<>> 6 April 2021 <<>>


// pre-load cursors used by drag-n-drop AWT subsystem
    activity = activity.endAndStart("DnD setup");
    DragSource.getDefaultDragSource();
    activity.end();
  }

  @SuppressWarnings("SpellCheckingInspection")
  private static void showSplashIfNeeded(@NotNull String @NotNull [] args,
                                         @Nullable ForkJoinTask<@Nullable Object> eulaDocument,
                                         @NotNull Activity activity) {
    // product specifies `slash` VM properties, `nosplash` is deprecated property, it should be checked first
    if (Boolean.getBoolean(CommandLineArgs.NO_SPLASH) || !Boolean.getBoolean(CommandLineArgs.SPLASH) || Main.isLightEdit()) {
      return;
    }

    Activity prepareSplashActivity = activity.endAndStart("splash preparation");
    Activity prepareSplashQueueActivity = prepareSplashActivity.startChild("splash preparation (in queue)");
    EventQueue.invokeLater(() -> {
      prepareSplashQueueActivity.end();
      Activity eulaActivity = prepareSplashActivity.startChild("splash eula isAccepted");
      boolean isEulaAccepted;
      try {
        EndUserAgreement.Document document = eulaDocument == null ? null : (EndUserAgreement.Document)eulaDocument.join();
        isEulaAccepted = document == null || document.isAccepted();
      }
      catch (Exception ignore) {
        isEulaAccepted = true;
      }
      eulaActivity.end();

      SplashManager.show(args, isEulaAccepted);
      prepareSplashActivity.end();
    });

<<>> 6 April 2021 <<>>


 ourShellEnvLoaded = ForkJoinPool.commonPool().submit(() -> {
      Activity subActivity = StartUpMeasurer.startActivity("environment loading", ActivityCategory.APP_INIT);
      Path envReaderFile = PathManager.findBinFile(EnvironmentUtil.READER_FILE_NAME);
      return envReaderFile == null ? null : EnvironmentUtil.loadEnvironment(envReaderFile, subActivity);
    });


<<>> 6 April 2021 <<>>  

CompletableFuture<Map<String, String>> envFuture = new CompletableFuture<>();
    ourEnvGetter.set(envFuture);
    Boolean result = Boolean.TRUE;
    try {
      Map<String, String> env = getShellEnv(reader);
      setCharsetVar(env);
      envFuture.complete(Collections.unmodifiableMap(env));
    }
    catch (Throwable t) {
      result = Boolean.FALSE;
      LOG.warn("can't get shell environment", t);
    }
    finally {
      activity.end();
    }

    // execution time of handlers of envFuture should be not included into load env activity
    if (result == Boolean.FALSE) {
      envFuture.complete(getSystemEnv());
    }
    return result;