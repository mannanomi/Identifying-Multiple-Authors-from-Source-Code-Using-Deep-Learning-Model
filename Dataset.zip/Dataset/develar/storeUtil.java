<<>>platform/platform-impl/src/com/intellij/configurationStore/storeUtil.java<<>>
<<>> 17 Jan 2019 <<>>

class StoreUtil private constructor() {
  companion object {
    /**
     * Do not use this method in tests, instead directly save using state store.
     */
    @JvmOverloads
    @JvmStatic
    @CalledInAny
    fun saveSettings(componentManager: ComponentManager, isForceSavingAllSettings: Boolean = false) {
      runBlocking {
        com.intellij.configurationStore.saveSettings(componentManager, isForceSavingAllSettings)
      }
    }

    /**
     * Save all unsaved documents and project settings. Must be called from EDT.
     * Use with care because it blocks EDT. Any new usage should be reviewed.
     */
    @CalledInAwt
    @JvmStatic
    fun saveDocumentsAndProjectSettings(project: Project) {
      FileDocumentManager.getInstance().saveAllDocuments()
      saveSettings(project)
    }

    /**
     * Save all unsaved documents, project and application settings. Must be called from EDT.
     * Use with care because it blocks EDT. Any new usage should be reviewed.
     *
     * @param isForceSavingAllSettings Whether to force save non-roamable component configuration.
     */
    @CalledInAwt
    @JvmStatic
    fun saveDocumentsAndProjectsAndApp(isForceSavingAllSettings: Boolean) {
      FileDocumentManager.getInstance().saveAllDocuments()
      runBlocking {
        saveProjectsAndApp(isForceSavingAllSettings)
      }
    }
  }
}