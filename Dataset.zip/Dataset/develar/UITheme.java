<<>> platform/platform-impl/src/com/intellij/ide/ui/UITheme.java <<>>
<<>> 18 April 2021 <<>>

// caches classes - must be not extracted to util class
  private static final NotNullLazyValue<JSON> JSON_READER = NotNullLazyValue.atomicLazy(() -> {
    // .disable(JSON.Feature.PRESERVE_FIELD_ORDERING) - cannot be disabled, for unknown reason order is important
    // for example, button label font color for light theme is not white, but black
    return JSON.builder()
      .enable(JSON.Feature.READ_ONLY)
      .build();
  });

<<>> 18 April 2021 <<>>

                                        @NotNull Function<? super String, String> iconsMapper)
    throws IllegalStateException, IOException {

    //UITheme theme = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), UITheme.class);
    UITheme theme = JSON_READER.getValue().beanFrom(UITheme.class, stream);



    <<>>12 April 2021 <<>>

colorPalette = Map.ofEntries(
      Map.entry("Actions.Red", "#DB5860"),
      Map.entry("Actions.Red.Dark", "#C75450"),
      Map.entry("Actions.Yellow", "#EDA200"),
      Map.entry("Actions.Yellow.Dark", "#F0A732"),
      Map.entry("Actions.Green", "#59A869"),
      Map.entry("Actions.Green.Dark", "#499C54"),
      Map.entry("Actions.Blue", "#389FD6"),
      Map.entry("Actions.Blue.Dark", "#3592C4"),
      Map.entry("Actions.Grey", "#6E6E6E"),
      Map.entry("Actions.Grey.Dark", "#AFB1B3"),
      Map.entry("Actions.GreyInline", "#7F8B91"),
      Map.entry("Actions.GreyInline.Dark", "#7F8B91"),
      Map.entry("Objects.Grey", "#9AA7B0"),
      Map.entry("Objects.Blue", "#40B6E0"),
      Map.entry("Objects.Green", "#62B543"),
      Map.entry("Objects.Yellow", "#F4AF3D"),
      Map.entry("Objects.YellowDark", "#D9A343"),
      Map.entry("Objects.Purple", "#B99BF8"),
      Map.entry("Objects.Pink", "#F98B9E"),
      Map.entry("Objects.Red", "#F26522"),
      Map.entry("Objects.RedStatus", "#E05555"),
      Map.entry("Objects.GreenAndroid", "#A4C639"),
      Map.entry("Objects.BlackText", "#231F20"),
      Map.entry("Checkbox.Background.Default", "#FFFFFF"),
      Map.entry("Checkbox.Background.Default.Dark", "#43494A"),
      Map.entry("Checkbox.Background.Disabled", "#F2F2F2"),
      Map.entry("Checkbox.Background.Disabled.Dark", "#3C3F41"),
      Map.entry("Checkbox.Border.Default", "#878787"),
      Map.entry("Checkbox.Border.Default.Dark", "#6B6B6B"),
      Map.entry("Checkbox.Border.Disabled", "#BDBDBD"),
      Map.entry("Checkbox.Border.Disabled.Dark", "#545556"),
      Map.entry("Checkbox.Focus.Thin.Default", "#7B9FC7"),
      Map.entry("Checkbox.Focus.Thin.Default.Dark", "#466D94"),
      Map.entry("Checkbox.Focus.Wide", "#97C3F3"),
      Map.entry("Checkbox.Focus.Wide.Dark", "#3D6185"),
      Map.entry("Checkbox.Foreground.Disabled", "#ABABAB"),
      Map.entry("Checkbox.Foreground.Disabled.Dark", "#606060"),
      Map.entry("Checkbox.Background.Selected", "#4D89C9"),
      Map.entry("Checkbox.Background.Selected.Dark", "#43494A"),
      Map.entry("Checkbox.Border.Selected", "#4982CC"),
      Map.entry("Checkbox.Border.Selected.Dark", "#6B6B6B"),
      Map.entry("Checkbox.Foreground.Selected", "#FFFFFF"),
      Map.entry("Checkbox.Foreground.Selected.Dark", "#A7A7A7"),
      Map.entry("Checkbox.Focus.Thin.Selected", "#ACCFF7"),
      Map.entry("Checkbox.Focus.Thin.Selected.Dark", "#466D94"),
      Map.entry("Tree.iconColor", "#808080"),
      Map.entry("Tree.iconColor.Dark", "#AFB1B3")
    );



<<>>12 April 2021<<>>

    public static Object parseValue(String key, @NotNull String value, @NotNull ClassLoader classLoader) {
    switch (value) {
      case "null":
        return null;
      case "true":
        return Boolean.TRUE;
      case "false":
        return Boolean.FALSE;
    }




<<>>12 April 2021<<>>


else if (ints.length == 5) {
          return JBUI.asUIResource(JBUI.Borders.customLine(ColorUtil.fromHex(ints[4]),
                                                           Integer.parseInt(ints[0]),
                                                           Integer.parseInt(ints[1]),
                                                           Integer.parseInt(ints[2]),
                                                           Integer.parseInt(ints[3])));

<<>>12 April 2021<<>>

   else if (ints.length == 5) {
          return JBUI.asUIResource(JBUI.Borders.customLine(ColorUtil.fromHex(ints[4]),
                                                           Integer.parseInt(ints[0]),
                                                           Integer.parseInt(ints[1]),
                                                           Integer.parseInt(ints[2]),
                                                           Integer.parseInt(ints[3])));  

 <<>>12 April 2021<<>>


  if (SystemInfoRt.isMac) {
        Class<?> aClass = DarculaLaf.class.getClassLoader().loadClass(UIManager.getSystemLookAndFeelClassName());
        base = (BasicLookAndFeel)MethodHandles.lookup().findConstructor(aClass, MethodType.methodType(void.class)).invoke();
      }
      else {
        base = new IdeaLaf();
      }

      if (base != null) {
        base.initialize();
      }                   



<<>> 8 April 2021 <<>>

Icon icon;
      if (value.startsWith("AllIcons.")) {
        Icon result;
        try {
          MethodHandle getter = LOOKUP.findStaticGetter(AllIcons.class, value.substring(value.lastIndexOf('.') + 1), Icon.class);
          result = (Icon)getter.invoke();
        }
        catch (Throwable e) {
          result = null;
        }
        icon = result;
      }
      else {
        icon = null;
      }

