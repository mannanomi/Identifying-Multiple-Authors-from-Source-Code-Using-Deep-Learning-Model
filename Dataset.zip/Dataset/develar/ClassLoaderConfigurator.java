<<>>platform/core-impl/src/com/intellij/ide/plugins/ClassLoaderConfigurator.java<<>>
<<>> 19 Feb 2021 <<>>

   return createPluginClassloader(parentLoaders, descriptor, urlClassLoaderBuilder, coreLoader, resourceFileFactory,
                                         new PluginClassLoader.ResolveScopeManager() {
                                           @Override
                                           public boolean isDefinitelyAlienClass(String name, String packagePrefix) {
                                             return !name.startsWith(packagePrefix) &&
                                                    !name.startsWith("com.intellij.ultimate.PluginVerifier") &&
                                                    !name.equals("com.intellij.codeInspection.unused.ImplicitPropertyUsageProvider");
                                           }
                                         });

<<>> 19 Feb 2021 <<>>

  else if (!descriptor.contentDescriptor.modules.isEmpty()) {
      // see "The `content.module` element" section about content handling for a module
      return createPluginClassloader(parentLoaders, descriptor, urlClassLoaderBuilder, coreLoader, resourceFileFactory,
                                     createModuleContentBasedScope(descriptor));
    }
    

<<>> 19 Feb 2021 <<>>                                           

  if (descriptor.packagePrefix == null) {
      return new PluginClassLoader(urlClassLoaderBuilder, parentLoaders, descriptor, descriptor.getPluginPath(), coreLoader, null,
                                   null, resourceFileFactory);
    }
    else {
      return createPluginClassloader(parentLoaders, descriptor, urlClassLoaderBuilder, coreLoader, resourceFileFactory,
                                     new PluginClassLoader.ResolveScopeManager() {
                                       @Override
                                       public boolean isDefinitelyAlienClass(String name, String packagePrefix) {
                                         return !name.startsWith(packagePrefix) && !name.startsWith("com.intellij.ultimate.PluginVerifier");
                                       }
                                     });


<<>> 19 Feb 2021 <<>>   

 private static @NotNull PluginClassLoader createPluginClassloader(@NotNull ClassLoader @NotNull [] parentLoaders,
                                                                    @NotNull IdeaPluginDescriptorImpl descriptor,
                                                                    @NotNull UrlClassLoader.Builder urlClassLoaderBuilder,
                                                                    @NotNull ClassLoader coreLoader,
                                                                    @Nullable ClassPath.ResourceFileFactory resourceFileFactory,
                                                                    @Nullable PluginClassLoader.ResolveScopeManager resolveScopeManager) {                                    

<<>> 19 Feb 2021 <<>>

 return createPluginClassloader(parentLoaders, descriptor, urlClassLoaderBuilder, coreLoader, resourceFileFactory,
                                   new PluginClassLoader.ResolveScopeManager() {
                                     @Override
                                     public boolean isDefinitelyAlienClass(String name, String packagePrefix) {
                                       return !name.startsWith(packagePrefix) && !name.startsWith("com.intellij.ultimate.PluginVerifier") &&
                                              !name.startsWith(customPackage);
                                     }
                                   });

<<>> 19 Feb 2021 <<>>

   return (name, packagePrefix) -> {
      if (name.startsWith(packagePrefix) || name.startsWith("com.intellij.ultimate.PluginVerifier")) {
        return false;
      }

      // for a module, the referenced module doesn't have own classloader and is added directly to classpath,
      // so, if name doesn't pass standard package prefix filter,
      // check that it is not in content - if in content, then it means that class is not alien      
      


<<>> 15 Feb 2021 <<>>

List<String> contentPackagePrefixes = getContentPackagePrefixes(descriptor);
    List<String> dependencyPackagePrefixes = getDependencyPackagePrefixes(descriptor);
    String pluginId = descriptor.getPluginId().getIdString();
    return name -> {
      for (String prefix : contentPackagePrefixes) {
        if (name.startsWith(prefix)) {
          getLogger().error("Class " + name + " must be not requested from main classloader of " + pluginId + " plugin");
          return true;
        }



<<>> 15 Feb 2021 <<>>


for (String prefix : dependencyPackagePrefixes) {
        if (name.startsWith(prefix)) {
          return true;
        }
      }
      return false;
    };
  }

  private static @NotNull List<String> getContentPackagePrefixes(@NotNull IdeaPluginDescriptorImpl descriptor) {
    List<String> result = null;

<<>> 15 Feb 2021 <<>>

private static @NotNull List<String> getDependencyPackagePrefixes(@NotNull IdeaPluginDescriptorImpl descriptor) {
    if (descriptor.dependencyDescriptor.modules.isEmpty()) {
      return Collections.emptyList();
    }

    List<String> result = new ArrayList<>(descriptor.dependencyDescriptor.modules.size());
    for (ModuleDependenciesDescriptor.ModuleItem item : descriptor.dependencyDescriptor.modules) {
      String packagePrefix = item.packageName;
      // intellij.platform.commercial.verifier is injected
      if (packagePrefix != null && !item.name.equals("intellij.platform.commercial.verifier")) {
        result.add(packagePrefix + '.');
                           