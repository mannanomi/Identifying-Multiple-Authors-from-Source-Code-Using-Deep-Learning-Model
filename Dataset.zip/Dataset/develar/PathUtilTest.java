<<>>platform/util/testSrc/com/intellij/util/PathUtilTest.java<<>>
<<>> 19 Jan 2019 <<>>


@Test
  public void fileName() {
    assertThat(PathUtilRt.getFileName("foo.html")).isSameAs("foo.html");
    assertThat(PathUtilRt.getFileName("/bar/foo.html")).isEqualTo("foo.html");
    assertThat(PathUtilRt.getFileName("bar/foo.html")).isEqualTo("foo.html");
    assertThat(PathUtilRt.getFileName("bar/foo.html/")).isEqualTo("foo.html");
  }

  @Test
  public void fileExt() {
    assertThat(PathUtilRt.getFileExt("foo.html")).isEqualTo("html");
    assertThat(PathUtilRt.getFileExt("foo.html/")).isEqualTo("html");
    assertThat(PathUtilRt.getFileExt("/foo.html/")).isEqualTo("html");
    assertThat(PathUtilRt.getFileExt("/bar/foo.html/")).isEqualTo("html");
  }