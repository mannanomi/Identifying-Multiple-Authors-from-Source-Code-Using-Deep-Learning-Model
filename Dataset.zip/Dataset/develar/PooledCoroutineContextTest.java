<<>>platform/platform-tests/testSrc/com/intellij/application/PooledCoroutineContextTest.java<<>>
<<>> 17 Jan 2019 <<>>

package com.intellij.application

import com.intellij.testFramework.assertions.Assertions.assertThat
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Test

class PooledCoroutineContextTest {
  @Test
  fun `log error`() = runBlocking<Unit> {
    val errorMessage = "don't swallow me"
    // cannot use assertThatThrownBy here, because AssertJ doesn't support Kotlin coroutines
    try {
      PooledScope.launch {
        throw RuntimeException(errorMessage)
      }.join()
    }
    catch (e: AssertionError) {
      // in tests logger throws AssertionError on log.error()
      assertThat(e).hasMessage(errorMessage)
    }
  }

  @Test
  fun `error must be propagated to parent context if available`() = runBlocking {
    class MyCustomException : RuntimeException()

    try {
      withContext(pooledThreadContext) {
        throw MyCustomException()
      }
    }
    catch (ignored: MyCustomException) {
    }
  }
}