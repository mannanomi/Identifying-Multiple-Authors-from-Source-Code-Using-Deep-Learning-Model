<<>>platform/util/ui/src/com/intellij/ui/scale/JBUIScale.java<<>>
<<>> 12 April 2021 <<>>

private static float getOrComputeUserScaleFactor() {
    float result = userScaleFactor;
    if (!Float.isNaN(result)) {
      return result;
    }

    Float debug = DEBUG_USER_SCALE_FACTOR.get();
    if (debug != null) {
      return result;

 <<>> 12 April 2021 <<>>
 

    synchronized (lock) {
      result = userScaleFactor;
      if (Float.isNaN(result)) {
        result = computeUserScaleFactor(JreHiDpiUtil.isJreHiDPIEnabled() ? 1f : sysScale());
        userScaleFactor = result;
      }
    }
    return result;
  }


<<>> 12 April 2021 <<>>

  loat result = systemScaleFactor;
    if (Float.isNaN(result)) {
      synchronized (lock) {
        result = systemScaleFactor;
        if (Float.isNaN(result)) {
          result = computeSystemScaleFactor();
          systemScaleFactor = result;
        }
      }
    }
    return result;

<<>> 12 April 2021 <<>>

     float userScaleFactor = getOrComputeUserScaleFactor();
    if (userScaleFactor == 1.25f) {
      return (int)(fontSize * 1.34f);
    }
    else if (userScaleFactor == 1.75f) {
      return (int)(fontSize * 1.67f);
    }
    else {
      return (int)scale(fontSize);
    }