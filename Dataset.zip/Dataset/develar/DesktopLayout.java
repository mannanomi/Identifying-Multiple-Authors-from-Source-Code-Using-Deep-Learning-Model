<<>>platform/platform-impl/src/com/intellij/openapi/wm/impl/DesktopLayout.java<<>>
<<>> 2 May 2018 <<>>

 private static int getAnchorWeight(@NotNull ToolWindowAnchor anchor) {
    if (anchor == ToolWindowAnchor.TOP) {
      return SwingConstants.TOP;
    }
    if (anchor == ToolWindowAnchor.LEFT) {
      return SwingConstants.LEFT;
    }
    if (anchor == ToolWindowAnchor.BOTTOM) {
      return SwingConstants.BOTTOM;
    }
    if (anchor == ToolWindowAnchor.RIGHT) {
      return SwingConstants.RIGHT;
    }
    return 0;
  }

  private static final Comparator<WindowInfoImpl> ourWindowInfoComparator = (o1, o2) -> {
    int d = getAnchorWeight(o1.getAnchor()) - getAnchorWeight(o2.getAnchor());
    return d == 0 ? o1.getOrder() - o2.getOrder() : d;
  };

  static final String TAG = "layout";


 <<>> 2 May 2018 <<>>


   List<WindowInfoImpl> result = new ArrayList<>();
      for (WindowInfoImpl value : myIdToInfo.values()) {
        if (value.isRegistered()) {
          result.add(value);
        }


   

