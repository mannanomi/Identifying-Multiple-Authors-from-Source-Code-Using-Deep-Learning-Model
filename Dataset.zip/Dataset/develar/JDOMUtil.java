<<>>platform/util/src/com/intellij/openapi/util/JDOMUtil.java<<>>
<<>> 16 April 2021 <<>>

finally {
          if (property != null) {
            System.setProperty(XML_INPUT_FACTORY_KEY, property);
          }
          else {
            System.clearProperty(XML_INPUT_FACTORY_KEY);
          }
        }

        // avoid loading of SystemInfo and Strings classes
        String jvmVendor = System.getProperty("java.vm.vendor", "");
        if (!jvmVendor.contains("IBM") && !jvmVendor.contains("ibm")) {
          try {
            //noinspection HttpUrlsUsage
            factory.setProperty("http://java.sun.com/xml/stream/properties/report-cdata-event", true);
          }
          catch (Exception e) {
            getLogger().error("cannot set \"report-cdata-event\" property for XMLInputFactory", e);
          }

<<>>17 Jan 2019 <<>>

 @NotNull
  public static String removeControlChars(@NotNull String text) {
    StringBuilder result = null;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (!Verifier.isXMLCharacter(c)) {
        if (result == null) {
          result = new StringBuilder(text.length());
          result.append(text, 0, i);
        }
        continue;
      }

      if (result != null) {
        result.append(c);
      }
    }
    return result == null ? text : result.toString();
  }
          