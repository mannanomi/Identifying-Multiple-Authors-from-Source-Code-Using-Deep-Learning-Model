<<>>platform/core-api/src/com/intellij/openapi/application/ApplicationNamesInfo.java<<>>
<<>> 16 April 2021 <<>>


    String filePath;
    if (Boolean.getBoolean("idea.use.dev.build.server")) {
      String module = null;
      if (prefix.isEmpty() || prefix.equals(PlatformUtils.IDEA_PREFIX)) {
        module = "intellij.idea.ultimate.resources";
      }
      else if (prefix.equals(PlatformUtils.WEB_PREFIX)) {
        module = "intellij.webstorm";
      }

      if (module == null) {
        filePath = null;
      }
      else {
        filePath = PathManager.getHomePath() + "/out/classes/production/" + module + "/idea/" +
                   (prefix.equals("idea") ? "" : prefix) + "ApplicationInfo.xml";
      }
    }
    else {
      filePath = PathManager.getBinPath() + "/appInfo.xml";
    }

    // production
    if (filePath != null) {
      Path file = Paths.get(filePath);
      try {
        return JDOMUtil.load(Files.newBufferedReader(file));
      }
      catch (NoSuchFileException ignore) {
      }
      catch (Exception e) {
        throw new RuntimeException("Cannot load " + file, e);
      }
    }

    // from sources
    String resource = "idea/" + (prefix.equals("idea") ? "" : prefix) + "ApplicationInfo.xml";
    InputStream stream = ApplicationNamesInfo.class.getClassLoader().getResourceAsStream(resource);