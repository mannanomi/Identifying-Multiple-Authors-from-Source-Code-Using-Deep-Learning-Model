<<>>platform/lang-impl/src/com/intellij/ide/projectView/impl/ProjectViewImpl.java<<>>
<<>> 2 May 2018 <<>>

@NotNull
  public static String getDefaultViewId() {
    //noinspection SpellCheckingInspection
    if (!"AndroidStudio".equals(PlatformUtils.getPlatformPrefix()) || Boolean.getBoolean("studio.projectview")) {
      return ProjectViewPane.ID;
    }
    else {
      return "AndroidView";
    }
  }