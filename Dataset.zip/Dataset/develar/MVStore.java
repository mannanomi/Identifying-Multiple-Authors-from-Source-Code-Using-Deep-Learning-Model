<<>>platform/util-ex/src/org/jetbrains/mvstore/MVStore.java<<>>
<<>>14 April 2021 <<>>

 Chunk chunk = chunks.get(chunkId);
      if (chunk != null) {
        return chunk;
      }

      checkOpen();
      byte[] metadata = chunkIdToChunkMetadata.get(chunkId);
      if (metadata == null) {
          throw new MVStoreException(MVStoreException.ERROR_CHUNK_NOT_FOUND, "Chunk " + chunkId + " not found");
      }

      chunk = Chunk.readMetadata(chunkId, Unpooled.wrappedBuffer(metadata));
      if (!chunk.isSaved()) {
          throw new MVStoreException(MVStoreException.ERROR_CHUNK_NOT_FOUND, "Chunk " + chunkId + " is invalid");
      }
      Chunk prev = chunks.putIfAbsent(chunkId, chunk);
      return prev == null ? chunk : prev;