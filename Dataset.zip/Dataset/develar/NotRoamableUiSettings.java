<<>>platform/editor-ui-api/src/com/intellij/ide/ui/NotRoamableUiSettings.java<<>>
<<>> 17 Jan 2019 <<>>

state.fontSize = UISettings.restoreFontSize(state.fontSize, state.fontScale)
    state.fontScale = UISettings.defFontScale
    state.initDefFont()

    // 1. Sometimes system font cannot display standard ASCII symbols. If so we have
    // find any other suitable font withing "preferred" fonts first.
    var fontIsValid = UIUtil.isValidFont(Font(state.fontFace, Font.PLAIN, state.fontSize))
    if (!fontIsValid) {
      for (preferredFont in arrayOf("dialog", "Arial", "Tahoma")) {
        if (UIUtil.isValidFont(Font(preferredFont, Font.PLAIN, state.fontSize))) {
          state.fontFace = preferredFont
          fontIsValid = true
          break
        }
      }

      // 2. If all preferred fonts are not valid in current environment
      // we have to find first valid font (if any)
      if (!fontIsValid) {
        val fontNames = UIUtil.getValidFontNames(false)
        if (fontNames.isNotEmpty()) {
          state.fontFace = fontNames[0]
        }
      }
    }
  }
}

internal fun NotRoamableUiOptions.initDefFont() {
  val fontData = systemFontFaceAndSize
  if (fontFace == null) {
    fontFace = fontData.first
  }
  if (fontSize <= 0) {
    fontSize = fontData.second
  }
  if (fontScale <= 0) {
    fontScale = UISettings.defFontScale


 <<>> 17 Jan 2019 <<>>
 

  @get:Property(filter = FontFilter::class)
  var fontFace by string()

  @get:Property(filter = FontFilter::class)
  var fontSize by property(UISettingsState.defFontSize)

  @get:Property(filter = FontFilter::class)
  var fontScale by property(0f)
}

private class FontFilter : SerializationFilter {
  override fun accepts(accessor: Accessor, bean: Any): Boolean {
    val settings = bean as NotRoamableUiOptions
    val fontData = systemFontFaceAndSize
    if ("fontFace" == accessor.name) {
      return fontData.first != settings.fontFace
    }
    // fontSize/fontScale should either be stored in pair or not stored at all
    // otherwise the fontSize restore logic gets broken (see loadState)
    return !(fontData.second == settings.fontSize && 1f == settings.fontScale)
  }
}

internal val systemFontFaceAndSize: Pair<String, Int>
  get() {
    val fontData = UIUtil.getSystemFontData()
    if (fontData != null) {
      return fontData
    }

    return Pair.create("Dialog", 12)
  }  