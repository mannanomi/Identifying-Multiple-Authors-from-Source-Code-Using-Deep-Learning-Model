<<>>platform/util/src/com/intellij/AbstractBundle.java<<>>
<<>> 20 Mar 2021 <<>>

private final static class MyResourceControl extends ResourceBundle.Control {
    final static MyResourceControl INSTANCE = new MyResourceControl();

    @Override
    public List<String> getFormats(String baseName) {
      return FORMAT_PROPERTIES;
    }

    @Override
    public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload)
      throws IOException {
      String bundleName = toBundleName(baseName, locale);
      // application protocol check
      String resourceName = bundleName.contains("://") ? null : toResourceName(bundleName, "properties");
      if (resourceName == null) {
        return null;
      }

      InputStream stream = loader.getResourceAsStream(resourceName);
      if (stream == null) {
        return null;
      }

      try {
        return new PropertyResourceBundle(new InputStreamReader(stream, StandardCharsets.UTF_8));
      }
      finally {
        stream.close();
      }
    }
  }