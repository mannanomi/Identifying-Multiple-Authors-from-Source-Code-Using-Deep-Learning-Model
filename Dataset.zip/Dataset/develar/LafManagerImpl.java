<<>>platform/platform-impl/src/com/intellij/ide/ui/laf/LafManagerImpl.java<<>>
<<>> 18 April 2021 <<>>


private final SynchronizedClearableLazy<UIManager.LookAndFeelInfo> defaultLightLaf = new SynchronizedClearableLazy<>(() -> {
    for (UIThemeProvider provider : UIThemeProvider.EP_NAME.getIterable()) {
      if (DEFAULT_LIGHT_THEME_ID.equals(provider.id)) {
        UITheme theme = provider.createTheme();
        if (theme != null) {
          return new UIThemeBasedLookAndFeelInfo(theme);
        }
      }
    }
    LOG.error("Can't load " + DEFAULT_LIGHT_THEME_ID);

    String lafInfoFQN = ApplicationInfoEx.getInstanceEx().getDefaultLightLaf();
    UIManager.LookAndFeelInfo lookAndFeelInfo = lafInfoFQN == null ? null : createLafInfo(lafInfoFQN);
    return lookAndFeelInfo == null ? new IntelliJLookAndFeelInfo() : lookAndFeelInfo;
  });

  private final SynchronizedClearableLazy<UIManager.LookAndFeelInfo> defaultDarkLaf = new SynchronizedClearableLazy<>(() -> {
    String lafInfoFQN = ApplicationInfoEx.getInstanceEx().getDefaultDarkLaf();
    UIManager.LookAndFeelInfo lookAndFeelInfo = lafInfoFQN == null ? null : createLafInfo(lafInfoFQN);
    return lookAndFeelInfo != null ? lookAndFeelInfo : new DarculaLookAndFeelInfo();
  });



<<>> 18 April 2021 <<>>

   private void syncLaf(boolean systemIsDark) {
    if (!autodetect) {
      return;
    }

    boolean currentIsDark =
      myCurrentLaf instanceof UIThemeBasedLookAndFeelInfo && ((UIThemeBasedLookAndFeelInfo)myCurrentLaf).getTheme().isDark() ||
      StartupUiUtil.isUnderDarcula();
    UIManager.LookAndFeelInfo expectedLaf;
    if (systemIsDark) {
      expectedLaf = preferredDarkLaf;
      if (expectedLaf == null) {
        expectedLaf = getDefaultDarkLaf();
      }
    }
    else {
      expectedLaf = preferredLightLaf;
      if (expectedLaf == null) {
        expectedLaf = getDefaultLightLaf();

<<>> 18 April 2021 <<>>


         if (laf == null) {
      return;
    }

    String className = laf.getClassName();
    if (className != null) {
      Element child = new Element(attrName);
      child.setAttribute(ATTRIBUTE_CLASS_NAME, className);

      if (laf instanceof UIThemeBasedLookAndFeelInfo) {
        child.setAttribute(ATTRIBUTE_THEME_NAME, ((UIThemeBasedLookAndFeelInfo)laf).getTheme().getId());