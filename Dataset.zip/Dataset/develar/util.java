<<>>platform/platform-impl/src/com/intellij/application/util.java<<>>


<<>> 17 Jan 2019 <<>>



/**
 * Execute coroutine on pooled thread. Uncaught error will be logged.
 *
 * @see com.intellij.openapi.application.Application.executeOnPooledThread
 */
val pooledThreadContext: CoroutineContext = ApplicationThreadPoolDispatcher().plus(CoroutineExceptionHandler { _, throwable ->
  // otherwise not possible to test - will be "Start Failed: Internal error" because in tests app not yet started / not created
  val app = ApplicationManager.getApplication()
  if (app == null || app.isUnitTestMode) {
    Logger.getInstance("#com.intellij.application.impl.ApplicationImpl").error(throwable)
  }
  else {
    PluginManager.processException(throwable)
  }
})

object PooledScope : CoroutineScope {
  override val coroutineContext = pooledThreadContext
}

// no need to implement isDispatchNeeded - Kotlin correctly uses the same thread if coroutines executes sequentially,
// and if launch/async is used, it is correct and expected that coroutine will be dispatched to another pooled thread.
private class ApplicationThreadPoolDispatcher : CoroutineDispatcher() {
  override fun dispatch(context: CoroutineContext, block: Runnable) {
    AppExecutorUtil.getAppExecutorService().execute(block)
  }

  override fun toString() = AppExecutorUtil.getAppExecutorService().toString()


<<>> 17 Jan 2019 <<>>


  saveSettings(this)
}

@CalledInAny
internal fun saveAllProjects(isForceSavingAllSettings: Boolean) {
  for (project in ProjectManager.getInstance().openProjects) {
    saveSettings(project, isForceSavingAllSettings)
  }
}

@CalledInAny
internal suspend fun saveDocumentsAndProjectsAndApp(onlyProject: Project?,
                                                    isForceSavingAllSettings: Boolean = false,
                                                    isDocumentsSavingExplicit: Boolean = true) {
  coroutineScope {
    launch(AppUIExecutor.onUiThread().coroutineDispatchingContext()) {
      (FileDocumentManagerImpl.getInstance() as FileDocumentManagerImpl).saveAllDocuments(isDocumentsSavingExplicit)
    }
    launch {
      doSaveProjectsAndApp(isForceSavingAllSettings = isForceSavingAllSettings, onlyProject = onlyProject)
    }
  }
}